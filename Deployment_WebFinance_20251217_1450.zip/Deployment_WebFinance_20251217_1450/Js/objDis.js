﻿var oop = function(arrData,stNum,stMoney,stDiv)
{
this.arr = [];
this.arrData = arrData;
this.stNum = stNum;
this.stMoney = stMoney;
this.stDiv = stDiv;
this.readflag = false
this.addDis = function(stDis)
{//1,,0,4,455.00,1
    var arrSt = stDis.split (',');
    var no = arrSt[0];
    var msg = arrSt[1];
    var index = arrSt[2];
    var num = arrSt[3];
    var money = parseFloat(arrSt[4]).toFixed(2);
    var cnt;
    
    this.addRow();
    cnt = this.arr.length - 1;
    this.arr[cnt].txt = index;
    this.arr[cnt].msg = msg;
    this.arr[cnt].n = num;
    this.arr[cnt].m = money;
    this.addData(cnt);
    
}
this.addRow = function()
    {
        var arrNum = this.arr.length;
        var txtAdd = {s : '<table><tr><td class="tdPic" align="right" ><span id="txtNo' + this.stDiv + arrNum + '" class="lbI"  ></span>.</td><td class="tdTxt" >'+
                      '<select id="lstSell' + this.stDiv + arrNum +'" onblur="setSell' + this.stDiv + '(this,' + arrNum +')"  class="selTxt" name="lstSell" ></select>'+
                      '<table border ="0" cellpadding ="0" cellspacing ="0"><tr><td><span id="txtSell' + this.stDiv + arrNum +'" class="selTxt"  ></span></td><td><input type"text" id="txtMsg' + this.stDiv + arrNum +'" onblur="setMsg' + this.stDiv + '(this,' + arrNum +')"  value="" /></td></tr></table></td><td>'+
                      '<input id="txtNum' + this.stDiv + arrNum + '" class="inputNum"  onblur="setNum' + this.stDiv + '(this,' + arrNum + ')"   onkeydown="fixkeyNum(this)" maxlength="2" />'+
                      '</td><td class="numType"><span class="lbI" >' + this.stNum + '</span></td><td>'+
                      '<input id="txtMoney' + this.stDiv + arrNum +'" class="inputMoney" onblur="setMoney' + this.stDiv + '(this,' + arrNum +')"   onkeydown="fixkey(this)" maxlength="14"  /></td>'+
                      '<td  class="monType"><span class="lbI" >' + this.stMoney + '</span>'+
                      '</td><td class="tdPic"><img src="img/add.gif" id="add' + this.stDiv + arrNum +'" title="เพิ่ม" class="imgPic" onclick="addRow' + this.stDiv + '();" alt="เพิ่ม" /></td><td  class="tdPic"><img src="img/del.gif" id="del' + this.stDiv + arrNum +'" title="ลบ" class="imgPic" onclick="delRow' + this.stDiv + '(' + arrNum + ')" alt="ลบ" /></td></tr></table>',
                      txt:"",msg:"",n:"",m:""
                      };
    var chkNum = arrNum - 1;
    if(chkNum != -1 && this.arr[chkNum] != null)
    {
        if(this.arr[chkNum].txt == "" || this.arr[chkNum].txt == "0")
        {
            alert("กรุณาเลือกข้อมูล");
            return;
        }
        else
            if(this.arr[chkNum].n == "")
            {
                alert("กรุณาใส่จำนวนข้อมูล");
                return;
            }
            else
                if(this.arr[chkNum].m == "")
                {
                    alert("กรุณาใส่จำนวนเงินข้อมูล");
                    return;
                }
    }
    this.arr[arrNum] = txtAdd;
    this.addAll();
    }
    this.addAll = function()
    {
        var num = 0;
        var numEnd = 0;
        document.getElementById(this.stDiv).innerHTML = "";
        for(var i = 0;i< this.arr.length ;i++)
        {
            if(this.arr[i] != null)
            {
                numEnd = i ;
             
                document.getElementById(this.stDiv).innerHTML += this.arr[i].s;
                document.getElementById("txtNo" + this.stDiv + numEnd).innerHTML = ++num;
                document.getElementById("add" + this.stDiv + numEnd).style.display = "none";
                document.getElementById("txtMsg" + this.stDiv + numEnd).style.display = "none";
                this.setSel(document.getElementById("lstSell" + this.stDiv + numEnd));
                this.addData(numEnd);
                if(this.readflag)
                {
                    document.getElementById("txtNum" + this.stDiv + numEnd).disabled = this.readflag;
                    document.getElementById("txtMoney" + this.stDiv + numEnd).disabled = this.readflag;
                    document.getElementById("txtMsg" + this.stDiv + numEnd).disabled = this.readflag;
                    document.getElementById("add" + this.stDiv + numEnd).style.display = "none";
                    document.getElementById("del" + this.stDiv + numEnd).style.display = "none";
                }
            }       
        }
        if(document.getElementById(this.stDiv).innerHTML != "" && this.readflag == false)
           document.getElementById("add" + this.stDiv + numEnd).style.display = "block";
    }
    
    
    this.setSell = function(obj,num)
    {
        if(obj.options[obj.selectedIndex].value != 0)
        {
            obj.style.display = "none";
            document.getElementById("txtSell" + this.stDiv + num).innerHTML = obj.options[obj.selectedIndex].text;
            this.arr[num].txt = obj.selectedIndex;
            if(obj.options[obj.selectedIndex].value.indexOf('-') != -1)
            {
                document.getElementById("txtMsg" + this.stDiv + num).style.display = "block";
            }
        }
    }
    
    this.setMsg = function(obj,num)
    {
        this.arr[num].msg = obj.value;
    }
    
    this.setNum = function(obj,num)
    {
       if(obj.value != '')
       {
          this.arr[num].n = obj.value;
       }
    }
    this.setMoney = function(obj,num)
    {
       if(obj.value != '')
       {
          obj.value = parseFloat(obj.value).toFixed(2);
          this.arr[num].m = obj.value;
       }
       else
       {
          this.arr[num].m = obj.value;
       }
    }
    this.addData = function(num,disF)
    {
        var obj = document.getElementById("lstSell" + this.stDiv + num);
        if(this.arr[num].txt != '')
        {
            obj.style.display = "none";
            obj.selectedIndex = this.arr[num].txt;
            document.getElementById("txtSell" + this.stDiv + num).innerHTML = obj.options[obj.selectedIndex].text;
            if(obj.options[obj.selectedIndex].value.indexOf('-') != -1)
            {
                document.getElementById("txtMsg" + this.stDiv + num).style.display = "block";
                document.getElementById("txtMsg" + this.stDiv + num).value = this.arr[num].msg;
            }
       }
       if(this.arr[num].n != '')
       {
            document.getElementById("txtNum" + this.stDiv + num).value = this.arr[num].n;
//            if(disF == true)
//            {
//                
//            }
       }
       if(this.arr[num].m != '')
       {
            document.getElementById("txtMoney" + this.stDiv + num).value = this.arr[num].m;
           
//            if(disF == true)
//            {
//                
//            }
       }
    }
    this.setSel = function(obj)
    {
        for(var i = 0;i < this.arrData.length ;i++)
        {
            obj.add( arrData[i]);
        }
        obj.selectedIndex = 0;
    }
    
    this.delRow = function(arrNum)
    {
        this.arr[arrNum] = null;
     /*   var arr2 = new Array();
        for(var i = 0,j = 0;i< this.arr.length ;i++)
        {
            if(this.arr[i] != null)
            {
                arr2[j] = this.arr[i];
                j++;
            }
        }
        this.arr = arr2;*/
        this.addAll();
        if(document.getElementById(this.stDiv).innerHTML == "")
        {
            this.arr = new Array();
            this.addRow();
        }
    }
    this.sumNum = function()
    {
        var sum = 0;
        for(var i = 0;i< this.arr.length;i++)
        {
          if(this.arr[i] !=null)
          {
            if(this.arr[i].n != "")
            {
                sum += parseInt(this.arr[i].n,10);
            }
          }
        }
        return sum;
    }
    this.sumMoney = function()
    {
        var sum = 0;
        for(var i = 0;i< this.arr.length;i++)
        {
          if(this.arr[i] !=null)
          {
            if(this.arr[i].m != "")
            {
                sum += parseFloat(this.arr[i].m);
            }
          }
        }
        return sum.toFixed(2);
    }
    this.saveData = function()
    {
        var stSave = "";
        for(var i = 0;i< this.arr.length ;i++)
        {
            if(this.arr[i] != null)
            {
                stSave += document.getElementById("txtNo" + this.stDiv + i ).innerHTML + "," +
                          document.getElementById("txtMsg" + this.stDiv + i ).value + "," +
                          document.getElementById("lstSell" + this.stDiv + i).options[this.arr[i].txt].value + "," +
                          this.arr[i].n + "," +
                          this.arr[i].m + "|" ;
                if(this.arr[i].txt == "" || this.arr[i].n == "" || this.arr[i].m == "")
                {
                    stSave = "";
                    break;
                }         
            }       
        }
        return stSave;
    }
}


                      