Imports System
Imports System.Collections.Generic
Imports Newtonsoft.Json
Imports Amazon
Imports Amazon.SecretsManager
Imports Amazon.SecretsManager.Model

Public Class AWSHelper
    
    ''' <summary>
    ''' Retrieves a secret from AWS Secrets Manager
    ''' </summary>
    ''' <param name="secretName">The name of the secret to retrieve</param>
    ''' <param name="region">The AWS region where the secret is stored</param>
    ''' <returns>The secret value as a string</returns>
    Public Shared Function GetSecretString(secretName As String, Optional region As String = "us-east-1") As String
        Try
            ' Create AWS Secrets Manager client with specified region
            Dim client As IAmazonSecretsManager = New AmazonSecretsManagerClient(
                RegionEndpoint.GetBySystemName(region))

            ' Create request to get secret value
            Dim request As New GetSecretValueRequest()
            request.SecretId = secretName
            request.VersionStage = "AWSCURRENT" ' Retrieve the latest version

            ' Call AWS Secrets Manager to get the secret
            Dim response As GetSecretValueResponse = client.GetSecretValueAsync(request).Result

            ' Return the secret string
            Return response.SecretString
        Catch ex As ResourceNotFoundException
            Throw New Exception($"The requested secret '{secretName}' was not found.", ex)
        Catch ex As InvalidParameterException
            Throw New Exception($"The request had invalid parameters. Please check the secret name '{secretName}'.", ex)
        Catch ex As InvalidRequestException
            Throw New Exception("The request was invalid due to an error on the server side.", ex)
        Catch ex As DecryptionFailureException
            Throw New Exception("Decryption failed for the secret.", ex)
        Catch ex As InternalServiceException
            Throw New Exception("An error occurred on the server side.", ex)
        Catch ex As Exception
            Throw New Exception($"An unexpected error occurred while retrieving secret '{secretName}': {ex.Message}", ex)
        End Try
    End Function
    
    ''' <summary>
    ''' Retrieves a secret from AWS Secrets Manager and parses it as JSON
    ''' </summary>
    ''' <typeparam name="T">The type to deserialize the JSON to</typeparam>
    ''' <param name="secretName">The name of the secret to retrieve</param>
    ''' <param name="region">The AWS region where the secret is stored</param>
    ''' <returns>The deserialized object</returns>
    Public Shared Function GetSecretObject(Of T)(secretName As String, Optional region As String = "us-east-1") As T
        Dim secretString As String = GetSecretString(secretName, region)
        Return JsonConvert.DeserializeObject(Of T)(secretString)
    End Function
    
    ''' <summary>
    ''' Example class for database connection secrets
    ''' </summary>
    Public Class DatabaseSecret
        Public Property Username As String
        Public Property Password As String
        Public Property Host As String
        Public Property Port As Integer
        Public Property Database As String
    End Class
    
    ''' <summary>
    ''' Example class for API key secrets
    ''' </summary>
    Public Class ApiKeySecret
        Public Property ApiKey As String
        Public Property ApiSecret As String
    End Class
End Class