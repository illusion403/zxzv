Imports System
Imports Amazon
Imports Amazon.Runtime
Imports Amazon.SecretsManager
Imports Amazon.SecretsManager.Model

Public Class AdvancedAWSHelper
    
    ''' <summary>
    ''' Retrieves a secret from AWS Secrets Manager using explicit credentials
    ''' </summary>
    ''' <param name="secretName">The name of the secret to retrieve</param>
    ''' <param name="accessKey">AWS Access Key</param>
    ''' <param name="secretKey">AWS Secret Key</param>
    ''' <param name="region">The AWS region where the secret is stored</param>
    ''' <returns>The secret value as a string</returns>
    Public Shared Function GetSecretWithCredentials(secretName As String, accessKey As String, secretKey As String, region As String) As String
        Try
            ' Create AWS credentials
            Dim credentials As AWSCredentials = New BasicAWSCredentials(accessKey, secretKey)
            
            ' Create AWS Secrets Manager client with explicit credentials
            Dim client As IAmazonSecretsManager = New AmazonSecretsManagerClient(credentials, RegionEndpoint.GetBySystemName(region))

            ' Create request to get secret value
            Dim request As New GetSecretValueRequest()
            request.SecretId = secretName
            request.VersionStage = "AWSCURRENT"

            ' Call AWS Secrets Manager to get the secret
            Dim response As GetSecretValueResponse = client.GetSecretValueAsync(request).Result

            ' Return the secret string
            Return response.SecretString
        Catch ex As Exception
            Throw New Exception($"Error retrieving secret '{secretName}': {ex.Message}", ex)
        End Try
    End Function
    
    ''' <summary>
    ''' Retrieves a secret from AWS Secrets Manager using a session token (for temporary credentials)
    ''' </summary>
    ''' <param name="secretName">The name of the secret to retrieve</param>
    ''' <param name="accessKey">AWS Access Key</param>
    ''' <param name="secretKey">AWS Secret Key</param>
    ''' <param name="sessionToken">Session token</param>
    ''' <param name="region">The AWS region where the secret is stored</param>
    ''' <returns>The secret value as a string</returns>
    Public Shared Function GetSecretWithSessionToken(secretName As String, accessKey As String, secretKey As String, sessionToken As String, region As String) As String
        Try
            ' Create AWS credentials with session token
            Dim credentials As AWSCredentials = New SessionAWSCredentials(accessKey, secretKey, sessionToken)
            
            ' Create AWS Secrets Manager client with session credentials
            Dim client As IAmazonSecretsManager = New AmazonSecretsManagerClient(credentials, RegionEndpoint.GetBySystemName(region))

            ' Create request to get secret value
            Dim request As New GetSecretValueRequest()
            request.SecretId = secretName
            request.VersionStage = "AWSCURRENT"

            ' Call AWS Secrets Manager to get the secret
            Dim response As GetSecretValueResponse = client.GetSecretValueAsync(request).Result

            ' Return the secret string
            Return response.SecretString
        Catch ex As Exception
            Throw New Exception($"Error retrieving secret '{secretName}': {ex.Message}", ex)
        End Try
    End Function
    
    ''' <summary>
    ''' Retrieves binary secret data from AWS Secrets Manager
    ''' </summary>
    ''' <param name="secretName">The name of the secret to retrieve</param>
    ''' <param name="region">The AWS region where the secret is stored</param>
    ''' <returns>The secret value as a byte array</returns>
    Public Shared Function GetBinarySecret(secretName As String, region As String) As Byte()
        Try
            ' Create AWS Secrets Manager client
            Dim client As IAmazonSecretsManager = New AmazonSecretsManagerClient(RegionEndpoint.GetBySystemName(region))

            ' Create request to get secret value
            Dim request As New GetSecretValueRequest()
            request.SecretId = secretName
            request.VersionStage = "AWSCURRENT"

            ' Call AWS Secrets Manager to get the secret
            Dim response As GetSecretValueResponse = client.GetSecretValueAsync(request).Result

            ' Return the secret binary data
            Return response.SecretBinary.ToArray()
        Catch ex As Exception
            Throw New Exception($"Error retrieving binary secret '{secretName}': {ex.Message}", ex)
        End Try
    End Function
End Class