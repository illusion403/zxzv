Imports System
Imports System.Web.UI

Partial Public Class AdvancedExample
    Inherits Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Try
            ' Example of retrieving a secret with explicit credentials
            ' NOTE: Never hardcode credentials in production code!
            ' Use IAM roles, environment variables, or secure configuration instead.
            Dim accessKey As String = System.Configuration.ConfigurationManager.AppSettings("AWSAccessKey")
            Dim secretKey As String = System.Configuration.ConfigurationManager.AppSettings("AWSSecretKey")
            Dim secretValue As String = AdvancedAWSHelper.GetSecretWithCredentials("MySecret", accessKey, secretKey, "us-east-1")
            
            lblResult.Text = "Retrieved secret value: " & secretValue
            
            ' Example of retrieving binary secret data
            ' Dim binaryData As Byte() = AdvancedAWSHelper.GetBinarySecret("MyBinarySecret", "us-east-1")
            ' lblResult.Text &= "<br/>Binary secret size: " & binaryData.Length & " bytes"
            
        Catch ex As Exception
            lblResult.Text = "Error: " & ex.Message
        End Try
    End Sub
End Class