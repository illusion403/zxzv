Imports System
Imports System.Web.UI

Partial Public Class _Default
    Inherits Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Try
            ' Example of retrieving a secret from AWS Secrets Manager
            Dim secretValue As String = AWSHelper.GetSecretString("MyDatabaseSecret")
            lblResult.Text = "Retrieved secret value: " & secretValue
            
            ' Example of retrieving and parsing a database secret
            ' Dim dbSecret As AWSHelper.DatabaseSecret = AWSHelper.GetSecretObject(Of AWSHelper.DatabaseSecret)("MyDatabaseSecret")
            ' lblResult.Text &= "<br/>Username: " & dbSecret.Username
        Catch ex As Exception
            lblResult.Text = "Error: " & ex.Message
        End Try
    End Sub
End Class