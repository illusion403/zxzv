# AWS Secrets Manager VB.NET Web Application Example

This is a sample VB.NET web application that demonstrates how to retrieve secrets from AWS Secrets Manager.

## Prerequisites

1. Visual Studio or another .NET development environment
2. AWS account with appropriate permissions to access Secrets Manager
3. AWS SDK for .NET installed (included in packages.config)
4. Valid AWS credentials configured (via AWS Toolkit for Visual Studio, IAM roles, or environment variables)

## Setup Instructions

1. Open the project in Visual Studio
2. Restore NuGet packages:
   ```
   nuget restore packages.config
   ```
3. Configure your AWS credentials using one of these methods:
   - AWS Toolkit for Visual Studio
   - AWS credentials file (~/.aws/credentials)
   - Environment variables (AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY)
   - IAM roles (if running on EC2)

4. Update the Web.config file with your AWS region:
   ```xml
   <add key="AWSRegion" value="your-region-here" />
   ```

## Code Structure

- `Default.aspx` - Main web page
- `Default.aspx.vb` - Code-behind that retrieves secrets from AWS Secrets Manager
- `AWSHelper.vb` - Helper class with methods for retrieving and parsing secrets
- `Web.config` - Configuration file with AWS settings
- `packages.config` - NuGet package references

## Usage Examples

### Retrieving a Simple Secret String

```vb
Dim secretValue As String = AWSHelper.GetSecretString("MySecretName")
```

### Retrieving and Parsing a JSON Secret

```vb
Dim dbSecret As AWSHelper.DatabaseSecret = AWSHelper.GetSecretObject(Of AWSHelper.DatabaseSecret)("MyDatabaseSecret")
Dim username As String = dbSecret.Username
Dim password As String = dbSecret.Password
```

## Error Handling

The example includes comprehensive error handling for common AWS Secrets Manager exceptions:
- ResourceNotFoundException
- InvalidParameterException
- InvalidRequestException
- DecryptionFailureException
- InternalServiceException

## Security Best Practices

1. Never log secret values
2. Use least privilege IAM policies
3. Rotate secrets regularly
4. Use SSL/TLS for all communications
5. Store compiled application binaries securely

## Required IAM Permissions

Your AWS credentials need the following permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue"
      ],
      "Resource": "arn:aws:secretsmanager:region:account:secret:secret-name"
    }
  ]
}
```