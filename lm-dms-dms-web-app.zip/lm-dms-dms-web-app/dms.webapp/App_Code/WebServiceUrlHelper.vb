Imports System
Imports System.Configuration

''' <summary>
''' Helper class to manage web service URLs and other settings dynamically from appSettings
''' </summary>
Public Class WebServiceUrlHelper

    ''' <summary>
    ''' Gets the web service URL for the aegis web service from appSettings
    ''' </summary>
    ''' <returns>The URL for the aegis web service</returns>
    Public Shared Function GetAegisWebServiceUrl() As String
        Dim url As String = ConfigurationManager.AppSettings("dms_webapp_wsSearchAegis_aegisWebService")
        Return url
    End Function

    ''' <summary>
    ''' Gets the web service URL for the image service from appSettings
    ''' </summary>
    ''' <returns>The URL for the image service</returns>
    Public Shared Function GetImageServiceUrl() As String
        Dim url As String = ConfigurationManager.AppSettings("dms_webapp_wsSearchData_ImageService1")
        Return url
    End Function

    ''' <summary>
    ''' Gets the web service URL for the policy service from appSettings
    ''' </summary>
    ''' <returns>The URL for the policy service</returns>
    Public Shared Function GetPolicyServiceUrl() As String
        Dim url As String = ConfigurationManager.AppSettings("dms_webapp_wsSearchPolicy_Service1")
        Return url
    End Function

    ''' <summary>
    ''' Gets the web service URL for the LSIC service from appSettings
    ''' </summary>
    ''' <returns>The URL for the LSIC service</returns>
    Public Shared Function GetLsicServiceUrl() As String
        Dim url As String = ConfigurationManager.AppSettings("dms_webapp_wsLsic_Service1")
        Return url
    End Function

    ''' <summary>
    ''' Gets the web service URL for the authentication service from appSettings
    ''' </summary>
    ''' <returns>The URL for the authentication service</returns>
    Public Shared Function GetAuthServiceUrl() As String
        Dim url As String = ConfigurationManager.AppSettings("dms_webapp_wsAuthen_Service1")
        Return url
    End Function

    ''' <summary>
    ''' Gets the DMS database connection string from appSettings
    ''' </summary>
    ''' <returns>The DMS database connection string</returns>
    Public Shared Function GetDMSData() As String
        Dim value As String = ConfigurationManager.AppSettings("DMS_data")
        Return value
    End Function

    ''' <summary>
    ''' Gets the WUP database connection string from appSettings
    ''' </summary>
    ''' <returns>The WUP database connection string</returns>
    Public Shared Function GetWUPData() As String
        Dim value As String = ConfigurationManager.AppSettings("WUP_data")
        Return value
    End Function

    ''' <summary>
    ''' Gets the DTW database connection string from appSettings
    ''' </summary>
    ''' <returns>The DTW database connection string</returns>
    Public Shared Function GetDTWData() As String
        Dim value As String = ConfigurationManager.AppSettings("DTW_data")
        Return value
    End Function

    ''' <summary>
    ''' Gets the DMS2 database connection string from appSettings
    ''' </summary>
    ''' <returns>The DMS2 database connection string</returns>
    Public Shared Function GetDMS2Data() As String
        Dim value As String = ConfigurationManager.AppSettings("DMS2_data")
        Return value
    End Function

    ''' <summary>
    ''' Gets the DWPROD database connection string from appSettings
    ''' </summary>
    ''' <returns>The DWPROD database connection string</returns>
    Public Shared Function GetDWPRODData() As String
        Dim value As String = ConfigurationManager.AppSettings("DWPROD_data")
        Return value
    End Function

    ''' <summary>
    ''' Gets the MOB database connection string from appSettings
    ''' </summary>
    ''' <returns>The MOB database connection string</returns>
    Public Shared Function GetMOBData() As String
        Dim value As String = ConfigurationManager.AppSettings("MOB_data")
        Return value
    End Function

    ''' <summary>
    ''' Gets the SETUP database connection string from appSettings
    ''' </summary>
    ''' <returns>The SETUP database connection string</returns>
    Public Shared Function GetSETUPData() As String
        Dim value As String = ConfigurationManager.AppSettings("SETUP_data")
        Return value
    End Function

    ''' <summary>
    ''' Gets the NSIS share path from appSettings
    ''' </summary>
    ''' <returns>The NSIS share path</returns>
    Public Shared Function GetNSISShare() As String
        Dim value As String = ConfigurationManager.AppSettings("NSIS_Share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the DMS share path from appSettings
    ''' </summary>
    ''' <returns>The DMS share path</returns>
    Public Shared Function GetDMSShare() As String
        Dim value As String = ConfigurationManager.AppSettings("DMS_share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the DMSUW share path from appSettings
    ''' </summary>
    ''' <returns>The DMSUW share path</returns>
    Public Shared Function GetDMSUWShare() As String
        Dim value As String = ConfigurationManager.AppSettings("DMSUW_share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the DMSFN share path from appSettings
    ''' </summary>
    ''' <returns>The DMSFN share path</returns>
    Public Shared Function GetDMSFNShare() As String
        Dim value As String = ConfigurationManager.AppSettings("DMSFN_share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the EMCS share path from appSettings
    ''' </summary>
    ''' <returns>The EMCS share path</returns>
    Public Shared Function GetEMCSShare() As String
        Dim value As String = ConfigurationManager.AppSettings("EMCS_share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the DIY share path from appSettings
    ''' </summary>
    ''' <returns>The DIY share path</returns>
    Public Shared Function GetDIYShare() As String
        Dim value As String = ConfigurationManager.AppSettings("DIY_Share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the SIG share path from appSettings
    ''' </summary>
    ''' <returns>The SIG share path</returns>
    Public Shared Function GetSIGShare() As String
        Dim value As String = ConfigurationManager.AppSettings("SIG_Share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the MI1 share path from appSettings
    ''' </summary>
    ''' <returns>The MI1 share path</returns>
    Public Shared Function GetMI1Share() As String
        Dim value As String = ConfigurationManager.AppSettings("MI1_Share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the MI2 share path from appSettings
    ''' </summary>
    ''' <returns>The MI2 share path</returns>
    Public Shared Function GetMI2Share() As String
        Dim value As String = ConfigurationManager.AppSettings("MI2_Share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the MI3 share path from appSettings
    ''' </summary>
    ''' <returns>The MI3 share path</returns>
    Public Shared Function GetMI3Share() As String
        Dim value As String = ConfigurationManager.AppSettings("MI3_Share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the MOB share path from appSettings
    ''' </summary>
    ''' <returns>The MOB share path</returns>
    Public Shared Function GetMOBShare() As String
        Dim value As String = ConfigurationManager.AppSettings("MOB_Share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the MEMO share path from appSettings
    ''' </summary>
    ''' <returns>The MEMO share path</returns>
    Public Shared Function GetMEMOShare() As String
        Dim value As String = ConfigurationManager.AppSettings("MEMO_share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Memo_Orj share path from appSettings
    ''' </summary>
    ''' <returns>The Memo_Orj share path</returns>
    Public Shared Function GetMemoOrj() As String
        Dim value As String = ConfigurationManager.AppSettings("Memo_Orj")
        Return value
    End Function

    ''' <summary>
    ''' Gets the RECEIPT share path from appSettings
    ''' </summary>
    ''' <returns>The RECEIPT share path</returns>
    Public Shared Function GetRECEIPTShare() As String
        Dim value As String = ConfigurationManager.AppSettings("RECEIPT_Share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the qkcash share path from appSettings
    ''' </summary>
    ''' <returns>The qkcash share path</returns>
    Public Shared Function GetQkcashShare() As String
        Dim value As String = ConfigurationManager.AppSettings("qkcash_Share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the PRINT share path from appSettings
    ''' </summary>
    ''' <returns>The PRINT share path</returns>
    Public Shared Function GetPRINTShare() As String
        Dim value As String = ConfigurationManager.AppSettings("PRINT_share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the ClaimCard share path from appSettings
    ''' </summary>
    ''' <returns>The ClaimCard share path</returns>
    Public Shared Function GetClaimCardShare() As String
        Dim value As String = ConfigurationManager.AppSettings("ClaimCard_share")
        Return value
    End Function

    ''' <summary>
    ''' Gets the SV_BKK value from appSettings
    ''' </summary>
    ''' <returns>The SV_BKK value</returns>
    Public Shared Function GetSVBKK() As String
        Dim value As String = ConfigurationManager.AppSettings("SV_BKK")
        Return value
    End Function

    ''' <summary>
    ''' Gets the URL_LINK value from appSettings
    ''' </summary>
    ''' <returns>The URL_LINK value</returns>
    Public Shared Function GetURLLink() As String
        Dim value As String = ConfigurationManager.AppSettings("URL_LINK")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Format_date value from appSettings
    ''' </summary>
    ''' <returns>The Format_date value</returns>
    Public Shared Function GetFormatDate() As String
        Dim value As String = ConfigurationManager.AppSettings("Format_date")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Region value from appSettings
    ''' </summary>
    ''' <returns>The Region value</returns>
    Public Shared Function GetRegion() As String
        Dim value As String = ConfigurationManager.AppSettings("Region")
        Return value
    End Function

    ''' <summary>
    ''' Gets the EMCSRegion value from appSettings
    ''' </summary>
    ''' <returns>The EMCSRegion value</returns>
    Public Shared Function GetEMCSRegion() As String
        Dim value As String = ConfigurationManager.AppSettings("EMCSRegion")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Url_Bangkok value from appSettings
    ''' </summary>
    ''' <returns>The Url_Bangkok value</returns>
    Public Shared Function GetUrlBangkok() As String
        Dim value As String = ConfigurationManager.AppSettings("Url_Bangkok")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Url_Central value from appSettings
    ''' </summary>
    ''' <returns>The Url_Central value</returns>
    Public Shared Function GetUrlCentral() As String
        Dim value As String = ConfigurationManager.AppSettings("Url_Central")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Url_East value from appSettings
    ''' </summary>
    ''' <returns>The Url_East value</returns>
    Public Shared Function GetUrlEast() As String
        Dim value As String = ConfigurationManager.AppSettings("Url_East")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Url_North value from appSettings
    ''' </summary>
    ''' <returns>The Url_North value</returns>
    Public Shared Function GetUrlNorth() As String
        Dim value As String = ConfigurationManager.AppSettings("Url_North")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Url_Northeast value from appSettings
    ''' </summary>
    ''' <returns>The Url_Northeast value</returns>
    Public Shared Function GetUrlNortheast() As String
        Dim value As String = ConfigurationManager.AppSettings("Url_Northeast")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Url_South value from appSettings
    ''' </summary>
    ''' <returns>The Url_South value</returns>
    Public Shared Function GetUrlSouth() As String
        Dim value As String = ConfigurationManager.AppSettings("Url_South")
        Return value
    End Function

    ''' <summary>
    ''' Gets the Archive_Url value from appSettings
    ''' </summary>
    ''' <returns>The Archive_Url value</returns>
    Public Shared Function GetArchiveUrl() As String
        Dim value As String = ConfigurationManager.AppSettings("Archive_Url")
        Return value
    End Function
End Class