﻿Imports System
Imports System.Web
Imports System.Web.UI

Public Class BasePage
    Inherits System.Web.UI.Page

    Protected Overrides Sub OnPreLoad(e As EventArgs)
        ' Apply common security measures to all pages
        ApplySecurityHeaders()

        ' Validate authentication for protected pages
        ValidateAuthentication()

        MyBase.OnPreLoad(e)
    End Sub

    Protected Overrides Sub OnPreRender(e As EventArgs)
        ' Add common JavaScript for session management
        AddSessionManagementScript()

        MyBase.OnPreRender(e)
    End Sub

    Private Sub ApplySecurityHeaders()
        ' Prevent Clickjacking
        Response.Headers.Remove("X-Frame-Options")
        Response.AddHeader("X-Frame-Options", "DENY")

        ' XSS Protection
        Response.Headers.Remove("X-XSS-Protection")
        Response.AddHeader("X-XSS-Protection", "1; mode=block")

        ' Content Type Options
        Response.Headers.Remove("X-Content-Type-Options")
        Response.AddHeader("X-Content-Type-Options", "nosniff")

        ' Cache Control for authenticated pages
        If Session("IsAuthenticated") IsNot Nothing AndAlso Convert.ToBoolean(Session("IsAuthenticated")) Then
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
            Response.Cache.SetNoStore()
            Response.AppendHeader("Pragma", "no-cache")
        End If
    End Sub

    Private Sub ValidateAuthentication()
        ' Get current page name
        Dim currentPage As String = System.IO.Path.GetFileNameWithoutExtension(Request.Url.AbsolutePath).ToLower()

        ' Skip authentication check for login, logout, and public pages
        If currentPage = "login" OrElse currentPage = "logout" OrElse currentPage = "keepalive" OrElse currentPage = "diagnostics" Then
            Return
        End If

        ' Check if user is authenticated
        If Session("IsAuthenticated") Is Nothing OrElse Not Convert.ToBoolean(Session("IsAuthenticated")) Then
            ' Clear any existing session data
            Session.Clear()
            Session.Abandon()

            ' Redirect to login
            Response.Redirect("Login.aspx")
            Return
        End If

        ' For cookie-based sessions, also validate the SessionExpiry cookie
        ValidateSessionExpiry()
    End Sub

    Private Sub ValidateSessionExpiry()
        ' Replace null-conditional operator with compatible code for .NET 3.5
        Dim expiryStr As String = Nothing
        If Request.Cookies("SessionExpiry") IsNot Nothing Then
            expiryStr = Request.Cookies("SessionExpiry").Value
        End If

        If String.IsNullOrEmpty(expiryStr) Then
            ' No session expiry cookie, redirect to login
            Session.Clear()
            Session.Abandon()
            Response.Redirect("Login.aspx")
            Return
        End If

        Dim expiryMs As Long
        If Long.TryParse(expiryStr, expiryMs) Then
            Dim nowMs As Long = CLng((DateTime.UtcNow - New DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds)
            If expiryMs < nowMs Then
                ' Session has expired
                Session.Clear()
                Session.Abandon()
                Response.Redirect("Login.aspx")
                Return
            End If
        Else
            ' Invalid cookie value
            Session.Clear()
            Session.Abandon()
            Response.Redirect("Login.aspx")
            Return
        End If
    End Sub

    Private Sub AddSessionManagementScript()
        ' Get current page name
        Dim currentPage As String = System.IO.Path.GetFileNameWithoutExtension(Request.Url.AbsolutePath).ToLower()

        ' Skip script injection for login, logout, and public pages
        If currentPage = "login" OrElse currentPage = "logout" OrElse currentPage = "keepalive" OrElse currentPage = "diagnostics" Then
            Return
        End If

        ' Only add script for authenticated pages
        If Session("IsAuthenticated") Is Nothing OrElse Not Convert.ToBoolean(Session("IsAuthenticated")) Then
            Return
        End If

        ' Add the session management JavaScript
        Dim script As String = "
            <script>
                // Utility to get cookie by name
                function getCookie(name) {
                    var v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
                    return v ? v[2] : null;
                }
    
                // Utility to set cookie
                function setCookie(name, value, minutes) {
                    var expires = '';
                    if (minutes) {
                        var date = new Date();
                        date.setTime(date.getTime() + (minutes * 60 * 1000));
                        expires = '; expires=' + date.toUTCString();
                    }
                    document.cookie = name + '=' + value + expires + '; path=/';
                }
    
                // Utility to erase cookie
                function eraseCookie(name) {   
                    document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
                }

                var checkInterval;
                var localExpiryTime = 0;

                function startMonitoring() {
                    // Initialize local expiry time from cookie
                    var expiryStr = getCookie('SessionExpiry');
                    if (expiryStr) {
                        localExpiryTime = parseInt(expiryStr);
                    }
        
                    if (checkInterval) clearInterval(checkInterval);
                    checkInterval = setInterval(checkSession, 1000);
                }

                function checkSession() {
                    var expiryStr = getCookie('SessionExpiry');

                    if (!expiryStr) {
                        // Cookie missing - likely logged out in another tab
                        forceLogout();
                        return;
                    }

                    var expiryMs = parseInt(expiryStr);
                    var now = Date.now();
                    var remainingMs = expiryMs - now;
        
                    // Check if the cookie has been updated by another tab
                    if (Math.abs(expiryMs - localExpiryTime) > 1000) {
                        // Cookie was updated by another tab, update local copy
                        localExpiryTime = expiryMs;
                    }

                    if (remainingMs <= 0) {
                        forceLogout();
                    } else if (remainingMs < 60000) { // Less than 1 minute
                        showWarning();
                    } else {
                        // Session is healthy
                        hideWarning();
                    }
        
                    // Update any timeout display labels
                    updateTimeoutDisplay(remainingMs);
                }

                function showWarning() {
                    // Try to find and show timeout modal
                    var modal = document.getElementById('timeout-modal');
                    if (modal) {
                        modal.style.display = 'block';
                    }
                }
    
                function hideWarning() {
                    // Try to find and hide timeout modal
                    var modal = document.getElementById('timeout-modal');
                    if (modal) {
                        modal.style.display = 'none';
                    }
                }

                function extendSession() {
                    // Check auth via KeepAlive endpoint
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', 'KeepAlive.ashx', true);
                    xhr.onload = function () {
                        if (xhr.status === 200) {
                            // KeepAlive.ashx updates the cookie.
                            hideWarning();
                            checkSession();
                        } else {
                            // Session is invalid or expired
                            forceLogout();
                        }
                    };
                    xhr.onerror = function () { forceLogout(); };
                    xhr.send();
                }

                function logout() {
                    // User clicked Log Out in modal
                    // Redirect to Logout.aspx to clear everything
                    window.location.href = 'Logout.aspx';
                }

                function forceLogout() {
                    // Timeout reached or cookie cleared
                    window.location.href = 'Logout.aspx';
                }
    
                function updateTimeoutDisplay(remainingMs) {
                    // Try to find any elements with class 'session-timeout-display'
                    var displayElements = document.getElementsByClassName('session-timeout-display');
                    if (displayElements.length > 0) {
                        var minutesLeft = Math.ceil(remainingMs / 60000);
                        if (minutesLeft >= 0) {
                            for (var i = 0; i < displayElements.length; i++) {
                                displayElements[i].innerText = minutesLeft;
                            }
                        }
                    }
                }

                // Start monitoring when page loads
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', startMonitoring);
                } else {
                    startMonitoring();
                }
            </script>"

        ' Register the script
        ClientScript.RegisterClientScriptBlock(Me.GetType(), "SessionManagementScript", script, False)
    End Sub

    Protected Sub ExpireCookie(cookieName As String)
        ' Utility method to expire cookies consistently
        If Request.Cookies(cookieName) IsNot Nothing Then
            Dim cookie As New HttpCookie(cookieName)
            cookie.Expires = DateTime.Now.AddDays(-1)
            cookie.Value = ""
            cookie.Path = "/"
            Response.Cookies.Add(cookie)
        End If
    End Sub
End Class