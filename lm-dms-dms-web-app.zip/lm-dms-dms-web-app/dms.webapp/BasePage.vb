﻿Imports System
Imports System.Web
Imports System.Web.UI

Public Class BasePage
    Inherits System.Web.UI.Page

    Protected Overrides Sub OnPreLoad(e As EventArgs)
        ' Apply common security measures to all pages
        ApplySecurityHeaders()

        ' Validate authentication for protected pages
        ValidateAuthentication()

        MyBase.OnPreLoad(e)
    End Sub

    Protected Overrides Sub OnPreRender(e As EventArgs)
        ' Add common JavaScript for session management
        AddSessionManagementScript()
        
        ' Add HTML for the session timeout modal
        AddSessionTimeoutModal()

        MyBase.OnPreRender(e)
    End Sub

    Private Sub ApplySecurityHeaders()
        ' Prevent Clickjacking
        Response.Headers.Remove("X-Frame-Options")
        Response.AddHeader("X-Frame-Options", "DENY")

        ' XSS Protection
        Response.Headers.Remove("X-XSS-Protection")
        Response.AddHeader("X-XSS-Protection", "1; mode=block")

        ' Content Type Options
        Response.Headers.Remove("X-Content-Type-Options")
        Response.AddHeader("X-Content-Type-Options", "nosniff")

        ' Cache Control for authenticated pages
        If Session("IsAuthenticated") IsNot Nothing AndAlso Convert.ToBoolean(Session("IsAuthenticated")) Then
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
            Response.Cache.SetNoStore()
            Response.AppendHeader("Pragma", "no-cache")
        End If
    End Sub

    Private Sub ValidateAuthentication()
        ' Get current page name
        Dim currentPage As String = System.IO.Path.GetFileNameWithoutExtension(Request.Url.AbsolutePath).ToLower()

        ' Skip authentication check for login, logout, and public pages
        If currentPage = "login" OrElse currentPage = "logout" OrElse currentPage = "keepalive" OrElse currentPage = "diagnostics" Then
            Return
        End If

        ' Check if user is authenticated
        If Session("IsAuthenticated") Is Nothing OrElse Not Convert.ToBoolean(Session("IsAuthenticated")) Then
            ' Clear any existing session data
            Session.Clear()
            Session.Abandon()

            ' Redirect to login
            Response.Redirect("Login.aspx")
            Return
        End If

        ' For cookie-based sessions, also validate the SessionExpiry cookie
        ValidateSessionExpiry()
    End Sub

    Private Sub ValidateSessionExpiry()
        ' Replace null-conditional operator with compatible code for .NET 3.5
        Dim expiryStr As String = Nothing
        If Request.Cookies("SessionExpiry") IsNot Nothing Then
            expiryStr = Request.Cookies("SessionExpiry").Value
        End If

        If String.IsNullOrEmpty(expiryStr) Then
            ' No session expiry cookie, redirect to login
            Session.Clear()
            Session.Abandon()
            Response.Redirect("Login.aspx")
            Return
        End If

        Dim expiryMs As Long
        If Long.TryParse(expiryStr, expiryMs) Then
            Dim nowMs As Long = CLng((DateTime.UtcNow - New DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds)
            If expiryMs < nowMs Then
                ' Session has expired
                Session.Clear()
                Session.Abandon()
                Response.Redirect("Login.aspx")
                Return
            End If
        Else
            ' Invalid cookie value
            Session.Clear()
            Session.Abandon()
            Response.Redirect("Login.aspx")
            Return
        End If
    End Sub

    Private Sub AddSessionManagementScript()
        ' Get current page name
        Dim currentPage As String = System.IO.Path.GetFileNameWithoutExtension(Request.Url.AbsolutePath).ToLower()

        ' Skip script injection for login, logout, and public pages
        If currentPage = "login" OrElse currentPage = "logout" OrElse currentPage = "keepalive" OrElse currentPage = "diagnostics" Then
            Return
        End If

        ' Only add script for authenticated pages
        If Session("IsAuthenticated") Is Nothing OrElse Not Convert.ToBoolean(Session("IsAuthenticated")) Then
            Return
        End If

        ' Add the session management JavaScript
        Dim script As String = "
            <script>
                // Utility to get cookie by name
                function getCookie(name) {
                    var v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
                    return v ? v[2] : null;
                }
    
                // Utility to set cookie
                function setCookie(name, value, minutes) {
                    var expires = '';
                    if (minutes) {
                        var date = new Date();
                        date.setTime(date.getTime() + (minutes * 60 * 1000));
                        expires = '; expires=' + date.toUTCString();
                    }
                    document.cookie = name + '=' + value + expires + '; path=/';
                }
    
                // Utility to erase cookie
                function eraseCookie(name) {   
                    document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
                }

                var checkInterval;
                var localExpiryTime = 0;

                function startMonitoring() {
                    // Initialize local expiry time from cookie
                    var expiryStr = getCookie('SessionExpiry');
                    if (expiryStr) {
                        localExpiryTime = parseInt(expiryStr);
                    }
        
                    if (checkInterval) clearInterval(checkInterval);
                    checkInterval = setInterval(checkSession, 1000);
                }

                function checkSession() {
                    var expiryStr = getCookie('SessionExpiry');

                    if (!expiryStr) {
                        // Cookie missing - likely logged out in another tab
                        forceLogout();
                        return;
                    }

                    var expiryMs = parseInt(expiryStr);
                    var now = Date.now();
                    var remainingMs = expiryMs - now;
        
                    // Check if the cookie has been updated by another tab
                    if (Math.abs(expiryMs - localExpiryTime) > 1000) {
                        // Cookie was updated by another tab, update local copy
                        localExpiryTime = expiryMs;
                    }

                    if (remainingMs <= 0) {
                        forceLogout();
                    } else if (remainingMs < 60000) { // Less than 1 minute
                        showWarning();
                    } else {
                        // Session is healthy
                        hideWarning();
                    }
        
                    // Update any timeout display labels
                    updateTimeoutDisplay(remainingMs);
                }

                function showWarning() {
                    // Try to find and show timeout modal
                    var modal = document.getElementById('timeout-modal');
                    if (modal) {
                        modal.style.display = 'block';
                    }
                }
    
                function hideWarning() {
                    // Try to find and hide timeout modal
                    var modal = document.getElementById('timeout-modal');
                    if (modal) {
                        modal.style.display = 'none';
                    }
                }

                function extendSession() {
                    // Check auth via KeepAlive endpoint
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', 'KeepAlive.ashx', true);
                    xhr.onload = function () {
                        if (xhr.status === 200) {
                            // KeepAlive.ashx updates the cookie.
                            hideWarning();
                            checkSession();
                        } else {
                            // Session is invalid or expired
                            forceLogout();
                        }
                    };
                    xhr.onerror = function () { forceLogout(); };
                    xhr.send();
                }

                function logout() {
                    // User clicked Log Out in modal
                    // Redirect to Logout.aspx to clear everything
                    window.location.href = 'Logout.aspx';
                }

                function forceLogout() {
                    // Timeout reached or cookie cleared
                    // Pass current URL to allow returning after login
                    var currentUrl = encodeURIComponent(window.location.pathname + window.location.search);
                    window.location.href = 'Logout.aspx?returnUrl=' + currentUrl;
                }
    
                function updateTimeoutDisplay(remainingMs) {
                    // Try to find any elements with class 'session-timeout-display'
                    var displayElements = document.getElementsByClassName('session-timeout-display');
                    if (displayElements.length > 0) {
                        if (remainingMs >= 0) {
                            var minutes = Math.floor(remainingMs / 60000);
                            var seconds = Math.floor((remainingMs % 60000) / 1000);
                            var text = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
                            
                            for (var i = 0; i < displayElements.length; i++) {
                                displayElements[i].innerText = text;
                            }
                        }
                    }
                }

                // Start monitoring when page loads
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', startMonitoring);
                } else {
                    startMonitoring();
                }
            </script>"

    ' Register the script
        ClientScript.RegisterClientScriptBlock(Me.GetType(), "SessionManagementScript", script, False)
    End Sub

    Private Sub AddSessionTimeoutModal()
        ' Get current page name
        Dim currentPage As String = System.IO.Path.GetFileNameWithoutExtension(Request.Url.AbsolutePath).ToLower()

        ' Skip for login, logout, and public pages
        If currentPage = "login" OrElse currentPage = "logout" OrElse currentPage = "keepalive" OrElse currentPage = "diagnostics" Then
            Return
        End If

        ' Only add for authenticated pages where session exists
        If Session("IsAuthenticated") Is Nothing OrElse Not Convert.ToBoolean(Session("IsAuthenticated")) Then
            Return
        End If

        ' Create the Modal HTML with inline styles for self-containment
        Dim modalHtml As String = "" & _
            "<div id='timeout-modal' style='display:none; position:fixed; z-index:99999; left:0; top:0; width:100%; height:100%; overflow:auto; background-color:rgba(0,0,0,0.5);'>" & _
            "  <div style='background-color:#fefefe; margin:15% auto; padding:20px; border:1px solid #888; width:80%; max-width:400px; text-align:center; font-family:Arial, sans-serif; box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19); border-radius: 5px;'>" & _
            "    <h2 style='color: #d9534f; margin-top: 0;'>Session Expiring</h2>" & _
            "    <p style='font-size: 16px; margin: 20px 0;'>Your session is about to expire due to inactivity.</p>" & _
            "    <div style='margin: 20px 0; font-size: 18px; font-weight: bold;'>" & _
            "       Time remaining: <span class='session-timeout-display' style='color:red;'>--:--</span>" & _
            "    </div>" & _
            "    <p>Would you like to continue working?</p>" & _
            "    <br/>" & _
            "    <button type='button' onclick='extendSession()' style='padding:10px 20px; cursor:pointer; background-color: #5cb85c; color: white; border: none; border-radius: 4px; font-size: 14px; margin-right: 10px;'>Yes, Keep Working</button>" & _
            "    <button type='button' onclick='logout()' style='padding:10px 20px; cursor:pointer; background-color: #f0ad4e; color: white; border: none; border-radius: 4px; font-size: 14px;'>No, Log Out</button>" & _
            "  </div>" & _
            "</div>"

        ' Inject into the form if it exists, otherwise add to page controls
        ' Using LiteralControl to ensure raw HTML is rendered
        If Me.Form IsNot Nothing Then
            Me.Form.Controls.Add(New LiteralControl(modalHtml))
        Else
            Me.Controls.Add(New LiteralControl(modalHtml))
        End If
    End Sub

    Protected Sub ExpireCookie(cookieName As String)
        ' Utility method to expire cookies consistently
        If Request.Cookies(cookieName) IsNot Nothing Then
            Dim cookie As New HttpCookie(cookieName)
            cookie.Expires = DateTime.Now.AddDays(-1)
            cookie.Value = ""
            cookie.Path = "/"
            Response.Cookies.Add(cookie)
        End If
    End Sub
End Class