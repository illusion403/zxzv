﻿Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.Collections.Specialized
Imports System.Diagnostics
Imports System.Runtime.CompilerServices
Imports System.Data
Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Net

Public Class Display_Picture
    Inherits System.Web.UI.Page
    Private myconn As SqlConnection
    Private myda As SqlDataAdapter
    Private mycommand As SqlCommand
    Private myds As DataSet
    Private mysql As String
    Private DMS_data As String = My.Settings.DMS_data 'System.Configuration.ConfigurationSettings.AppSettings("DMS_data")
    Private DTW_data As String = My.Settings.DTW_data 'System.Configuration.ConfigurationSettings.AppSettings("DTW_data")
    Private access_from As String = My.Settings.URL_LINK 'System.Configuration.ConfigurationSettings.AppSettings("URL_LINK")
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim file_path As String = MyBase.Request.QueryString("picname").ToString.ToLower
        Dim sys_id As String = MyBase.Request.QueryString("sys_id").ToString
        Dim doc_id As String = MyBase.Request.QueryString("doc_id").ToString
        Dim sub_id As String = MyBase.Request.QueryString("sub_id").ToString
        Dim doc_no As String = MyBase.Request.QueryString("doc_no").ToString
        Dim party As String = MyBase.Request.QueryString("party").ToString
        Dim picture_name As String = ""
        Dim t_file_path As String = ""

        If (Operators.CompareString(sys_id, "", False) <> 0 And Operators.CompareString(doc_id, "", False) <> 0 And Operators.CompareString(sub_id, "", False) <> 0 And
            Operators.CompareString(doc_no, "", False) <> 0 And Operators.CompareString(party, "", False) <> 0 And Operators.CompareString(file_path, "", False) <> 0) Then
            If file_path.Split("\").Length > 1 Then
                picture_name = file_path.Split("\")(file_path.Split("\").Length - 1)
                t_file_path = file_path.Replace("\", "\\")
            Else
                picture_name = file_path.Split("/")(file_path.Split("/").Length - 1)
                t_file_path = file_path.Replace("/", "//")
            End If
            If sys_id = "1" Or sys_id = "2" Then
                Me.myconn = New SqlConnection(Me.DMS_data)
                Me.mysql = String.Concat(New String() {"SELECT doc_submain_nm FROM dbo.DMS_doc_submain WHERE (system_id = ", sys_id, ") AND (doc_main_id = ", doc_id, ") AND (doc_submain_id = ", sub_id, ") "})
                Me.myconn.Open()
                Me.mycommand = New SqlCommand(Me.mysql, Me.myconn)
                Dim submain_nm As String = Conversions.ToString(Me.mycommand.ExecuteScalar())
                Me.myconn.Close()
                submain_nm = submain_nm.Replace("&nbsp; ", "")
                If submain_nm = "" Then
                    Me.Label1.Text = "Error: ข้อมูลไม่ถูกถูกต้อง"
                    Exit Sub
                End If
                Me.myconn = New SqlConnection(Me.DTW_data)
                Me.mysql = "INSERT INTO dbo.DMS_Activity_log " &
                    "(user_name,claim_no,doc_type,doc_submain_nm,picture_name,access_from) " &
                    "VALUES('" & Me.Session("USERLOGIN") & "','" & doc_no & "','" & party & "','" & submain_nm & "','" & picture_name & "','" & access_from & "')"
                Me.myconn.Open()
                Me.mycommand = New SqlCommand(Me.mysql, Me.myconn)
                Me.mycommand.ExecuteNonQuery()
                Me.myconn.Close()
            End If
            Try
                If (Strings.InStr(1, Conversions.ToString(file_path), ".jpg", CompareMethod.Binary) <> 0 Or
                    Strings.InStr(1, Conversions.ToString(file_path), ".jpeg", CompareMethod.Binary) <> 0) Then
                    If (Operators.ConditionalCompareObjectEqual(Me.Session("AuthPrintFlag"), True, False)) Then
                        Me.Image1.Visible = False
                        Me.Label1.Text = String.Concat("<img src='", file_path, "'>")
                        Return
                    End If
                    If (Operators.ConditionalCompareObjectEqual(Me.Session("AuthPrintFlag"), False, False)) Then
                        Me.Image1.Visible = True
                        Me.Image1.ImageUrl = file_path
                        Me.Image1.Enabled = False
                    End If
                ElseIf (Strings.InStr(1, Conversions.ToString(file_path), ".pdf", CompareMethod.Binary) <> 0) Then
                    Dim path As String = file_path
                    Dim client As New WebClient()
                    Dim buffer As [Byte]() = client.DownloadData(path)

                    If buffer IsNot Nothing Then
                        Response.ContentType = "application/pdf"
                        'Response.AddHeader("content-length", buffer.Length.ToString()) text/plain
                        Response.AddHeader("Content-Disposition", "attachment; filename=" & picture_name)
                        Response.BinaryWrite(buffer)
                        Response.Flush()
                        Response.End()
                    End If
                    'ElseIf (Strings.InStr(1, Conversions.ToString(file_path), ".txt", CompareMethod.Binary) <> 0) Then
                    '    Dim path As String = file_path
                    '    Dim client As New WebClient()
                    '    Dim buffer As [Byte]() = client.DownloadData(path)

                    '    If buffer IsNot Nothing Then
                    '        Response.ContentType = "text/plain"
                    '        'Response.AddHeader("content-length", buffer.Length.ToString()) text/plain
                    '        Response.AddHeader("Content-Disposition", "attachment; filename=" & picture_name)
                    '        Response.BinaryWrite(buffer)
                    '        Response.Flush()
                    '        Response.End()
                    '    End If
                    'ElseIf (Strings.InStr(1, Conversions.ToString(file_path), ".xls", CompareMethod.Binary) <> 0) Then
                    '    Dim path As String = file_path
                    '    Dim client As New WebClient()
                    '    Dim buffer As [Byte]() = client.DownloadData(path)

                    '    If buffer IsNot Nothing Then
                    '        If Right(file_path, 3) = "xls" Then
                    '            Response.ContentType = "application/vnd.ms-excel"
                    '        Else
                    '            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    '        End If

                    '        'Response.AddHeader("content-length", buffer.Length.ToString()) text/plain
                    '        Response.AddHeader("Content-Disposition", "attachment; filename=" & picture_name)
                    '        Response.BinaryWrite(buffer)
                    '        Response.Flush()
                    '        Response.End()
                    '    End If
                    'ElseIf (Strings.InStr(1, Conversions.ToString(file_path), ".doc", CompareMethod.Binary) <> 0) Then
                    '    Dim path As String = file_path
                    '    Dim client As New WebClient()
                    '    Dim buffer As [Byte]() = client.DownloadData(path)

                    '    If buffer IsNot Nothing Then
                    '        If Right(file_path, 3) = "doc" Then
                    '            Response.ContentType = "application/msword"
                    '        Else
                    '            Response.ContentType = "application/application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    '        End If

                    '        'Response.AddHeader("content-length", buffer.Length.ToString()) text/plain
                    '        Response.AddHeader("Content-Disposition", "attachment; filename=" & picture_name)
                    '        Response.BinaryWrite(buffer)
                    '        Response.Flush()
                    '        Response.End()
                    '    End If
                ElseIf (Strings.InStr(1, Conversions.ToString(file_path), ".tif", CompareMethod.Binary) <> 0) Then
                    Dim path As String = file_path
                    Dim client As New WebClient()
                    Dim buffer As [Byte]() = client.DownloadData(path)

                    If buffer IsNot Nothing Then
                        Response.ContentType = "image/tiff"
                        Response.AddHeader("content-length", buffer.Length.ToString())
                        Response.BinaryWrite(buffer)
                        Response.Flush()
                        Response.End()
                    End If
                ElseIf (Strings.InStr(1, Conversions.ToString(file_path), ".png", CompareMethod.Binary) <> 0) Then
                    Dim path As String = file_path
                    Dim client As New WebClient()
                    Dim buffer As [Byte]() = client.DownloadData(path)

                    If buffer IsNot Nothing Then
                        Response.ContentType = "image/png"
                        Response.AddHeader("content-length", buffer.Length.ToString())
                        Response.BinaryWrite(buffer)
                        Response.Flush()
                        Response.End()
                    End If
                Else
                    System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, GetType(Page), "Script", "NewWindows('" & t_file_path & "');", True)
                End If
            Catch ex As Exception
                Me.Label1.Text = "Error: ไม่พบไฟล์ที่ต้องการ"
            End Try
        Else
            Me.Label1.Text = "Error: ข้อมูลไม่ถูกต้อง"
        End If
    End Sub

End Class
