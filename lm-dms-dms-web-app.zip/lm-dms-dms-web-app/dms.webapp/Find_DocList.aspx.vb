Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.Collections
Imports System.Collections.Specialized
Imports System.Configuration
Imports System.Data
Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Runtime.CompilerServices
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI


Public Class Find_DocList
    Inherits BasePage
    Private myconnDTW As SqlConnection
    Private myconnDMS As SqlConnection
    Private myconnMOB As SqlConnection
    Private myconnSETUP As SqlConnection
    Private mycommand As SqlCommand
    Private myda As SqlDataAdapter
    Private myds, dsSearch As DataSet
    Private myDataRow As DataRow
    Private mysql, sys_id As String
    Private DMS_data As String
    Private DTW_data As String
    Private SETUP_data As String
    Private Region As String
    Private Url_Bangkok As String
    Private Archive_Url As String

    Private Sub InitializeSettings()
        DMS_data = WebServiceUrlHelper.GetDMSData()
        DTW_data = WebServiceUrlHelper.GetDTWData()
        SETUP_data = WebServiceUrlHelper.GetSETUPData()
        Region = WebServiceUrlHelper.GetRegion()
        Url_Bangkok = WebServiceUrlHelper.GetUrlBangkok()
        Archive_Url = WebServiceUrlHelper.GetUrlBangkok()
    End Sub
    Private MySearchAegis As New wsSearchAegis.aegisWebService
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        InitializeSettings()

        Dim count As Integer
        Dim str As String
        Dim str1 As String
        Dim current As DataRow
        Dim sqlConnection As System.Data.SqlClient.SqlConnection = Nothing
        Dim str2 As String = Nothing
        Dim enumerator As IEnumerator = Nothing
        Dim str3 As String = Nothing
        Dim enumerator1 As IEnumerator = Nothing
        Me.myconnDMS = New System.Data.SqlClient.SqlConnection(Me.DMS_data)
        Me.myconnDTW = New System.Data.SqlClient.SqlConnection(Me.DTW_data)
        Me.myconnSETUP = New System.Data.SqlClient.SqlConnection(Me.SETUP_data)
        Me.sys_id = MyBase.Request.QueryString("sys_id")
        Dim item As String = ConfigurationSettings.AppSettings("WUP_data")
        Dim item1 As String = ConfigurationSettings.AppSettings("URL_LINK")
        Me.Session("dsCount") = New DataSet()
        Dim item2 As String = MyBase.Request.QueryString("doc_no")
        Me.mysql = String.Concat("SELECT top 1 DMS_system_id FROM dbo.Mapp_System_NewDMS_DMS WHERE (system_code = '", Me.sys_id, "') ")
        Try
            Me.myconnDMS = New System.Data.SqlClient.SqlConnection(Me.DMS_data)
            Me.myda = New SqlDataAdapter(Me.mysql, Me.myconnDMS)
            Me.myconnDMS.Open()
            Me.mycommand = New SqlCommand(Me.mysql, Me.myconnDMS)
            str = Me.mycommand.ExecuteScalar().ToString()
            Me.myconnDMS.Close()
        Catch exception As System.Exception
            ProjectData.SetProjectError(exception)
            If (Me.myconnDMS.State = ConnectionState.Open) Then
                Me.myconnDMS.Close()
            End If
            str = ""
            ProjectData.ClearProjectError()
        End Try
        If (Not (Operators.CompareString(str, "1", False) = 0 Or Operators.CompareString(str, "2", False) = 0 Or Operators.CompareString(str, "3", False) = 0)) Then
            MyBase.Response.Write("ไม่สามารถเข้าใช้งานระบบได้ โปรดติดต่อเจ้าหน้า IT")
            Return
        End If
        Me.dsSearch = New DataSet()
        Me.BuildPolicyData(item2, str)
        Dim str4 As String = Me.dsSearch.Tables("t_search").Rows(0)("POLICY_NO").ToString()
        Dim str5 As String = Me.dsSearch.Tables("t_search").Rows(0)("LICENSE_NO").ToString()
        Dim str6 As String = Me.dsSearch.Tables("t_search").Rows(0)("KEY_FIELD").ToString()
        str1 = If(Operators.CompareString(item1, "DMS", False) <> 0, "", "AND (ISNULL(Archive_Flag, 'N') IN ('Y', 'H')) ")
        Me.mysql = String.Concat(New String() {"SELECT ISNULL(Archive_Flag, 'N') AS Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date FROM dbo.DMS_ClaimMonitor WHERE (CLAIM_NO = '", item2, "') ", str1, "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"})
        Try
            sqlConnection = New System.Data.SqlClient.SqlConnection(item)
            Me.myda = New SqlDataAdapter(Me.mysql, sqlConnection)
            Me.myds = New DataSet()
            sqlConnection.Open()
            Me.myda.Fill(Me.myds, "t_Archive")
            sqlConnection.Close()
        Catch exception1 As System.Exception
            ProjectData.SetProjectError(exception1)
            If (sqlConnection.State = ConnectionState.Open) Then
                sqlConnection.Close()
            End If
            ProjectData.ClearProjectError()
        End Try
        Me.mysql = String.Concat(New String() {"SELECT ISNULL(Archive_Flag, 'N') AS Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date FROM dbo.DMS_maindocument WHERE (doc_no = '", item2, "') ", str1, "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"})
        Try
            Me.myconnDMS = New System.Data.SqlClient.SqlConnection(Me.DMS_data)
            Me.myda = New SqlDataAdapter(Me.mysql, Me.myconnDMS)
            Me.myconnDMS.Open()
            Me.myda.Fill(Me.myds, "t_Archive")
            Me.myconnDMS.Close()
        Catch exception2 As System.Exception
            ProjectData.SetProjectError(exception2)
            If (Me.myconnDMS.State = ConnectionState.Open) Then
                Me.myconnDMS.Close()
            End If
            ProjectData.ClearProjectError()
        End Try
        Try
            count = Me.myds.Tables("t_Archive").Rows.Count
        Catch exception3 As System.Exception
            ProjectData.SetProjectError(exception3)
            count = 0
            ProjectData.ClearProjectError()
        End Try
        If (Operators.CompareString(item1, "DMS", False) = 0) Then
            If (count = 0) Then
                MyBase.Response.Redirect(String.Concat(New String() {"ClaimMotorMain.aspx?sys_id=", str, "&doc_no=", item2, "&licenseno=", str5, "&keyfield=", str6, "&t_policy=", str4, "&url_region=", Me.Region}), False)
                Return
            End If
            Dim str7 As String = "N"
            Try
                enumerator = Me.myds.Tables("t_Archive").Rows.GetEnumerator()
                While enumerator.MoveNext()
                    current = DirectCast(enumerator.Current, DataRow)
                    If (Operators.CompareString(current("Archive_Flag").ToString(), "H", False) <> 0) Then
                        Continue While
                    End If
                    str7 = "Y"
                    str2 = current("Archive_Date").ToString()
                    GoTo Label0
                End While
            Finally
                If (TypeOf enumerator Is IDisposable) Then
                    TryCast(enumerator, IDisposable).Dispose()
                End If
            End Try
Label0:
            If (Operators.CompareString(str7, "Y", False) = 0) Then
                MyBase.Response.Write(String.Concat("ข้อมูลนี้ได้ถูกเก็บขึ้นเทปแล้ว เมื่อวันที่ ", str2, " ไม่สามารถ upload และดูเอกสารได้"))
                Return
            End If
            MyBase.Response.Redirect(String.Concat(New String() {Me.Archive_Url, "ClaimMotorMain.aspx?sys_id=", str, "&doc_no=", item2, "&licenseno=", str5, "&keyfield=", str6, "&t_policy=", str4, "&url_region=", Me.Region}), False)
            Return
        End If
        If (count = 0) Then
            MyBase.Response.Redirect(String.Concat(New String() {Me.Archive_Url, "ClaimMotorMain.aspx?sys_id=", str, "&doc_no=", item2, "&licenseno=", str5, "&keyfield=", str6, "&t_policy=", str4, "&url_region=", Me.Region}), False)
            Return
        End If
        Dim str8 As String = "N"
        Try
            enumerator1 = Me.myds.Tables("t_Archive").Rows.GetEnumerator()
            While enumerator1.MoveNext()
                current = DirectCast(enumerator1.Current, DataRow)
                If (Operators.CompareString(current("Archive_Flag").ToString(), "H", False) <> 0) Then
                    Continue While
                End If
                str8 = "Y"
                str3 = current("Archive_Date").ToString()
                GoTo Label1
            End While
        Finally
            If (TypeOf enumerator1 Is IDisposable) Then
                TryCast(enumerator1, IDisposable).Dispose()
            End If
        End Try
Label1:
        If (Operators.CompareString(str8, "Y", False) = 0) Then
            MyBase.Response.Write(String.Concat("ข้อมูลนี้ได้ถูกเก็บขึ้นเทปแล้ว เมื่อวันที่ ", str3, " ไม่สามารถ upload และดูเอกสารได้"))
            Return
        End If
        MyBase.Response.Redirect(String.Concat(New String() {"ClaimMotorMain.aspx?sys_id=", str, "&doc_no=", item2, "&licenseno=", str5, "&keyfield=", str6, "&t_policy=", str4, "&url_region=", Me.Region}), False)
    End Sub
    Private Sub BuildPolicyData(ByVal doc_no As String, ByVal sys_id As String)
        Dim objectValue As System.Data.DataRow
        Dim enumerator As IEnumerator = Nothing
        Dim enumerator1 As IEnumerator = Nothing
        Dim dataSet As System.Data.DataSet = New System.Data.DataSet()
        dataSet.Tables.Add("search_policy_claim_info")
        dataSet.Tables(0).Columns.Add("CALLER")
        dataSet.Tables(0).Columns.Add("REFERENCE_NO")
        dataSet.Tables(0).Columns.Add("POLICY_NO_PAR")
        dataSet.Tables(0).Columns.Add("CLAIM_NO_PAR")
        dataSet.Tables(0).Columns.Add("VEHICLE_PREFIX_LICENSE_NO_PAR")
        dataSet.Tables(0).Columns.Add("VEHICLE_LICENSE_NO_PAR")
        dataSet.Tables(0).Columns.Add("PROVINCE_LICENSE_NO_PAR")
        dataSet.Tables(0).Columns.Add("REFERENCE_NO_PAR")
        dataSet.Tables(0).Columns.Add("LOSS_DATE_PAR")
        Dim docNo As System.Data.DataRow = dataSet.Tables(0).NewRow()
        docNo("CALLER") = RuntimeHelpers.GetObjectValue(Me.Session("USERLOGIN"))
        docNo("REFERENCE_NO") = "123"
        docNo("REFERENCE_NO_PAR") = ""
        docNo("VEHICLE_PREFIX_LICENSE_NO_PAR") = ""
        docNo("VEHICLE_LICENSE_NO_PAR") = ""
        docNo("PROVINCE_LICENSE_NO_PAR") = ""
        docNo("POLICY_NO_PAR") = ""
        docNo("CLAIM_NO_PAR") = doc_no
        docNo("LOSS_DATE_PAR") = ""
        dataSet.Tables(0).Rows.Add(docNo)
        Dim dataSet1 As System.Data.DataSet = New System.Data.DataSet()
        dataSet1 = Me.MySearchAegis.wsSearchPolicyClaimInfo(dataSet)
        If (Operators.ConditionalCompareObjectEqual(dataSet1.Tables("ws_return_data").Rows(0)("ws_return_code"), "1", False) AndAlso dataSet1.Tables("ws_return_claim_data").Rows.Count > 0) Then
            Me.dsSearch = New System.Data.DataSet()
            Me.dsSearch.Tables.Add("t_search")
            Me.dsSearch.Tables(0).Columns.Add("POLICY_NO")
            Me.dsSearch.Tables(0).Columns.Add("LICENSE_NO")
            Me.dsSearch.Tables(0).Columns.Add("KEY_FIELD")
            Me.dsSearch.Tables(0).Columns.Add("PROVINCE_NAME")
            Me.dsSearch.Tables(0).Columns.Add("Claim_no")
            Me.dsSearch.Tables(0).Columns.Add("LICENSE_KEY")
            Try
                enumerator = dataSet1.Tables("ws_return_claim_data").Rows.GetEnumerator()
Label0:
                While enumerator.MoveNext()
                    Dim current As System.Data.DataRow = DirectCast(enumerator.Current, System.Data.DataRow)
                    Try
                        enumerator1 = dataSet1.Tables("ws_return_policy_data").Rows.GetEnumerator()
                        While enumerator1.MoveNext()
                            Dim dataRow As System.Data.DataRow = DirectCast(enumerator1.Current, System.Data.DataRow)
                            If (Not Operators.ConditionalCompareObjectEqual(current("POLICY_NO"), dataRow("POLICY_NO"), False)) Then
                                Continue While
                            End If
                            If (Not Conversions.ToBoolean(NewLateBinding.LateGet(current("claim_id"), Nothing, "StartsWith", New Object() {"A"}, Nothing, Nothing, Nothing))) Then
                                objectValue = Me.dsSearch.Tables("t_search").NewRow()
                                objectValue("POLICY_NO") = RuntimeHelpers.GetObjectValue(dataRow("POLICY_NO"))
                                objectValue("LICENSE_NO") = RuntimeHelpers.GetObjectValue(current("claim_reference_no"))
                                objectValue("KEY_FIELD") = "99"
                                objectValue("PROVINCE_NAME") = "Non"
                                objectValue("Claim_no") = RuntimeHelpers.GetObjectValue(current("Claim_no"))
                                objectValue("LICENSE_KEY") = "Non"
                                Me.dsSearch.Tables("t_search").Rows.Add(objectValue)
                                GoTo Label0
                            Else
                                Dim strArrays As String() = dataRow("policy_unit_description").ToString().Split(New Char() {"L"c})
                                Dim str As String = ""
                                Dim length As Integer = CInt(strArrays.Length) - 1
                                Dim num As Integer = 0
                                Do
                                    If (strArrays(num).StartsWith("icense:")) Then
                                        str = strArrays(num).ToString().Split(New Char() {"C"c})(0).ToString().Replace("icense: ", "").Replace(" ", "")
                                    End If
                                    num = num + 1
                                Loop While num <= length
                                objectValue = Me.dsSearch.Tables("t_search").NewRow()
                                objectValue("POLICY_NO") = RuntimeHelpers.GetObjectValue(dataRow("POLICY_NO"))
                                objectValue("LICENSE_NO") = str.Trim()
                                objectValue("KEY_FIELD") = RuntimeHelpers.GetObjectValue(dataRow("PROVINCE_LICENSE_NO_CODE"))
                                objectValue("PROVINCE_NAME") = RuntimeHelpers.GetObjectValue(dataRow("PROVINCE_LICENSE_NO_NAME"))
                                objectValue("Claim_no") = RuntimeHelpers.GetObjectValue(current("Claim_no"))
                                objectValue("LICENSE_KEY") = Operators.ConcatenateObject(str.Trim(), dataRow("PROVINCE_LICENSE_NO_CODE"))
                                Me.dsSearch.Tables("t_search").Rows.Add(objectValue)
                                GoTo Label0
                            End If
                        End While
                    Finally
                        If (TypeOf enumerator1 Is IDisposable) Then
                            TryCast(enumerator1, IDisposable).Dispose()
                        End If
                    End Try
                End While
            Finally
                If (TypeOf enumerator Is IDisposable) Then
                    TryCast(enumerator, IDisposable).Dispose()
                End If
            End Try
        End If
    End Sub

End Class
