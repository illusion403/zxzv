﻿Imports System.Web
Imports System.Web.Services

Public Class KeepAlive : Implements IHttpHandler, IRequiresSessionState

    Public Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        ' Accessing the Session object resets the sliding expiration timer.
        If context.Session IsNot Nothing Then
            Dim auth = context.Session("IsAuthenticated")

            ' Only proceed if user is authenticated
            If auth IsNot Nothing AndAlso Convert.ToBoolean(auth) Then
                ' Update the Sync Cookie
                Dim timeoutMinutes As Integer = context.Session.Timeout

                ' Calculate milliseconds since epoch (UTC to match JS Date.now())
                Dim diff = DateTime.UtcNow - New DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)
                ' Add timeout duration to current UTC time
                Dim expiryMs = CLng(diff.TotalMilliseconds) + (timeoutMinutes * 60 * 1000)

                Dim val As String = expiryMs.ToString()

                Dim cookie As New HttpCookie("SessionExpiry", val)
                cookie.Expires = DateTime.Now.AddMinutes(timeoutMinutes + 5)
                cookie.Path = "/"
                context.Response.Cookies.Add(cookie)

                context.Response.ContentType = "text/plain"
                context.Response.Write("OK")
                Return
            End If
        End If

        ' If we get here, session is invalid
        context.Response.StatusCode = 401
        context.Response.ContentType = "text/plain"
        context.Response.Write("Unauthorized")
    End Sub

    Public ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class