Imports System
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Net
Imports System.Web.Services.Protocols
Imports wsAuthen

Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Always clear old session localStorage when arriving at login page
        ' This ensures stale values from closed browser sessions don't interfere
        Dim clearScript As String = "if (typeof(Storage) !== 'undefined') { localStorage.removeItem('dms_session_expires'); }"
        ClientScript.RegisterStartupScript(Me.GetType(), "ClearStaleSessionStorage", clearScript, True)

        ' Check if user is already authenticated AND has a valid session
        If User.Identity.IsAuthenticated Then
            ' Verify that critical session data exists (not just auth cookie)
            If Session("USERLOGIN") IsNot Nothing AndAlso Not String.IsNullOrEmpty(Session("USERLOGIN").ToString()) Then
                ' Valid session exists, allow redirect
                RedirectToRequestedPage()
            Else
                ' Auth cookie exists but session expired - force re-login
                ' Clear the authentication cookie to force fresh login
                FormsAuthentication.SignOut()
                If Request.Cookies(FormsAuthentication.FormsCookieName) IsNot Nothing Then
                    Dim authCookie As New HttpCookie(FormsAuthentication.FormsCookieName)
                    authCookie.Expires = DateTime.Now.AddDays(-1)
                    Response.Cookies.Add(authCookie)
                End If
                ' Fall through to show login form
            End If
        End If

        ' Pre-populate username if provided in query string
        If Not IsPostBack Then
            ' Auto-focus on username field
            txtUsername.Focus()
        End If
    End Sub

    Protected Sub bntLogin_Click(sender As Object, e As EventArgs) Handles bntLogin.Click
        ' Validate input
        If String.IsNullOrWhiteSpace(txtUsername.Text) OrElse String.IsNullOrWhiteSpace(txtPassword.Text) Then
            lbError.Text = "Please enter both username and password."
            'lblMessage.CssClass = "message-container error"
            Return
        End If
        Try
            ' Call authentication web service
            Dim authService As New wsAuthen.Service1()
            authService.Url = WebServiceUrlHelper.GetAuthServiceUrl()
            Dim isAuthenticated As Boolean = authService.Check_UserAuthen(txtUsername.Text.Trim(), txtPassword.Text)

            If isAuthenticated Then
                ' Authentication successful
                ProcessSuccessfulLogin()
            Else
                ' Authentication failed
                lbError.Text = "Invalid username or password."
                'lblMessage.CssClass = "message-container error"
            End If
        Catch ex As SoapException
            ' Handle SOAP service exceptions
            lbError.Text = "Authentication service error: " & ex.Message
            'lblMessage.CssClass = "message-container error"
        Catch ex As WebException
            ' Handle web service connection errors
            lbError.Text = "Unable to connect to authentication service. Please try again later."
            'lblMessage.CssClass = "message-container error"
        Catch ex As Exception
            ' Handle other exceptions
            lbError.Text = "An error occurred during authentication. Please try again."
            'lblMessage.CssClass = "message-container error"
            ' Log the exception in a production environment
        End Try
    End Sub

    Private Sub ProcessSuccessfulLogin()
        ' Set authentication cookie
        FormsAuthentication.SetAuthCookie(txtUsername.Text.Trim(), False)

        ' Set IsAuthenticated flag for BasePage validation
        Session("IsAuthenticated") = True

        ' Initialize session variables
        Dim ds_tmp As New DataSet
        Session("dsCount") = ds_tmp
        Session("USERLOGIN") = txtUsername.Text.Trim()
        Session("AuthPrintFlag") = True
        Session("AuthPrevFlag") = True
        Session("AuthLoadFlag") = True
        Session("AuthAdminFlag") = True
        Session("PrevDoc") = 0

        ' Set SessionExpiry cookie for session management
        Dim timeoutMinutes As Integer = Session.Timeout
        Dim diff = DateTime.UtcNow - New DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)
        Dim expiryMs = CLng(diff.TotalMilliseconds) + (timeoutMinutes * 60 * 1000)
        Dim cookie As New HttpCookie("SessionExpiry", expiryMs.ToString())
        cookie.Expires = DateTime.Now.AddMinutes(timeoutMinutes + 5)
        cookie.Path = "/"
        Response.Cookies.Add(cookie)

        ' Redirect to default page
        RedirectToRequestedPage()
    End Sub

    Private Sub RedirectToRequestedPage()
        ' Redirect to default page
        Response.Redirect("~/Home.aspx", False)
        HttpContext.Current.ApplicationInstance.CompleteRequest()
    End Sub
End Class
