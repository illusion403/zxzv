Imports System
Imports System.Web
Imports System.Web.Security

Partial Public Class Logout
    Inherits BasePage
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Session.Clear()
        Session.Abandon()
        ExpireCookie("SessionExpiry")
        ExpireCookie("ASP.NET_SessionId")


    End Sub


End Class
