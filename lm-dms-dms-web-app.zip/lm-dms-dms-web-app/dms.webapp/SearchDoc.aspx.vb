﻿Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.Collections
Imports System.Collections.Specialized
Imports System.Configuration
Imports System.Data
Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports CLChkDate
Public Class SearchDoc
    Inherits System.Web.UI.Page
    Private myconnDTW As SqlConnection
    Private myconnDMS As SqlConnection
    Private myconnMOB As SqlConnection
    Private myconnSETUP As SqlConnection
    Private mycommand As SqlCommand
    Private myda As SqlDataAdapter
    Private myds, dsSearch As DataSet
    Private myDataRow As DataRow
    Private mysql, sys_id As String
    Private DMS_data As String = My.Settings.DMS_data 'System.Configuration.ConfigurationSettings.AppSettings("DMS_data")
    Private DTW_data As String = My.Settings.DTW_data 'System.Configuration.ConfigurationSettings.AppSettings("DTW_data")
    Private SETUP_data As String = My.Settings.SETUP_data 'System.Configuration.ConfigurationSettings.AppSettings("SETUP_data")
    Private MOB_data As String = My.Settings.MOB_data 'System.Configuration.ConfigurationSettings.AppSettings("MOB_data")
    Private MySearchAegis As New wsSearchAegis.aegisWebService
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents LB_Header1 As System.Web.UI.WebControls.Label
    Protected WithEvents LB_Header2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents TB_REF_NO As System.Web.UI.WebControls.TextBox
    Private Region As String = My.Settings.Region 'System.Configuration.ConfigurationSettings.AppSettings("Region")
    Private URL_LINK As String = My.Settings.URL_LINK 'System.Configuration.ConfigurationSettings.AppSettings("URL_LINK")
    Private Archive_Url As String
    Private Url_Bangkok As String = My.Settings.Url_Bangkok 'System.Configuration.ConfigurationSettings.AppSettings("Url_Bangkok")
    Private Url_Central As String = My.Settings.Region 'System.Configuration.ConfigurationSettings.AppSettings("Url_Central")
    Private Url_East As String = My.Settings.Url_Central 'System.Configuration.ConfigurationSettings.AppSettings("Url_East")
    Private Url_North As String = My.Settings.Url_North 'System.Configuration.ConfigurationSettings.AppSettings("Url_North")
    Private Url_Northeast As String = My.Settings.Url_Northeast 'System.Configuration.ConfigurationSettings.AppSettings("Url_Northeast")
    Private Url_South As String = My.Settings.Url_South 'System.Configuration.ConfigurationSettings.AppSettings("Url_South")

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RegularExpressionValidator1 As System.Web.UI.WebControls.RegularExpressionValidator
    Protected WithEvents RegularExpressionValidator2 As System.Web.UI.WebControls.RegularExpressionValidator
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Me.myconnDMS = New SqlConnection(Me.DMS_data)
        Me.myconnDTW = New SqlConnection(Me.DTW_data)
        Me.myconnSETUP = New SqlConnection(Me.SETUP_data)
        Me.sys_id = MyBase.Request.QueryString("sys_id")
        Dim region As String = Me.Region

        If (Operators.CompareString(region, "Bangkok", False) = 0) Then
            Me.Archive_Url = Me.Url_Bangkok
        ElseIf (Operators.CompareString(region, "Central", False) = 0) Then
            Me.Archive_Url = Me.Url_Central
        ElseIf (Operators.CompareString(region, "East", False) = 0) Then
            Me.Archive_Url = Me.Url_East
        ElseIf (Operators.CompareString(region, "North", False) = 0) Then
            Me.Archive_Url = Me.Url_North
        ElseIf (Operators.CompareString(region, "Northeast", False) = 0) Then
            Me.Archive_Url = Me.Url_Northeast
        ElseIf (Operators.CompareString(region, "South", False) = 0) Then
            Me.Archive_Url = Me.Url_South
        Else
            Me.Archive_Url = Me.Url_Bangkok
        End If
        If (Not Me.Page.IsPostBack) Then
            'Session("USERLOGIN") = "chairungreang.b"
            If (Operators.CompareString(Me.sys_id, "1", False) = 0 Or Operators.CompareString(Me.sys_id, "2", False) = 0) Then
                Me.mysql = "SELECT PROVINCE_NAME, KEY_FIELD FROM dbo.SETUP_PROVINCES"
                Me.myconnSETUP.Open()
                Me.myda = New SqlDataAdapter(Me.mysql, Me.myconnSETUP)
                Me.myds = New DataSet()
                Me.myda.Fill(Me.myds, "T_PROVINCE")
                Me.myconnSETUP.Close()
                Dim dataRow As System.Data.DataRow = Me.myds.Tables("T_PROVINCE").NewRow()
                dataRow("PROVINCE_NAME") = "ทุกจังหวัด"
                dataRow("KEY_FIELD") = "0"
                Me.myds.Tables("T_PROVINCE").Rows.Add(dataRow)
                Me.DropDownList1.DataSource = Me.myds.Tables("T_PROVINCE")
                Me.DropDownList1.DataTextField = "PROVINCE_NAME"
                Me.DropDownList1.DataValueField = "KEY_FIELD"
                Me.DropDownList1.DataBind()
                Me.DropDownList1.SelectedValue = "0"
                Me.DropDownList1.Visible = True
                Me.TextBox1.Visible = True
                Me.TextBox2.Visible = True
                Me.Label1.Visible = True
            End If
            Me.mysql = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("SELECT dbo.DMS_User_Role.*, dbo.DMS_system.system_name FROM dbo.DMS_User_Role INNER JOIN dbo.DMS_system ON DMS_User_Role.system_id = DMS_system.system_id WHERE (dbo.DMS_User_Role.User_Name = '", Me.Session("USERLOGIN")), "') "), "AND (dbo.DMS_User_Role.system_id = "), MyBase.Request.QueryString("sys_id")), ")"))
            Me.myconnDMS.Open()
            Me.myda = New SqlDataAdapter(Me.mysql, Me.myconnDMS)
            Me.myds = New DataSet()
            Me.myda.Fill(Me.myds, "T_User")
            Me.myconnDMS.Close()
            Dim str As String = MyBase.Server.MapPath("bin/dms.webapp.dll")
            Dim lastWriteTime As DateTime = (New FileInfo(str)).LastWriteTime
            Dim str1 As String = String.Concat("Version: ", lastWriteTime.ToString("yyyy.MM.dd.HH.mm.ss"))
            Dim str2 As String = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("<td style='WIDTH: 170px'><font color='#ffffff' face='MS Sans Serif' size=1><B>User: ", Me.Session("USERLOGIN")), "</B></font>"), "</td><td style='WIDTH: 180px' align='right'><font color='#ffffff' face='MS Sans Serif' size=1><B>"), str1), " </B></font></td>"))
            Me.LB_Header2.Text = ""
            Me.LB_Header1.Text = ""
            Me.LB_Header1.Text = String.Concat(Me.LB_Header1.Text, "<table border=0 width=647 cellspacing=0 cellpadding=0>")
            If URL_LINK = "DMS" Then
                Me.LB_Header1.Text = String.Concat(Me.LB_Header1.Text, "<tr bgcolor=CornflowerBlue><td style='WIDTH: 350px'><font face='MS Sans Serif' size=2><a href='", Me.Archive_Url, "home.html'><B>หน้าหลัก</B></a>")
            Else
                Me.LB_Header1.Text = String.Concat(Me.LB_Header1.Text, "<tr bgcolor=CornflowerBlue><td style='WIDTH: 350px'><font face='MS Sans Serif' size=2><a href='home.html'><B>หน้าหลัก</B></a>")
            End If
            Me.LB_Header1.Text = String.Concat(Me.LB_Header1.Text, "</font></td>", str2, "</tr></table>")
            If (Me.myds.Tables("T_User").Rows.Count = 0) Then
                Me.LB_Header2.Text = "<h1 align='center'><span class='style1'>คุณไม่ได้รับอนุญาตให้ใช้โปรแกรมนี้</span><span class='style2'></span></h1><h1 align='center' class='style2'><strong>กรุณาติดต่อ Support Team Ext.7711 </strong></h1>"
                Me.TextBox1.Visible = False
                Me.TextBox2.Visible = False
                Me.TextBox3.Visible = False
                Me.TextBox4.Visible = False
                Me.TextBox5.Visible = False
                Me.TB_REF_NO.Visible = False
                Me.Label1.Visible = False
                Me.Label3.Visible = False
                Me.Label4.Visible = False
                Me.Label5.Visible = False
                Me.DropDownList1.Visible = False
                Me.Button1.Visible = False
                Me.Button2.Visible = False
            Else
                Me.LB_Header2.Text = String.Concat(Me.LB_Header2.Text, "<table border=0 width=647 cellspacing=0 cellpadding=0>")
                Me.LB_Header2.Text = String.Concat(Me.LB_Header2.Text, "<tr bgcolor=LightSteelBlue><td style='WIDTH: 400px'><font color='#ffffff' face='MS Sans Serif' size=1><B>ค้นหาเลขที่เอกสาร</B></font></td><td style='WIDTH: 250px'><P align='right'><font color='#ffffff' face='MS Sans Serif' size=1><B>เอกสาร: ", Me.myds.Tables("T_User").Rows(0)("system_name").ToString(), "</B></font></P></td></tr></table>")
                Me.TextBox1.Visible = True
                Me.TextBox2.Visible = True
                Me.TextBox3.Visible = True
                Me.TextBox4.Visible = True
                Me.TB_REF_NO.Visible = True
                Me.Label1.Visible = True
                Me.Label3.Visible = True
                Me.Label4.Visible = True
                Me.Label5.Visible = True
                Me.DropDownList1.Visible = True
                Me.Button1.Visible = True
                Me.Button2.Visible = True
                If (sys_id <> "1") And (sys_id <> "2") Then
                    Me.TB_REF_NO.Visible = False
                    Me.Label1.Text = "ทะเบียนรถ"
                    Return
                End If
                If (sys_id = "3") Then
                    Me.DropDownList1.Visible = False
                    Me.TextBox1.Visible = False
                    Me.TextBox2.Visible = False
                    Me.Label1.Text = "Reference No"
                    Return
                End If
            End If
        End If
    End Sub
    Private Sub BuildData()
        Dim year As Integer
        Dim count As Integer
        Dim day As Integer
        Dim enumerator As IEnumerator = Nothing
        Dim enumerator1 As IEnumerator = Nothing
        Me.mysql = "SELECT dbo.POLICY_AUTO_INFO.POLICY_NO, Replace(ISNULL(dbo.POLICY_AUTO_INFO.VEHICLE_PREFIX_LICENSE_NO, ''), ' ', '') AS LICENSE_NO, dbo.POLICY_AUTO_INFO.KEY_FIELD, ISNULL(P.PROVINCE_NAME, '') AS PROVINCE_NAME, ISNULL(dbo.COSL_MASTER.CLAIM_NO, '') AS Claim_no, Replace(ISNULL(dbo.POLICY_AUTO_INFO.VEHICLE_PREFIX_LICENSE_NO, ''), ' ', '') + dbo.POLICY_AUTO_INFO.KEY_FIELD AS LICENSE_KEY FROM dbo.POLICY_AUTO_INFO INNER JOIN dbo.COSL_MASTER ON dbo.POLICY_AUTO_INFO.POLICY_NO = dbo.COSL_MASTER.POLICY_NO INNER JOIN center_setup.dbo.SETUP_MAX_ENDORSEMENT M ON dbo.POLICY_AUTO_INFO.POLICY_NO = M.POLICY_NO AND dbo.POLICY_AUTO_INFO.POLICY_ENDORSEMENT_NO = M.MAX_ENDORSEMENT LEFT OUTER JOIN center_setup.dbo.SETUP_PROVINCES P ON dbo.POLICY_AUTO_INFO.KEY_FIELD = P.KEY_FIELD WHERE (substring(dbo.POLICY_AUTO_INFO.POLICY_NO,4,2) in ('AV', 'AC')) "
        If (Me.TextBox1.Text.Trim().Length <> 0 And Me.TextBox2.Text.Trim().Length <> 0) Then
            Me.mysql = String.Concat(Me.mysql, "AND (dbo.POLICY_AUTO_INFO.VEHICLE_PREFIX_LICENSE_NO = '", Strings.Trim(String.Concat(Me.TextBox2.Text.Trim(), " ", Me.TextBox1.Text.Trim())), "') ")
        End If
        If (Operators.CompareString(Me.DropDownList1.SelectedValue, "0", False) <> 0) Then
            Me.mysql = String.Concat(Me.mysql, "AND (dbo.POLICY_AUTO_INFO.KEY_FIELD = '", Me.DropDownList1.SelectedValue, "') ")
        End If
        If (Me.TextBox3.Text.Trim().Length <> 0) Then
            Me.mysql = String.Concat(Me.mysql, "AND (dbo.POLICY_AUTO_INFO.POLICY_NO = '", Me.TextBox3.Text.Trim(), "') ")
        End If
        If (Me.TextBox4.Text.Trim().Length <> 0) Then
            Me.mysql = String.Concat(Me.mysql, "AND (dbo.COSL_MASTER.CLAIM_NO = '", Me.TextBox4.Text.Trim(), "') ")
        End If
        If (Me.TextBox5.Text.Trim().Length <> 0) Then
            Dim dateTime As System.DateTime = ChkDate.getdateIIS(Strings.Mid(Me.TextBox5.Text, 1, 2), Strings.Mid(Me.TextBox5.Text, 4, 2), Strings.Mid(Me.TextBox5.Text, 7, 4))
            If (dateTime.Year <= 2500) Then
                year = If(dateTime.Year >= 1950, dateTime.Year, dateTime.Year + 543)
            Else
                year = dateTime.Year - 543
            End If
            Dim dTWData As String = Me.DTW_data
            day = dateTime.Day + 100
            Dim str As String = ChkDate.getdate(dTWData, Strings.Right(day.ToString(), 2), Strings.Right(Conversions.ToString(dateTime.Month + 100), 2).ToString(), year.ToString().Trim())
            Me.mysql = String.Concat(Me.mysql, "AND (dbo.COSL_MASTER.LOSS_DATE = convert(datetime, '", str, " 00:00:00', 103)) ")
        End If
        Me.mysql = String.Concat(Me.mysql, "ORDER BY Replace(ISNULL(dbo.POLICY_AUTO_INFO.VEHICLE_PREFIX_LICENSE_NO, ''), ' ', '') + dbo.POLICY_AUTO_INFO.KEY_FIELD")
        Try
            Me.myconnDTW = New SqlConnection(Me.DTW_data)
            Me.myda = New SqlDataAdapter(Me.mysql, Me.myconnDTW)
            Me.dsSearch = New System.Data.DataSet()
            Me.myconnDTW.Open()
            Me.myda.Fill(Me.dsSearch, "t_search")
            Me.myconnDTW.Close()
        Catch exception1 As System.Exception
            ProjectData.SetProjectError(exception1)
            Dim exception As System.Exception = exception1
            Me.Label2.Text = exception.Message.ToString().Trim()
            Me.myconnDTW.Close()
            ProjectData.ClearProjectError()
        End Try
        Try
            count = Me.dsSearch.Tables("t_search").Rows.Count
        Catch exception2 As System.Exception
            ProjectData.SetProjectError(exception2)
            count = 0
            ProjectData.ClearProjectError()
        End Try
        If (count = 0) Then
            Dim dataSet As System.Data.DataSet = New System.Data.DataSet()
            dataSet.Tables.Add("search_policy_claim_info")
            dataSet.Tables(0).Columns.Add("CALLER")
            dataSet.Tables(0).Columns.Add("REFERENCE_NO")
            dataSet.Tables(0).Columns.Add("POLICY_NO_PAR")
            dataSet.Tables(0).Columns.Add("CLAIM_NO_PAR")
            dataSet.Tables(0).Columns.Add("VEHICLE_PREFIX_LICENSE_NO_PAR")
            dataSet.Tables(0).Columns.Add("VEHICLE_LICENSE_NO_PAR")
            dataSet.Tables(0).Columns.Add("PROVINCE_LICENSE_NO_PAR")
            dataSet.Tables(0).Columns.Add("REFERENCE_NO_PAR")
            dataSet.Tables(0).Columns.Add("LOSS_DATE_PAR")
            Dim objectValue As System.Data.DataRow = dataSet.Tables(0).NewRow()
            objectValue("CALLER") = RuntimeHelpers.GetObjectValue(Me.Session("USERLOGIN"))
            objectValue("REFERENCE_NO") = "123"
            objectValue("REFERENCE_NO_PAR") = ""
            If (Me.TextBox2.Text.Trim().Length = 0) Then
                objectValue("VEHICLE_PREFIX_LICENSE_NO_PAR") = ""
            Else
                objectValue("VEHICLE_PREFIX_LICENSE_NO_PAR") = Me.TextBox2.Text.Trim()
            End If
            If (Me.TextBox1.Text.Trim().Length = 0) Then
                objectValue("VEHICLE_LICENSE_NO_PAR") = ""
            Else
                objectValue("VEHICLE_LICENSE_NO_PAR") = Me.TextBox1.Text.Trim()
            End If
            If (Operators.CompareString(Me.DropDownList1.SelectedValue, "0", False) = 0) Then
                objectValue("PROVINCE_LICENSE_NO_PAR") = ""
            Else
                objectValue("PROVINCE_LICENSE_NO_PAR") = Me.DropDownList1.SelectedValue.ToString().Trim()
            End If
            If (Me.TextBox3.Text.Trim().Length = 0) Then
                objectValue("POLICY_NO_PAR") = ""
            Else
                objectValue("POLICY_NO_PAR") = Me.TextBox3.Text.Trim()
            End If
            If (Me.TextBox4.Text.Trim().Length = 0) Then
                objectValue("CLAIM_NO_PAR") = ""
            Else
                objectValue("CLAIM_NO_PAR") = Me.TextBox4.Text.Trim()
            End If
            If (Me.TextBox5.Text.Trim().Length = 0) Then
                objectValue("LOSS_DATE_PAR") = ""
            Else
                objectValue("LOSS_DATE_PAR") = Me.TextBox5.Text.Trim()
            End If
            dataSet.Tables(0).Rows.Add(objectValue)
            Dim dataSet1 As System.Data.DataSet = New System.Data.DataSet()
            dataSet1 = Me.MySearchAegis.wsSearchPolicyClaimInfo(dataSet)
            If (Operators.ConditionalCompareObjectEqual(dataSet1.Tables("ws_return_data").Rows(0)("ws_return_code"), "1", False) AndAlso dataSet1.Tables("ws_return_claim_data").Rows.Count > 0) Then
                Me.dsSearch = New System.Data.DataSet()
                Me.dsSearch.Tables.Add("t_search")
                Me.dsSearch.Tables(0).Columns.Add("POLICY_NO")
                Me.dsSearch.Tables(0).Columns.Add("LICENSE_NO")
                Me.dsSearch.Tables(0).Columns.Add("KEY_FIELD")
                Me.dsSearch.Tables(0).Columns.Add("PROVINCE_NAME")
                Me.dsSearch.Tables(0).Columns.Add("Claim_no")
                Me.dsSearch.Tables(0).Columns.Add("LICENSE_KEY")
                Try
                    enumerator = dataSet1.Tables("ws_return_claim_data").Rows.GetEnumerator()
Label0:
                    While enumerator.MoveNext()
                        Dim current As System.Data.DataRow = DirectCast(enumerator.Current, System.Data.DataRow)
                        Try
                            enumerator1 = dataSet1.Tables("ws_return_policy_data").Rows.GetEnumerator()
                            While enumerator1.MoveNext()
                                Dim dataRow As System.Data.DataRow = DirectCast(enumerator1.Current, System.Data.DataRow)
                                If (Not Conversions.ToBoolean(Operators.AndObject(Operators.CompareObjectEqual(current("POLICY_NO"), dataRow("POLICY_NO"), False), NewLateBinding.LateGet(current("claim_id"), Nothing, "StartsWith", New Object() {"A"}, Nothing, Nothing, Nothing)))) Then
                                    Continue While
                                End If
                                Dim strArrays As String() = dataRow("policy_unit_description").ToString().Split(New Char() {"L"c})
                                Dim str1 As String = ""
                                day = CInt(strArrays.Length) - 1
                                Dim num As Integer = 0
                                Do
                                    If (strArrays(num).StartsWith("icense:")) Then
                                        str1 = strArrays(num).ToString().Split(New Char() {"C"c})(0).ToString().Replace("icense: ", "").Replace(" ", "")
                                    End If
                                    num = num + 1
                                Loop While num <= day
                                Dim objectValue1 As System.Data.DataRow = Me.dsSearch.Tables("t_search").NewRow()
                                objectValue1("POLICY_NO") = RuntimeHelpers.GetObjectValue(dataRow("POLICY_NO"))
                                objectValue1("LICENSE_NO") = str1.Trim()
                                objectValue1("KEY_FIELD") = RuntimeHelpers.GetObjectValue(dataRow("PROVINCE_LICENSE_NO_CODE"))
                                objectValue1("PROVINCE_NAME") = RuntimeHelpers.GetObjectValue(dataRow("PROVINCE_LICENSE_NO_NAME"))
                                objectValue1("Claim_no") = RuntimeHelpers.GetObjectValue(current("Claim_no"))
                                objectValue1("LICENSE_KEY") = Operators.ConcatenateObject(str1.Trim(), dataRow("PROVINCE_LICENSE_NO_CODE"))
                                Me.dsSearch.Tables("t_search").Rows.Add(objectValue1)
                                GoTo Label0
                            End While
                        Finally
                            If (TypeOf enumerator1 Is IDisposable) Then
                                TryCast(enumerator1, IDisposable).Dispose()
                            End If
                        End Try
                    End While
                Finally
                    If (TypeOf enumerator Is IDisposable) Then
                        TryCast(enumerator, IDisposable).Dispose()
                    End If
                End Try
            End If
        End If
    End Sub
    Private Sub BuildDataNonMotor()
        Dim year As Integer
        Dim count As Integer
        Dim enumerator As IEnumerator = Nothing
        Dim enumerator1 As IEnumerator = Nothing
        Me.mysql = "SELECT C.POLICY_NO, C.CLAIM_NO, C.REFERENCE_NO AS LICENSE_NO, '99' AS KEY_FIELD, 'Non' AS PROVINCE_NAME, 'Non' AS LICENSE_KEY FROM dbo.NM_COSL_MASTER C WHERE (NOT C.POLICY_NO IS NULL) "
        If (Me.TextBox3.Text.Trim().Length <> 0) Then
            Me.mysql = String.Concat(Me.mysql, "AND (C.POLICY_NO = '", Me.TextBox3.Text.Trim(), "') ")
        End If
        If (Me.TextBox4.Text.Trim().Length <> 0) Then
            Me.mysql = String.Concat(Me.mysql, "AND (C.CLAIM_NO = '", Me.TextBox4.Text.Trim(), "') ")
        End If
        If (Me.TB_REF_NO.Text.Trim().Length <> 0) Then
            Me.mysql = String.Concat(Me.mysql, "AND (C.REFERENCE_NO LIKE '%", Me.TB_REF_NO.Text.Trim(), "%') ")
        End If
        If (Me.TextBox5.Text.Trim().Length <> 0) Then
            Dim dateTime As System.DateTime = ChkDate.getdateIIS(Strings.Mid(Me.TextBox5.Text, 1, 2), Strings.Mid(Me.TextBox5.Text, 4, 2), Strings.Mid(Me.TextBox5.Text, 7, 4))
            If (dateTime.Year <= 2500) Then
                year = If(dateTime.Year >= 1950, dateTime.Year, dateTime.Year + 543)
            Else
                year = dateTime.Year - 543
            End If
            Dim dTWData As String = Me.DTW_data
            Dim day As Integer = dateTime.Day + 100
            Dim str As String = ChkDate.getdate(dTWData, Strings.Right(day.ToString(), 2), Strings.Right(Conversions.ToString(dateTime.Month + 100), 2).ToString(), year.ToString().Trim())
            Me.mysql = String.Concat(Me.mysql, "AND (C.LOSS_DATE = convert(datetime, '", str, " 00:00:00', 103)) ")
        End If
        Me.mysql = String.Concat(Me.mysql, "ORDER BY C.POLICY_NO")
        Try
            Me.myconnDTW = New SqlConnection(Me.DTW_data)
            Me.myda = New SqlDataAdapter(Me.mysql, Me.myconnDTW)
            Me.dsSearch = New System.Data.DataSet()
            Me.myconnDTW.Open()
            Me.myda.Fill(Me.dsSearch, "t_search")
            Me.myconnDTW.Close()
        Catch exception1 As System.Exception
            ProjectData.SetProjectError(exception1)
            Dim exception As System.Exception = exception1
            Me.Label2.Text = exception.Message.ToString().Trim()
            Me.myconnDTW.Close()
            ProjectData.ClearProjectError()
        End Try
        Try
            count = Me.dsSearch.Tables("t_search").Rows.Count
        Catch exception2 As System.Exception
            ProjectData.SetProjectError(exception2)
            count = 0
            ProjectData.ClearProjectError()
        End Try
        If (count = 0) Then
            Dim dataSet As System.Data.DataSet = New System.Data.DataSet()
            dataSet.Tables.Add("search_policy_claim_info")
            dataSet.Tables(0).Columns.Add("CALLER")
            dataSet.Tables(0).Columns.Add("REFERENCE_NO")
            dataSet.Tables(0).Columns.Add("POLICY_NO_PAR")
            dataSet.Tables(0).Columns.Add("CLAIM_NO_PAR")
            dataSet.Tables(0).Columns.Add("VEHICLE_PREFIX_LICENSE_NO_PAR")
            dataSet.Tables(0).Columns.Add("VEHICLE_LICENSE_NO_PAR")
            dataSet.Tables(0).Columns.Add("PROVINCE_LICENSE_NO_PAR")
            dataSet.Tables(0).Columns.Add("REFERENCE_NO_PAR")
            dataSet.Tables(0).Columns.Add("LOSS_DATE_PAR")
            Dim objectValue As System.Data.DataRow = dataSet.Tables(0).NewRow()
            objectValue("CALLER") = RuntimeHelpers.GetObjectValue(Me.Session("USERLOGIN"))
            objectValue("REFERENCE_NO") = "123"
            objectValue("VEHICLE_PREFIX_LICENSE_NO_PAR") = ""
            objectValue("VEHICLE_LICENSE_NO_PAR") = ""
            objectValue("PROVINCE_LICENSE_NO_PAR") = ""
            If (Me.TB_REF_NO.Text.Trim().Length = 0) Then
                objectValue("REFERENCE_NO_PAR") = ""
            Else
                objectValue("REFERENCE_NO_PAR") = Me.TB_REF_NO.Text.Trim()
            End If
            If (Me.TextBox3.Text.Trim().Length = 0) Then
                objectValue("POLICY_NO_PAR") = ""
            Else
                objectValue("POLICY_NO_PAR") = Me.TextBox3.Text.Trim()
            End If
            If (Me.TextBox4.Text.Trim().Length = 0) Then
                objectValue("CLAIM_NO_PAR") = ""
            Else
                objectValue("CLAIM_NO_PAR") = Me.TextBox4.Text.Trim()
            End If
            If (Me.TextBox5.Text.Trim().Length = 0) Then
                objectValue("LOSS_DATE_PAR") = ""
            Else
                objectValue("LOSS_DATE_PAR") = Me.TextBox5.Text.Trim()
            End If
            dataSet.Tables(0).Rows.Add(objectValue)
            Dim dataSet1 As System.Data.DataSet = New System.Data.DataSet()
            dataSet1 = Me.MySearchAegis.wsSearchPolicyClaimInfo(dataSet)
            If (Operators.ConditionalCompareObjectEqual(dataSet1.Tables("ws_return_data").Rows(0)("ws_return_code"), "1", False) AndAlso dataSet1.Tables("ws_return_claim_data").Rows.Count > 0) Then
                Me.dsSearch = New System.Data.DataSet()
                Me.dsSearch.Tables.Add("t_search")
                Me.dsSearch.Tables(0).Columns.Add("POLICY_NO")
                Me.dsSearch.Tables(0).Columns.Add("LICENSE_NO")
                Me.dsSearch.Tables(0).Columns.Add("KEY_FIELD")
                Me.dsSearch.Tables(0).Columns.Add("PROVINCE_NAME")
                Me.dsSearch.Tables(0).Columns.Add("Claim_no")
                Me.dsSearch.Tables(0).Columns.Add("LICENSE_KEY")
                Try
                    enumerator = dataSet1.Tables("ws_return_claim_data").Rows.GetEnumerator()
Label0:
                    While enumerator.MoveNext()
                        Dim current As System.Data.DataRow = DirectCast(enumerator.Current, System.Data.DataRow)
                        Try
                            enumerator1 = dataSet1.Tables("ws_return_policy_data").Rows.GetEnumerator()
                            While enumerator1.MoveNext()
                                Dim dataRow As System.Data.DataRow = DirectCast(enumerator1.Current, System.Data.DataRow)
                                If (Not Conversions.ToBoolean(Operators.AndObject(Operators.CompareObjectEqual(current("POLICY_NO"), dataRow("POLICY_NO"), False), Operators.NotObject(NewLateBinding.LateGet(current("claim_id"), Nothing, "StartsWith", New Object() {"A"}, Nothing, Nothing, Nothing))))) Then
                                    Continue While
                                End If
                                Dim objectValue1 As System.Data.DataRow = Me.dsSearch.Tables("t_search").NewRow()
                                objectValue1("POLICY_NO") = RuntimeHelpers.GetObjectValue(dataRow("POLICY_NO"))
                                objectValue1("LICENSE_NO") = RuntimeHelpers.GetObjectValue(current("claim_reference_no"))
                                objectValue1("KEY_FIELD") = "99"
                                objectValue1("PROVINCE_NAME") = "Non"
                                objectValue1("Claim_no") = RuntimeHelpers.GetObjectValue(current("Claim_no"))
                                objectValue1("LICENSE_KEY") = "Non"
                                Me.dsSearch.Tables("t_search").Rows.Add(objectValue1)
                                GoTo Label0
                            End While
                        Finally
                            If (TypeOf enumerator1 Is IDisposable) Then
                                TryCast(enumerator1, IDisposable).Dispose()
                            End If
                        End Try
                    End While
                Finally
                    If (TypeOf enumerator Is IDisposable) Then
                        TryCast(enumerator, IDisposable).Dispose()
                    End If
                End Try
            End If
        End If
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim count As Integer
        Dim num As Integer
        If (Not (Operators.CompareString(Me.sys_id, "1", False) = 0 Or Operators.CompareString(Me.sys_id, "2", False) = 0)) Then
            If (Me.TextBox3.Text.Trim().Length = 0 And Me.TextBox4.Text.Trim().Length = 0 And Me.TextBox5.Text.Trim().Length = 0 And Me.TB_REF_NO.Text.Trim().Length = 0) Then
                Me.Label2.Text = "กรุณาใส่ข้อมูลที่ต้องการค้นหา"
                Return
            End If
            If (Not (Me.TextBox5.Text.Length = 10 And Operators.CompareString(Strings.Mid(Me.TextBox5.Text, 3, 1), "/", False) = 0 And Operators.CompareString(Strings.Mid(Me.TextBox5.Text, 6, 1), "/", False) = 0 And Conversion.Val(Strings.Mid(Me.TextBox5.Text, 4, 2)) <= 12 Or Me.TextBox5.Text.Length = 0)) Then
                Me.Label11.Visible = True
                Me.CleanData()
            Else
                Me.Label11.Visible = False
                Try
                    Me.dsSearch = New DataSet()
                    Me.BuildDataNonMotor()
                    Try
                        num = Me.dsSearch.Tables("t_search").Rows.Count
                    Catch exception As System.Exception
                        ProjectData.SetProjectError(exception)
                        num = 0
                        ProjectData.ClearProjectError()
                    End Try
                    If (num = 0) Then
                        Me.DataGrid1.Visible = False
                        Me.Label2.Text = "ไม่พบข้อมูลที่ต้องการค้นหา"
                    Else
                        Dim dataViews As DataView = New DataView()
                        dataViews = Me.dsSearch.Tables("t_search").DefaultView
                        Me.DataGrid1.DataSource = dataViews
                        Me.DataGrid1.Columns(2).HeaderText = "Reference No"
                        Me.DataGrid1.DataBind()
                        Me.DataGrid1.Columns(3).Visible = False
                        Me.Label2.Text = String.Concat("จำนวนรายการทั้งหมดที่ค้นหา : ", Strings.Trim(Conversion.Str(Me.dsSearch.Tables("t_search").Rows.Count)), " รายการ")
                        Me.DataGrid1.Visible = True
                    End If
                Catch exception1 As System.Exception
                    ProjectData.SetProjectError(exception1)
                    Me.DataGrid1.Visible = False
                    Me.Label2.Text = "TimeOut กรุณาลองใหม่อีกครั้ง"
                    ProjectData.ClearProjectError()
                End Try
            End If
        Else
            If (Me.TextBox1.Text.Trim().Length = 0 And Me.TextBox2.Text.Trim().Length = 0 And Me.TextBox3.Text.Trim().Length = 0 And Me.TextBox4.Text.Trim().Length = 0 And Me.TextBox5.Text.Trim().Length = 0) Then
                Me.Label2.Text = "กรุณาใส่ข้อมูลที่ต้องการค้นหา"
                Return
            End If
            If (Me.RegularExpressionValidator1.IsValid And Me.RegularExpressionValidator2.IsValid) Then
                If (Not (Me.TextBox5.Text.Length = 10 And Operators.CompareString(Strings.Mid(Me.TextBox5.Text, 3, 1), "/", False) = 0 And Operators.CompareString(Strings.Mid(Me.TextBox5.Text, 6, 1), "/", False) = 0 And Conversion.Val(Strings.Mid(Me.TextBox5.Text, 4, 2)) <= 12 Or Me.TextBox5.Text.Length = 0)) Then
                    Me.Label11.Visible = True
                    Me.CleanData()
                    Return
                End If
                Me.Label11.Visible = False
                Try
                    Me.dsSearch = New DataSet()
                    Me.BuildData()
                    Try
                        count = Me.dsSearch.Tables("t_search").Rows.Count
                    Catch exception2 As System.Exception
                        ProjectData.SetProjectError(exception2)
                        count = 0
                        ProjectData.ClearProjectError()
                    End Try
                    If (count = 0) Then
                        Me.DataGrid1.Visible = False
                        Me.Label2.Text = "ไม่พบข้อมูลที่ต้องการค้นหา"
                    Else
                        Dim defaultView As DataView = New DataView()
                        defaultView = Me.dsSearch.Tables("t_search").DefaultView
                        Me.DataGrid1.DataSource = defaultView
                        Me.DataGrid1.DataBind()
                        Me.Label2.Text = String.Concat("จำนวนรายการทั้งหมดที่ค้นหา : ", Strings.Trim(Conversion.Str(Me.dsSearch.Tables("t_search").Rows.Count)), " รายการ")
                        Me.DataGrid1.Visible = True
                    End If
                Catch exception3 As System.Exception
                    ProjectData.SetProjectError(exception3)
                    Me.DataGrid1.Visible = False
                    Me.Label2.Text = "TimeOut กรุณาลองใหม่อีกครั้ง"
                    ProjectData.ClearProjectError()
                End Try
            End If
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.CleanData()
        Me.TextBox1.Text = ""
        Me.TextBox2.Text = ""
        Me.TextBox3.Text = ""
        Me.TextBox4.Text = ""
        Me.TextBox5.Text = ""
        Me.DropDownList1.SelectedValue = "0"
    End Sub

    Private Sub CleanData()
        Me.DataGrid1.Visible = False
        Me.Label2.Text = ""
    End Sub
    Private Sub DataGrid1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGrid1.SelectedIndexChanged
        Dim count As Integer
        Dim str As String
        Dim current As DataRow
        Dim sqlConnection As System.Data.SqlClient.SqlConnection = Nothing
        Dim str1 As String = Nothing
        Dim enumerator As IEnumerator = Nothing
        Dim str2 As String = Nothing
        Dim enumerator1 As IEnumerator = Nothing
        Dim item As String = My.Settings.WUP_data 'ConfigurationSettings.AppSettings("WUP_data")
        Dim item1 As String = My.Settings.URL_LINK 'ConfigurationSettings.AppSettings("URL_LINK")
        Me.Session("dsCount") = New DataSet()
        Dim text As String = Me.DataGrid1.SelectedItem.Cells(4).Text
        Dim text1 As String = Me.DataGrid1.SelectedItem.Cells(1).Text
        Dim text2 As String = Me.DataGrid1.SelectedItem.Cells(2).Text
        Dim text3 As String = Me.DataGrid1.SelectedItem.Cells(5).Text
        Me.Session("PrevDoc") = 0
        str = If(Operators.CompareString(item1, "DMS", False) <> 0, "", "AND (ISNULL(Archive_Flag, 'N') IN ('Y', 'H')) ")
        Me.mysql = String.Concat(New String() {"SELECT ISNULL(Archive_Flag, 'N') AS Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date FROM dbo.DMS_ClaimMonitor WHERE (CLAIM_NO = '", text, "') ", str, "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"})
        Try
            sqlConnection = New System.Data.SqlClient.SqlConnection(item)
            Me.myda = New SqlDataAdapter(Me.mysql, sqlConnection)
            Me.myds = New DataSet()
            sqlConnection.Open()
            Me.myda.Fill(Me.myds, "t_Archive")
            sqlConnection.Close()
        Catch exception As System.Exception
            ProjectData.SetProjectError(exception)
            If (sqlConnection.State = ConnectionState.Open) Then
                sqlConnection.Close()
            End If
            ProjectData.ClearProjectError()
        End Try
        Me.mysql = String.Concat(New String() {"SELECT ISNULL(Archive_Flag, 'N') AS Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date FROM dbo.DMS_maindocument WHERE (doc_no = '", text, "') ", str, "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"})
        Try
            Me.myconnDMS = New System.Data.SqlClient.SqlConnection(Me.DMS_data)
            Me.myda = New SqlDataAdapter(Me.mysql, Me.myconnDMS)
            Me.myconnDMS.Open()
            Me.myda.Fill(Me.myds, "t_Archive")
            Me.myconnDMS.Close()
        Catch exception1 As System.Exception
            ProjectData.SetProjectError(exception1)
            If (Me.myconnDMS.State = ConnectionState.Open) Then
                Me.myconnDMS.Close()
            End If
            ProjectData.ClearProjectError()
        End Try
        Try
            count = Me.myds.Tables("t_Archive").Rows.Count
        Catch exception2 As System.Exception
            ProjectData.SetProjectError(exception2)
            count = 0
            ProjectData.ClearProjectError()
        End Try
        If (Operators.CompareString(item1, "DMS", False) = 0) Then
            If (count = 0) Then
                MyBase.Response.Redirect(String.Concat(New String() {"ClaimMotorMain.aspx?sys_id=", Me.sys_id, "&doc_no=", text, "&licenseno=", text2, "&keyfield=", text3, "&t_policy=", text1, "&url_region=", Me.Region}), False)
                Return
            End If
            Dim str3 As String = "N"
            Try
                enumerator = Me.myds.Tables("t_Archive").Rows.GetEnumerator()
                While enumerator.MoveNext()
                    current = DirectCast(enumerator.Current, DataRow)
                    If (Operators.CompareString(current("Archive_Flag").ToString(), "H", False) <> 0) Then
                        Continue While
                    End If
                    str3 = "Y"
                    str1 = current("Archive_Date").ToString()
                    GoTo Label0
                End While
            Finally
                If (TypeOf enumerator Is IDisposable) Then
                    TryCast(enumerator, IDisposable).Dispose()
                End If
            End Try
Label0:
            If (Operators.CompareString(str3, "Y", False) = 0) Then
                Me.Label2.Text = String.Concat("ข้อมูลนี้ได้ถูกเก็บขึ้นเทปแล้ว เมื่อวันที่ ", str1, " ไม่สามารถ upload และดูเอกสารได้")
                Return
            End If
            MyBase.Response.Redirect(String.Concat(New String() {Me.Archive_Url, "ClaimMotorMain.aspx?sys_id=", Me.sys_id, "&doc_no=", text, "&licenseno=", text2, "&keyfield=", text3, "&t_policy=", text1, "&url_region=", Me.Region}), False)
            Return
        End If
        If (count = 0) Then
            MyBase.Response.Redirect(String.Concat(New String() {Me.Archive_Url, "ClaimMotorMain.aspx?sys_id=", Me.sys_id, "&doc_no=", text, "&licenseno=", text2, "&keyfield=", text3, "&t_policy=", text1, "&url_region=", Me.Region}), False)
            Return
        End If
        Dim str4 As String = "N"
        Try
            enumerator1 = Me.myds.Tables("t_Archive").Rows.GetEnumerator()
            While enumerator1.MoveNext()
                current = DirectCast(enumerator1.Current, DataRow)
                If (Operators.CompareString(current("Archive_Flag").ToString(), "H", False) <> 0) Then
                    Continue While
                End If
                str4 = "Y"
                str2 = current("Archive_Date").ToString()
                GoTo Label1
            End While
        Finally
            If (TypeOf enumerator1 Is IDisposable) Then
                TryCast(enumerator1, IDisposable).Dispose()
            End If
        End Try
Label1:
        If (Operators.CompareString(str4, "Y", False) = 0) Then
            Me.Label2.Text = String.Concat("ข้อมูลนี้ได้ถูกเก็บขึ้นเทปแล้ว เมื่อวันที่ ", str2, " ไม่สามารถ upload และดูเอกสารได้")
            Return
        End If
        MyBase.Response.Redirect(String.Concat(New String() {"ClaimMotorMain.aspx?sys_id=", Me.sys_id, "&doc_no=", text, "&licenseno=", text2, "&keyfield=", text3, "&t_policy=", text1, "&url_region=", Me.Region}), False)
    End Sub
End Class
