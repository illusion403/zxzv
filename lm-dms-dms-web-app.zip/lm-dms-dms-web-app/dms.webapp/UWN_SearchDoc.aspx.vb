﻿Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.Collections
Imports System.Collections.Specialized
Imports System.Configuration
Imports System.Data
Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.HtmlControls
Imports System.Web.UI.WebControls
Public Class UWN_SearchDoc
    Inherits System.Web.UI.Page
    Private myconnDMS As SqlConnection
    Private myconnSETUP As SqlConnection
    Private myconnDWPROD As SqlConnection
    Private mycommand As SqlCommand
    Private myda As SqlDataAdapter
    Private myds, dsSearch As DataSet
    Private myDataRow As DataRow
    Private mysql, sys_id, act_type, act_name, l_doc_no As String
    Private DMS_data As String = My.Settings.DMS_data 'System.Configuration.ConfigurationSettings.AppSettings("DMS_data")
    Private DWPROD_data As String = My.Settings.DWPROD_data 'System.Configuration.ConfigurationSettings.AppSettings("DWPROD_data")
    Private Region As String = My.Settings.Region 'System.Configuration.ConfigurationSettings.AppSettings("Region")
    Private MySearchAegis As New wsSearchAegis.aegisWebService
    Private SETUP_data As String = My.Settings.SETUP_data 'System.Configuration.ConfigurationSettings.AppSettings("SETUP_data")
    Private URL_LINK As String = My.Settings.URL_LINK 'System.Configuration.ConfigurationSettings.AppSettings("URL_LINK")
    Private Format_date As String = My.Settings.Format_date 'System.Configuration.ConfigurationSettings.AppSettings("Format_date")
    Private Archive_Url As String
    Private Url_Bangkok As String = My.Settings.Url_Bangkok 'System.Configuration.ConfigurationSettings.AppSettings("Url_Bangkok")
    Private Url_Central As String = My.Settings.Url_Central 'System.Configuration.ConfigurationSettings.AppSettings("Url_Central")
    Private Url_East As String = My.Settings.Url_East 'System.Configuration.ConfigurationSettings.AppSettings("Url_East")
    Private Url_North As String = My.Settings.Url_North 'System.Configuration.ConfigurationSettings.AppSettings("Url_North")
    Private Url_Northeast As String = My.Settings.Url_Northeast 'System.Configuration.ConfigurationSettings.AppSettings("Url_Northeast")
    Private Url_South As String = My.Settings.Url_South 'System.Configuration.ConfigurationSettings.AppSettings("Url_South")

    Protected Sub DataGrid1_SelectedIndexChanged1(sender As Object, e As EventArgs) Handles DataGrid1.SelectedIndexChanged
        Dim count As Integer
        Dim str As String
        Dim text As String = Me.DataGrid1.SelectedItem.Cells(4).Text
        Dim text1 As String = Me.DataGrid1.SelectedItem.Cells(4).Text
        Dim str1 As String = Conversions.ToString(99999)
        Dim str2 As String = "999"
        Me.Session("PrevDoc") = 0
        str = If(Operators.CompareString(Me.URL_LINK, "DMS", False) <> 0, "", "AND (Archive_Flag = 'Y') ")
        Me.mysql = String.Concat(New String() {"SELECT Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date FROM dbo.DMS_maindocument WHERE (doc_no = '", text, "') ", str, "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"})
        Try
            Me.myconnDMS = New SqlConnection(Me.DMS_data)
            Me.myda = New SqlDataAdapter(Me.mysql, Me.myconnDMS)
            Me.myconnDMS.Open()
            Me.myda.Fill(Me.myds, "t_Archive")
            Me.myconnDMS.Close()
        Catch exception As System.Exception
            ProjectData.SetProjectError(exception)
            If (Me.myconnDMS.State = ConnectionState.Open) Then
                Me.myconnDMS.Close()
            End If
            ProjectData.ClearProjectError()
        End Try
        Try
            count = Me.myds.Tables("t_Archive").Rows.Count
        Catch exception1 As System.Exception
            ProjectData.SetProjectError(exception1)
            count = 0
            ProjectData.ClearProjectError()
        End Try
        If (Operators.CompareString(Me.URL_LINK, "DMS", False) = 0) Then
            If (count = 0) Then
                MyBase.Response.Redirect(String.Concat(New String() {"ClaimMotorMain.aspx?sys_id=", Me.sys_id, "&doc_no=", text, "&licenseno=", str1, "&keyfield=", str2, "&t_policy=", text1}), False)
                Return
            End If
            MyBase.Response.Redirect(String.Concat(New String() {Me.Archive_Url, "ClaimMotorMain.aspx?sys_id=", Me.sys_id, "&doc_no=", text, "&licenseno=", str1, "&keyfield=", str2, "&t_policy=", text1, "&url_region=", Me.Region}), False)
            Return
        End If
        If (count <> 0) Then
            MyBase.Response.Redirect(String.Concat(New String() {"ClaimMotorMain.aspx?sys_id=", Me.sys_id, "&doc_no=", text, "&licenseno=", str1, "&keyfield=", str2, "&t_policy=", text1, "&url_region=", Me.Region}), False)
            Return
        End If
        MyBase.Response.Redirect(String.Concat(New String() {Me.Archive_Url, "ClaimMotorMain.aspx?sys_id=", Me.sys_id, "&doc_no=", text, "&licenseno=", str1, "&keyfield=", str2, "&t_policy=", text1, "&url_region=", Me.Region}), False)
    End Sub

    Protected Sub BTT_CLEAN_Click1(sender As Object, e As EventArgs) Handles BTT_CLEAN.Click
        MyBase.Response.Redirect("UWN_SearchDoc.aspx?sys_id=7")
    End Sub

    Protected Sub BTT_SEARCH_Click1(sender As Object, e As EventArgs) Handles BTT_SEARCH.Click
        Dim count As Integer
        Try
            If (Me.TB_insured.Text.Trim().Length = 0 And Me.TB_policy.Text.Trim().Length = 0 And Me.TB_ref_no.Text.Trim().Length = 0) Then
                Me.Label2.Text = "กรุณาระบุเงื่อนไขในการค้นหา"
            ElseIf (Me.RegularExpressionValidator1.IsValid) Then
                Me.dsSearch = New DataSet()
                Me.BuildData()
                Try
                    count = Me.dsSearch.Tables("t_search").Rows.Count
                Catch exception As System.Exception
                    ProjectData.SetProjectError(exception)
                    count = 0
                    ProjectData.ClearProjectError()
                End Try
                If (count = 0) Then
                    Me.DataGrid1.Visible = False
                    Me.Label2.Text = "ไม่พบข้อมูลที่ต้องการค้นหา"
                Else
                    Dim dataViews As DataView = New DataView()
                    dataViews = Me.dsSearch.Tables("t_search").DefaultView
                    Me.DataGrid1.DataSource = dataViews
                    Me.DataGrid1.DataBind()
                    Me.Label2.Text = String.Concat("จำนวนรายการทั้งหมดที่ค้นหา : ", Strings.Trim(Conversion.Str(count)), " รายการ")
                    Me.DataGrid1.Visible = True
                End If
            End If
        Catch exception1 As System.Exception
            ProjectData.SetProjectError(exception1)
            Me.DataGrid1.Visible = False
            Me.Label2.Text = "TimeOut กรุณาลองใหม่อีกครั้ง"
            ProjectData.ClearProjectError()
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.myconnDMS = New SqlConnection(Me.DMS_data)
        Me.myconnSETUP = New SqlConnection(Me.SETUP_data)
        Me.myconnDWPROD = New SqlConnection(Me.DWPROD_data)
        Me.sys_id = MyBase.Request.QueryString("sys_id")
        Dim region As String = Me.Region
        If (Operators.CompareString(region, "Bangkok", False) = 0) Then
            Me.Archive_Url = Me.Url_Bangkok
        ElseIf (Operators.CompareString(region, "Central", False) = 0) Then
            Me.Archive_Url = Me.Url_Central
        ElseIf (Operators.CompareString(region, "East", False) = 0) Then
            Me.Archive_Url = Me.Url_East
        ElseIf (Operators.CompareString(region, "North", False) = 0) Then
            Me.Archive_Url = Me.Url_North
        ElseIf (Operators.CompareString(region, "Northeast", False) = 0) Then
            Me.Archive_Url = Me.Url_Northeast
        ElseIf (Operators.CompareString(region, "South", False) = 0) Then
            Me.Archive_Url = Me.Url_South
        Else
            Me.Archive_Url = Me.Url_Bangkok
        End If
        If (Not Me.Page.IsPostBack) Then
            'Session("USERLOGIN") = "chairungreang.b"
            Me.mysql = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("SELECT dbo.DMS_User_Role.*, dbo.DMS_system.system_name, YEAR(GETDATE()) AS UW_YEAR, MONTH(GETDATE()) AS UW_MONTH FROM dbo.DMS_User_Role INNER JOIN dbo.DMS_system ON DMS_User_Role.system_id = DMS_system.system_id WHERE (dbo.DMS_User_Role.User_Name = '", Me.Session("USERLOGIN")), "') "), "AND (dbo.DMS_User_Role.system_id = "), Me.sys_id), ")"))
            Me.myconnDMS.Open()
            Me.myda = New SqlDataAdapter(Me.mysql, Me.myconnDMS)
            Me.myds = New DataSet()
            Me.myda.Fill(Me.myds, "T_User")
            Me.myconnDMS.Close()
            Dim str As String = MyBase.Server.MapPath("bin/dms.webapp.dll")
            Dim lastWriteTime As DateTime = (New FileInfo(str)).LastWriteTime
            Dim str1 As String = String.Concat("Version: ", lastWriteTime.ToString("yyyy.MM.dd.HH.mm.ss"))
            Dim str2 As String = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("<td style='WIDTH: 165px'><font color='#ffffff' face='MS Sans Serif' size=1><b>User: ", Me.Session("USERLOGIN")), "</b></font>"), "</td><td style='WIDTH: 175px' align='right'><font color='#ffffff' face='MS Sans Serif' size=1><b>"), str1), " </b></font></td>"))
            Me.LB_Header2.Text = ""
            Me.LB_Header1.Text = ""
            Me.LB_Header1.Text = String.Concat(Me.LB_Header1.Text, "<table border=0 width=647 cellspacing=0 cellpadding=0>")
            If (Operators.CompareString(Me.URL_LINK, "DMS", False) <> 0) Then
                Me.LB_Header1.Text = String.Concat(Me.LB_Header1.Text, "<tr bgcolor=CornflowerBlue><td style='WIDTH: 300px'><font face='MS Sans Serif' size=2><a href='", Me.Archive_Url, "home.html'><b>หน้าหลัก</b></a>")
            Else
                Me.LB_Header1.Text = String.Concat(Me.LB_Header1.Text, "<tr bgcolor=CornflowerBlue><td style='WIDTH: 300px'><font face='MS Sans Serif' size=2><a href='home.html'><b>หน้าหลัก</b></a>")
            End If
            Me.LB_Header1.Text = String.Concat(Me.LB_Header1.Text, "</font></td>", str2, "</tr></table>")
            If (Me.myds.Tables("T_User").Rows.Count <> 0) Then
                Me.LB_Header2.Text = String.Concat(Me.LB_Header2.Text, "<table border=0 width=647 cellspacing=0 cellpadding=0>")
                Me.LB_Header2.Text = String.Concat(Me.LB_Header2.Text, "<tr bgcolor=LightSteelBlue><td style='WIDTH: 400px'><font color='#ffffff' face='MS Sans Serif' size=2><b>ค้นหาเลขที่เอกสาร</b></font></td><td style='WIDTH: 247px' align='right'><font color='#ffffff' face='MS Sans Serif' size=2><b>เอกสาร: ", Me.myds.Tables("T_User").Rows(0)("system_name").ToString(), "</b></font></td></tr></table>")
                Me.TB_policy.Visible = True
                Me.TB_insured.Visible = True
                Me.TB_ref_no.Visible = True
                Me.BTT_CLEAN.Visible = True
                Me.BTT_CLEAN.Text = "ล้างหน้าจอ"
                Return
            End If
            Me.LB_Header2.Text = "<h1 align='center'><span class='style1'>คุณไม่ได้รับอนุญาตให้ใช้โปรแกรมนี้</span><span class='style2'></span></h1><h1 align='center' class='style2'><strong>กรุณาติดต่อ Support Team Ext.7711 </strong></h1>"
            Me.TB_policy.Visible = False
            Me.TB_insured.Visible = False
            Me.TB_ref_no.Visible = False
            Me.BTT_CLEAN.Visible = False
            Me.BTT_SEARCH.Visible = False
        End If
    End Sub
    Private Sub BuildData()
        Dim enumerator As IEnumerator = Nothing
        Dim dataSet As System.Data.DataSet = New System.Data.DataSet()
        dataSet.Tables.Add("search_policy_claim_info")
        dataSet.Tables(0).Columns.Add("CALLER")
        dataSet.Tables(0).Columns.Add("REFERENCE_NO")
        dataSet.Tables(0).Columns.Add("POLICY_NO_PAR")
        dataSet.Tables(0).Columns.Add("CLAIM_NO_PAR")
        dataSet.Tables(0).Columns.Add("VEHICLE_PREFIX_LICENSE_NO_PAR")
        dataSet.Tables(0).Columns.Add("VEHICLE_LICENSE_NO_PAR")
        dataSet.Tables(0).Columns.Add("PROVINCE_LICENSE_NO_PAR")
        dataSet.Tables(0).Columns.Add("REFERENCE_NO_PAR")
        dataSet.Tables(0).Columns.Add("LOSS_DATE_PAR")
        Dim objectValue As System.Data.DataRow = dataSet.Tables(0).NewRow()
        objectValue("CALLER") = RuntimeHelpers.GetObjectValue(Me.Session("USERLOGIN"))
        objectValue("REFERENCE_NO") = "123"
        If (Me.TB_ref_no.Text.Trim().Length = 0) Then
            objectValue("REFERENCE_NO_PAR") = ""
        Else
            objectValue("REFERENCE_NO_PAR") = Me.TB_ref_no.Text.Trim()
        End If
        objectValue("VEHICLE_PREFIX_LICENSE_NO_PAR") = ""
        objectValue("VEHICLE_LICENSE_NO_PAR") = ""
        objectValue("PROVINCE_LICENSE_NO_PAR") = ""
        If (Me.TB_policy.Text.Trim().Length = 0) Then
            objectValue("POLICY_NO_PAR") = ""
        Else
            objectValue("POLICY_NO_PAR") = Me.TB_policy.Text.Trim()
        End If
        objectValue("CLAIM_NO_PAR") = ""
        dataSet.Tables(0).Rows.Add(objectValue)
        Dim dataSet1 As System.Data.DataSet = New System.Data.DataSet()
        dataSet1 = Me.MySearchAegis.wsSearchPolicyClaimInfo(dataSet)
        If (Operators.ConditionalCompareObjectEqual(dataSet1.Tables("ws_return_data").Rows(0)("ws_return_code"), "1", False) AndAlso dataSet1.Tables("ws_return_policy_data").Rows.Count > 0) Then
            Me.dsSearch = New System.Data.DataSet()
            Me.dsSearch.Tables.Add("t_search")
            Me.dsSearch.Tables(0).Columns.Add("insured_name")
            Me.dsSearch.Tables(0).Columns.Add("unit_description")
            Me.dsSearch.Tables(0).Columns.Add("policy_no")
            Me.dsSearch.Tables(0).Columns.Add("reference_no")
            Try
                enumerator = dataSet1.Tables("ws_return_policy_data").Rows.GetEnumerator()
                While enumerator.MoveNext()
                    Dim current As System.Data.DataRow = DirectCast(enumerator.Current, System.Data.DataRow)
                    Dim dataRow As System.Data.DataRow = Me.dsSearch.Tables("t_search").NewRow()
                    dataRow("insured_name") = RuntimeHelpers.GetObjectValue(current("insured_name"))
                    dataRow("unit_description") = RuntimeHelpers.GetObjectValue(current("policy_unit_description"))
                    dataRow("policy_no") = RuntimeHelpers.GetObjectValue(current("POLICY_NO"))
                    dataRow("reference_no") = ""
                    Me.dsSearch.Tables("t_search").Rows.Add(dataRow)
                End While
            Finally
                If (TypeOf enumerator Is IDisposable) Then
                    TryCast(enumerator, IDisposable).Dispose()
                End If
            End Try
        End If
    End Sub
End Class