﻿Imports System.IO

Partial Public Class ClaimsList
    Inherits System.Web.UI.Page

    Private imgFolder As String = "<img src='img/folder_create.gif' border='0' width='15' height='15' title='โหลดเอกสาร' />"
    Private aHUpload As String = "<a href=""javascript:upNewWindows('Upload.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&region={4}&party_key={5}&office_code={6}&program_nm={7}&AA={8}','670','610','yes','yes','no')"">{9}</a>"
    '"<a href=""javascript:upNewWindows('Upload.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&region={4}&party_key={5}&office_code={6}&program_nm={7}&AA={8}','670','610','yes','yes','no')"">{9}</a>"
    '"<a href=""javascript:upNewWindows('Uploader1.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&region={4}&party_key={5}&office_code={6}&program_nm={7}&AA={8}','670','610','yes','yes','no')"">{9}</a>" & _
    '<a href=""javascript:upNewWindows('Uploader2.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&region={4}&party_key={5}&office_code={6}&program_nm={7}&AA={8}','670','610','yes','yes','no')"">{9}</a>"

    Private aHShow As String = "<a href=""javascript:NewWindows('DisplayImg.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&doc_form={4}&doc_type={5}&region={6}&office_code={7}&program_nm={8}&AA={9}','735','500','yes','yes','no','{11}')"">{10}</a>"

    Private aLog As String = "(<a href='{0}frmLog.aspx?claim_corp_id={1}&claim_id={2}&claim_year={3}&claim_sequence={4}' Target='_blank'>เอกสารจาก PDA</a>)"
    Private aCus As String = "(<a href='{0}frmCustSatifaction.aspx?claim_corp_id={1}&claim_id={2}&claim_year={3}&claim_sequence={4}' Target='_blank'>เอกสารจาก PDA</a>)"
    Private aPdf As String = "(<a href='{0}{1}.pdf' Target='_blank'>Claim Card</a>)"


    Private aHDelDoc As String = "<img id='img_del_{0}' style='display:{1};' alt='' src='img\file_deleted.gif'/>"


    Private wDiv As String = "<div id='w_tree_{0}' style='display:{2};'> {1}<span style='font-size:9pt;color:#ff0000;font-family:Arial;'> (Wait...)</span></div>"
    Private aDiv As String = "<div id='a_tree_{0}' style='display:{2};'> {1}</div>"
    Private dDiv As String = "<div id='d_tree_{0}' style='display:{2};'> {1}</div>"
    Private nDiv As String = "<td> {1}</td><td> <div id='n_tree_{0}' style='display:{3};'>({2})</div></td>"


    Private tbDiv As String = "<table cellpadding ='0' cellspacing ='0' border ='0'><tr><td>{0}</td>{1}<td>{2}</td><td>{3}</td></tr></table>"
    Private sBlock As String = "block"
    Private sNone As String = "none"
    Public sForm As String


    Private sys_id As String
    Private doc_no As String
    Private policy As String
    Private region As String
    Private groupId As String

    Private licenseno As String
    Private keyfield As String

    Private office_code As String
    Private program_name As String

    Private aa As String
    Private daMenu As DA_Menu = New DA_Menu(ConfigurationSettings.AppSettings.Get("DB"))
    Private daDMS As DA_Menu = New DA_Menu(ConfigurationSettings.AppSettings.Get("DMS_data"))
    Private daWUP As DA_Menu = New DA_Menu(ConfigurationSettings.AppSettings.Get("MOB_data"))
    Private err_page As String = ConfigurationSettings.AppSettings.Get("error_page")
    Private intranet As String = ConfigurationSettings.AppSettings.Get("Intranet")

    Private MOB_Share As String = System.Configuration.ConfigurationSettings.AppSettings("MOB_Share")
    Private ClaimCard_Share As String = System.Configuration.ConfigurationSettings.AppSettings("ClaimCard_share")
    Private MEMO_share As String = System.Configuration.ConfigurationSettings.AppSettings("MEMO_share")
    Private Memo_Orj As String = System.Configuration.ConfigurationSettings.AppSettings("Memo_Orj")
    Private User_LVL As String = System.Configuration.ConfigurationSettings.AppSettings("LVL_U")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Bill()
        End If
    End Sub

    Private Sub Bill()
        Dim dt, dt1 As DataTable
        Dim doc_out As String
        Dim user As String = String.Empty
        Dim doc_lvl As String = String.Empty
        Dim ntree As Integer = 0
        Try
            sys_id = Request.QueryString("sys_id")
            doc_no = Request.QueryString("doc_no")
            licenseno = Request.QueryString("licenseno")
            keyfield = Request.QueryString("keyfield")
            policy = Request.QueryString("policy")
            region = Request.QueryString("region")
            office_code = Request.QueryString("office_code")
            program_name = Request.QueryString("program_nm")
            aa = UCase(Request.QueryString("AA"))
            If aa Is Nothing Then
                Dim auth_user() As String = Request.ServerVariables.Item("AUTH_USER").Split("\")
                aa = (auth_user(auth_user.Length - 1)).ToUpper
            End If
            If region Is Nothing Then
                region = System.Configuration.ConfigurationManager.AppSettings("Region")
            End If
            If program_name Is Nothing Then
                program_name = System.Configuration.ConfigurationManager.AppSettings("APP_CALLER")
            End If

            lbDMS.Text = System.Configuration.ConfigurationManager.AppSettings("URL_LINK")
            Dim t_archive_date As String
            If lbDMS.Text <> "DMS" Then
                t_archive_date = daDMS.getArchiveDataDMS(doc_no)
                If t_archive_date = Nothing Then
                    t_archive_date = daWUP.getArchiveDataWUP(doc_no)
                End If
                lbDMS.Text &= " เมื่อวันที่  " & t_archive_date
            End If
            If Request.QueryString("ntree") IsNot Nothing Then
                ntree = Integer.Parse(Request.QueryString("ntree")) - 1
            End If


            CType(Master, DMSMaster).setdocType = "เอกสารของเคลมเลขที่: " & doc_no

            CType(Master, DMSMaster).setHLink = "<input type='button'  onclick='clickR()'  id='lnkSearch' value='Refresh' style='width:40px;font-size:9px; font-family:Microsoft Sans Serif;height:18px;' />"
            sForm = CType(Master, DMSMaster).FormName()
            hdnlink.Value = "ClaimsList.aspx?sys_id=" & sys_id & _
                              "&doc_no=" & doc_no & "&licenseno=" & licenseno & _
                              "&keyfield=" & keyfield & "&policy=" & policy & _
                              "&region=" & region & "&office_code=" & office_code & _
                              "&program_nm=" & program_name & _
                              "&AA=" & aa & ""

            dt = daMenu.getUserRole(sys_id, aa)
            If dt.Rows.Count > 0 Then


                CType(Master, DMSMaster).setSysName = dt.Rows(0)("system_name")
                doc_lvl = dt.Rows(0)("lavel")
                groupId = daMenu.getGroupID(sys_id, aa)

                If User_LVL.IndexOf(doc_lvl) = -1 Then
                    Response.Redirect(err_page)
                End If

                If sys_id = 4 Then
                    doc_out = policy
                Else
                    doc_out = doc_no
                End If
                If doc_lvl = "U" Then
                    user = aa
                End If
                dt = daMenu.getDMS_MenuDoc(doc_out, sys_id, groupId, user)

                dt1 = daMenu.getDMS_CheckMenuDoc(sys_id, groupId)
                If dt.Rows.Count <> 0 Then
                    setTree(tvMenu, dt, dt1, doc_lvl)
                Else
                    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('ไม่พบข้อมูล');", True)
                End If
                tvMenu.Nodes(ntree).ExpandAll()
            Else
                Response.Redirect(err_page)
            End If
            ' tvMenu.TabIndex = Integer.Parse(ntree)
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub
    Private Sub setTree(ByVal tv As TreeView, ByVal dt As DataTable, ByVal dt1 As DataTable, ByVal doc_lvl As String)
        Dim tn As TreeNode = Nothing
        Dim tnc As TreeNode = Nothing
        Dim stMenu As String = String.Empty
        Dim row1() As DataRow = Nothing
        Dim row2() As DataRow = Nothing
        Dim found As Boolean = False
        Dim nData As Integer
        Dim stData As String

        hdndoc_no.Value = doc_no
        hdnpolicy.Value = policy
        hdnlicenseno.Value = licenseno
        hdnkeyfield.Value = keyfield

        For Each row As DataRow In dt.Rows
            'daMenu.getOther_MenuDoc(row, doc_no, policy, licenseno, keyfield)
            row2 = chkDocmain(sys_id, dt1)
            If row2 IsNot Nothing Then
                For Each rowIn As DataRow In row2
                    found = False
                    If rowIn("doc_main_id").ToString() = row("doc_main_id").ToString() Then
                        found = True
                        Exit For
                    End If
                Next
            Else
                found = True
            End If

            If found Then
                If stMenu <> row("doc_main_id").ToString() Then
                    stMenu = row("doc_main_id").ToString()
                    tn = New TreeNode()
                    tn.Text = row("doc_main_name").ToString() '+ "<div style ='display:none;' onclick='alert("" sss "")'>" + stMenu + "</div>"
                    tn.ToolTip = row("doc_main_name").ToString()

                    tn.PopulateOnDemand = False
                    tn.SelectAction = TreeNodeSelectAction.None
                    tvMenu.Nodes.Add(tn)
                    If row2 IsNot Nothing Then
                        row1 = chkSubmain(row("doc_main_id").ToString(), dt1)
                    Else
                        row1 = Nothing
                    End If
                End If

                If row1 IsNot Nothing Then
                    For Each rowIn As DataRow In row1
                        found = False
                        If rowIn("doc_submain_id").ToString() = row("doc_submain_id").ToString() Then
                            found = True
                            Exit For
                        End If
                    Next
                Else
                    found = True
                End If

                If found Then
                    tnc = New TreeNode()
                    tnc.PopulateOnDemand = False
                    tnc.SelectAction = TreeNodeSelectAction.None

                    If row("doc_form").ToString().Substring(0, 1) <> "H" Then
                        Dim aOther As String = disOtherLink(row("system_id").ToString(), row("doc_main_id").ToString(), row("doc_submain_id").ToString(), doc_no)

                        If row("doc_form").ToString().IndexOf("DMS") <> -1 Then


                            Dim nAmn As String = row("doc_form").ToString() & _
                                                 row("doc_main_id").ToString() & _
                                                 row("system_id").ToString() & _
                                                 row("doc_submain_id").ToString()
                            Dim sTnc As String = String.Empty
                            Dim sUpd As String = String.Empty

                            stData = discntFile(row, nAmn, dt, nData)


                            sTnc = String.Format(wDiv, nAmn, row("doc_submain_nm").ToString(), sNone)
                            If row("doc_form").ToString().ToLower().IndexOf("-memo") <> -1 Then
                                If AddMemo(nData, sys_id, row("doc_main_id").ToString(), row("doc_submain_id").ToString(), doc_no) Then
                                    nData += 1
                                End If
                            End If
                            sTnc += String.Format(aDiv, nAmn, displayImage(row("doc_submain_nm").ToString(), 1, sys_id, _
                                                                           row("doc_main_id").ToString(), row("doc_submain_id").ToString(), _
                                                                           doc_no, row("doc_form").ToString(), "0", region, _
                                                                           office_code, program_name, aa), IIf(nData > 0, sBlock, sNone))


                            sTnc += String.Format(dDiv, nAmn, row("doc_submain_nm").ToString(), IIf(nData > 0, sNone, sBlock))

                            If doc_lvl <> "V" Then
                                sUpd = displayUploads(sys_id, row("doc_main_id").ToString(), row("doc_submain_id").ToString(), doc_no, region, "", office_code, program_name, aa)
                            End If

                            tnc.Text += String.Format(tbDiv, sTnc, stData, sUpd, aOther)
                        Else

                            Dim sWait = String.Format(wDiv, row("doc_form").ToString(), row("doc_submain_nm").ToString(), sBlock)

                            Dim slink = String.Format(aDiv, row("doc_form").ToString(), displayImage(row("doc_submain_nm").ToString(), 1, sys_id, row("doc_main_id").ToString(), row("doc_submain_id").ToString(), doc_no, row("doc_form").ToString(), "0", region, office_code, program_name, aa), sNone)

                            Dim sDis = String.Format(dDiv, row("doc_form").ToString(), row("doc_submain_nm").ToString(), sNone)


                            tnc.Text += String.Format(tbDiv, sWait, "<td>" + slink + "</td>", sDis, aOther)

                            hdnTree.Value += row("doc_form").ToString() + "|"
                        End If

                    Else
                        tnc.Text = row("doc_submain_nm").ToString()
                    End If
                    tn.ChildNodes.Add(tnc)
                End If

            End If
        Next
        tv.ShowLines = True
        tv.CollapseAll()
    End Sub

    Private Function displayImage(ByVal doc_submain_nm As String, ByVal nData As Integer, ByVal sys_id As String, ByVal doc_id As String, ByVal sub_id As String, ByVal doc_no As String, ByVal doc_form As String, ByVal doc_type As String, _
                                  ByVal region As String, ByVal office_code As String, ByVal program_nm As String, ByVal aa As String)
        '' If nData > 0 Then
        ''DisplayImg.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&doc_form={4}&doc_type={5}&region={6}&office_code={7}&program_nm={8}&AA={9}
        'Return String.Format(aHShow, sys_id, doc_id, sub_id, doc_no, doc_form, doc_type, region, office_code, program_nm, aa, doc_submain_nm, doc_form + doc_id + sys_id + sub_id)
        ''Else
        ''Return doc_submain_nm
        ''End If
        If doc_form.IndexOf("LCIS") <> -1 Then
            Return String.Format(aHShow, sys_id, doc_id, sub_id, hdnpolicy.Value, doc_form, doc_type, region, office_code, program_nm, aa, doc_submain_nm, doc_form + doc_id + sys_id + sub_id)
        Else
            Return String.Format(aHShow, sys_id, doc_id, sub_id, doc_no, doc_form, doc_type, region, office_code, program_nm, aa, doc_submain_nm, doc_form + doc_id + sys_id + sub_id)
        End If


    End Function

    Private Function displayUploads(ByVal sys_id As String, ByVal doc_id As String, ByVal sub_id As String, ByVal doc_no As String, ByVal region As String, ByVal party_key As String, ByVal office_code As String, ByVal program_nm As String, ByVal aa As String)
        'Upload.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&region={4}&party_key={5}&office_code={6}&program_nm={7}&AA={8}
        Return String.Format(aHUpload, sys_id, doc_id, sub_id, doc_no, region, party_key, office_code, program_nm, aa, imgFolder)
    End Function

    Private Function displayImgDel(ByVal nDel As Integer) As String
        If nDel <> 0 Then
            Return aHDelDoc
        Else
            Return String.Empty
        End If
    End Function

    Private Function discntFile(ByVal dr As DataRow, ByVal dName As String, ByVal dt As DataTable, ByRef out As Integer) As String
        Dim stCnt As String = String.Empty
        Dim stType As String = String.Empty
        out = 0

        For i As Integer = dt.Columns("chkDoc").Ordinal + 1 To dt.Columns.Count - 1
            out += CInt(dr(i))
            stType = dt.Columns(i).ColumnName.Replace("0", "O").Replace("O", "")


            stCnt += String.Format(nDiv, dName + "_" + dt.Columns(i).ColumnName, stType, dr(i), sBlock)

            'If CInt(dr(i)) > 0 Then
            '    stCnt += String.Format(" {0} ({1}) ", dt.Columns(i).ColumnName.Substring(0, 2), dr(i))
            'End If

        Next i


        Return stCnt
    End Function
    Private Function disOtherLink(ByVal sys_id As String, ByVal doc_id As String, ByVal doc_sub As String, ByVal t_doc_no As String) As String
        Dim a As String = String.Empty
        If sys_id = "1" And doc_id = "1" And intranet = "Y" Then
            Select Case doc_sub
                Case 3
                    a = String.Format(aLog, MOB_Share, Mid(t_doc_no, 1, 2), Mid(t_doc_no, 4, 3), Mid(t_doc_no, 8, 4), Mid(t_doc_no, 13))
                Case 16
                    a = String.Format(aCus, MOB_Share, Mid(t_doc_no, 1, 2), Mid(t_doc_no, 4, 3), Mid(t_doc_no, 8, 4), Mid(t_doc_no, 13))
                Case 14
                    a = String.Format(aPdf, ClaimCard_Share, t_doc_no.Replace("-", ""))
            End Select
        End If
        Return a
    End Function
    Private Function chkDocmain(ByVal stSys As String, ByVal dt1 As DataTable) As DataRow()
        If dt1.Select("system_id = '" + stSys + "'")(0)("doc_main_id").ToString() = "0" Then
            Return Nothing
        Else
            Return dt1.Select("system_id = '" + stSys + "'")
        End If
    End Function
    Private Function chkSubmain(ByVal stMain As String, ByVal dt1 As DataTable) As DataRow()
        If dt1.Select("doc_main_id = '" + stMain + "'")(0)("doc_submain_id").ToString() = "0" Then
            Return Nothing
        Else
            Return dt1.Select("doc_main_id = '" + stMain + "'")
        End If
    End Function

    Private Function AddMemo(ByVal Cnt_Memo As Integer, ByVal sys_id As String, ByVal DocID As String, ByVal submain_memo As String, ByVal t_doc_no As String) As Boolean
        If (Cnt_Memo = 0) Then
            Dim format = Now.GetDateTimeFormats(New Globalization.CultureInfo("en-US"))
            Dim formatdate = format(65)
            Dim filedate As String
            filedate = "D" + Replace(Mid(formatdate, 1, 10), "-", "") + "T" + Mid(formatdate, 12, 8)
            filedate = filedate.Replace(":", "")
            filedate = filedate.Replace(" ", "")
            If sys_id = "1" Then
                Memo_Orj = Memo_Orj & "Memo.xls"
            ElseIf sys_id = "2" And DocID = "1" Then
                Memo_Orj = Memo_Orj & "MemoRP.xls"
            ElseIf sys_id = "2" And DocID = "2" Then
                Memo_Orj = Memo_Orj & "MemoLegal.xls"
            ElseIf sys_id = "3" Then
                Memo_Orj = Memo_Orj & "MemoNonMotor.xls"
            End If
            Dim t_date_path As String = Replace(formatdate, "-", "\").Substring(0, 8)
            Try
                If Not FileIO.FileSystem.DirectoryExists(MEMO_share & t_date_path) Then
                    FileIO.FileSystem.CreateDirectory(MEMO_share & t_date_path)
                End If
                File.Copy(Memo_Orj, MEMO_share & t_date_path & t_doc_no & filedate & "_M.xls", True)
                If Not daMenu.InsertMemo(sys_id, DocID, submain_memo, t_doc_no, filedate, aa) Then
                    File.Delete(MEMO_share & t_date_path & t_doc_no & filedate & "_M.xls")
                    Return False
                End If
            Catch ex As Exception
                Return False
            End Try
            Return True
        Else
            Return False
        End If
    End Function
End Class