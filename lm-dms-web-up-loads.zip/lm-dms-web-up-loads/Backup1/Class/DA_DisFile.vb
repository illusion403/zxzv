﻿Public Class DA_DisFile
    Private AllowedFileTypes As Dictionary(Of String, String)
    Private _serverPath As String
    Public Sub New()
        AllowedFileTypes = New Dictionary(Of String, String)
        AllowedFileTypes.Add("doc", "img\doc.jpg")
        AllowedFileTypes.Add("docx", "img\doc.jpg")
        AllowedFileTypes.Add("xls", "img\xls.jpg")
        AllowedFileTypes.Add("xlsx", "img\xls.jpg")
        AllowedFileTypes.Add("pdf", "img\pdf.jpg")
        AllowedFileTypes.Add("zip", "img\zip.jpg")
        AllowedFileTypes.Add("rar", "img\zip.jpg")
        AllowedFileTypes.Add("msg", "img\msg.jpg")
    End Sub
    Public Sub setDisImage(ByVal lstDisFile As List(Of DS_DisFile))
        For i As Integer = 0 To lstDisFile.Count - 1
            Dim fType As String = lstDisFile(i).toType()
            If AllowedFileTypes.ContainsKey(fType) Then
                lstDisFile(i).FileDis = AllowedFileTypes.Item(fType)
                lstDisFile(i).PathDis = ""
            Else
                lstDisFile(i).FileDis = lstDisFile(i).FileName
                lstDisFile(i).PathDis = lstDisFile(i).FilePath
            End If
        Next i
    End Sub
    Public Function setDisStr(ByVal lstDisFile As List(Of DS_DisFile)) As String
        Dim strFile As String = String.Empty
        For i As Integer = 0 To lstDisFile.Count - 1
            strFile &= "<li>"
            If lstDisFile(i).FileMove = True Or lstDisFile(i).FileMove = True Then
                strFile &= "<input type='checkbox' name='ImgName' onclick='onsetFile()' value='" & lstDisFile(i).FileName & "," & lstDisFile(i).PathDis & lstDisFile(i).FileDis & "," & IIf(lstDisFile(i).Msg IsNot Nothing And lstDisFile(i).Msg <> String.Empty, lstDisFile(i).Msg, String.Empty) & "' />"
            End If
            
            strFile &= "<a href=""javascript:onsend('" & lstDisFile(i).showFile() & "','" & lstDisFile(i).toType & "','" & lstDisFile(i).Pnt & "');"" name='Alertes_name' title='" & _
                       IIf(lstDisFile(i).Msg Is Nothing Or IsDBNull(lstDisFile(i).Msg), lstDisFile(i).FileDis, lstDisFile(i).Msg) & "'>" & _
                       "<img class='disp' src='" & lstDisFile(i).PathDis & lstDisFile(i).FileDis & "' alt='" & IIf(lstDisFile(i).Msg IsNot Nothing And lstDisFile(i).Msg <> String.Empty, lstDisFile(i).Msg, lstDisFile(i).FileName) & "' /></a></li> "
        Next i
        Return strFile
    End Function
    Public WriteOnly Property ServerPath() As String
        Set(ByVal value As String)
            _serverPath = value
        End Set
    End Property
End Class
