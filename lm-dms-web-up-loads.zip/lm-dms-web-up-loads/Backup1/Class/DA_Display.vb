﻿Imports WebLibrary

Public Class DA_Display
    Private sql As String
    Private dt As DataTable = Nothing
    Private conn As Database = Nothing
    Public Sub New(ByVal Confname As String)
        conn = New Database(Confname)
    End Sub

    Public Function disDMS_Header(ByVal sys_id As String, ByVal doc_id As String, ByVal sub_id As String, ByVal doc_no As String, ByVal user As String) As DataTable
        dt = New DataTable()

        sql = "SELECT D.doc_type " & _
                  "FROM dbo. DMS_loaddocument D " & _
                  "WHERE (D.system_id = @sys_id) " & _
                  "AND (D.doc_main_id = @doc_id) " & _
                  "AND (D.doc_submain_id = @sub_id) " & _
                  "AND (D.doc_no = @doc_no) " & _
                  "AND (D.delete_flag = 'N') "
        If user <> String.Empty Then
            sql &= "AND (D.create_by = '" & user & "') "
        End If
        sql &= "GROUP BY D.doc_type ORDER BY D.doc_type"

        conn.addParameterInt("@sys_id", CInt(sys_id))
        conn.addParameterInt("@doc_id", CInt(doc_id))
        conn.addParameterInt("@sub_id", CInt(sub_id))
        conn.addParameterST50("@doc_no", doc_no)
        conn.SqlQuery(sql, dt)

        Return dt
    End Function

    Public Function disDMS(ByVal sys_id As String, ByVal doc_id As String, ByVal sub_id As String, ByVal doc_no As String, ByVal user As String, ByVal doc_type As String) As DataTable
        dt = New DataTable()

        sql = "SELECT M.doc_main_name, S.doc_submain_nm, D.doc_no, D.doc_type, D.picture_no, " & _
                  "D.picture_name, D.Region, D.create_by, create_date, isnull(new_vol_flag, 'N') AS new_vol_flag ,S.doc_form,D.picture_description " & _
                  "FROM dbo. DMS_loaddocument D INNER JOIN dbo.DMS_doc_main M " & _
                  "ON D.system_id = M.system_id " & _
                  "AND D.doc_main_id = M.doc_main_id " & _
                  "INNER JOIN dbo.DMS_doc_submain S " & _
                  "ON D.system_id = S.system_id " & _
                  "AND D.doc_main_id = S.doc_main_id " & _
                  "AND D.doc_submain_id = S.doc_submain_id " & _
                  "WHERE (D.system_id = @sys_id) " & _
                  "AND (D.doc_main_id = @doc_id) " & _
                  "AND (D.doc_submain_id = @sub_id) " & _
                  "AND (D.doc_no = @doc_no) " & _
                  "AND (D.delete_flag = 'N') "
        If user <> String.Empty Then
            sql &= "AND (D.create_by = '" & user & "') "
        End If
        If doc_type <> "0" Then
            sql &= "AND (D.doc_type = '" & doc_type & "') "
        End If
        sql &= "ORDER BY M.doc_main_name, S.doc_submain_nm, D.doc_no, D.doc_type"

        conn.addParameterInt("@sys_id", CInt(sys_id))
        conn.addParameterInt("@doc_id", CInt(doc_id))
        conn.addParameterInt("@sub_id", CInt(sub_id))
        conn.addParameterST50("@doc_no", doc_no)
        conn.SqlQuery(sql, dt)

        Return dt
    End Function

    Public Function DeldisDMS(ByVal sys_id As String, ByVal doc_id As String, ByVal sub_id As String, ByVal doc_no As String, ByVal pic_nm As String, ByVal aa As String) As Integer
        dt = New DataTable()

        sql = "update dbo. DMS_loaddocument set delete_flag = 'Y' , delete_date = getdate() , delete_by = @aa " & _
                  "WHERE (system_id = @sys_id) " & _
                  "AND (doc_main_id = @doc_id) " & _
                  "AND (doc_submain_id = @sub_id) " & _
                  "AND (doc_no = @doc_no) " & _
                  "AND (picture_name = @pic_nm)"

        conn.addParameterInt("@sys_id", CInt(sys_id))
        conn.addParameterInt("@doc_id", CInt(doc_id))
        conn.addParameterInt("@sub_id", CInt(sub_id))
        conn.addParameterST50("@doc_no", doc_no)
        conn.addParameterST255("@pic_nm", pic_nm)
        conn.addParameterST255("@aa", aa)
        Return conn.SqlQuery(sql)
    End Function


    Public Function getParaNSIS(ByVal t_policy As String) As DataTable
        dt = New DataTable()

        sql = "SELECT TOP 1 REPLACE(ISNULL(VEHICLE_PREFIX_LICENSE_NO, ''), ' ', '') AS LICENSE_NO, KEY_FIELD " & _
                "FROM POLICY_AUTO_INFO " & _
                "WHERE (POLICY_NO = @t_policy) " & _
                "ORDER BY POLICY_ENDORSEMENT_NO DESC"

        conn.addParameterST50("@t_policy", t_policy)
        conn.Timeout = 120000L
        conn.SqlQuery(sql, dt)
        Return dt
    End Function

    Public Function chkAmin(ByVal aa As String, ByVal sys_id As String) As String
        'sql = "SELECT Admin " & _
        '"FROM DMS_User_Role " & _
        '"WHERE (User_Name = @aa) " & _
        '"AND (system_id = @sys_id) "

        sql = "SELECT distinct U.Admin " & _
        "FROM [I-DMS_USER]  U " & _
        " left JOIN DMS_GroupRole_Detail D on U.GroupID = D.GroupID " & _
        "WHERE (U.User_Name = @aa) " & _
        "AND (D.system_id = @sys_id) "
        conn.addParameterST50("@aa", aa)
        conn.addParameterInt("@sys_id", CInt(sys_id))
        conn.SqlQuery(sql, dt)
        If dt.Rows.Count <> 0 AndAlso IsDBNull(dt.Rows(0)(0)) = False Then
            Return dt.Rows(0)(0)
        Else
            Return String.Empty
        End If
    End Function
    Public Function Getdoc_group(ByVal sys_id As String, ByVal doc_id As String, ByVal sub_id As String) As String
        sql = "SELECT doc_group_submain " & _
        "FROM dbo.DMS_doc_submain " & _
        "WHERE (system_id = @sys_id) " & _
        "AND (doc_main_id = @doc_id) " & _
        "AND (doc_submain_id = @sub_id) "

        conn.addParameterInt("@sys_id", CInt(sys_id))
        conn.addParameterInt("@doc_id", CInt(doc_id))
        conn.addParameterInt("@sub_id", CInt(sub_id))
        conn.SqlQuery(sql, dt)
        If dt.Rows.Count <> 0 AndAlso IsDBNull(dt.Rows(0)(0)) = False Then
            Return dt.Rows(0)(0)
        Else
            Return String.Empty
        End If
    End Function

End Class
