﻿Public Class DA_File
    'Private Shared AllowedFileTypes As Dictionary(Of String, String)
    Public Shared NoneFileImg As Dictionary(Of String, String)

    Private Shared stFileInput As String = String.Empty
    Private Shared stTempDir As String = String.Empty
    Public Shared valFileSize As Integer
    Public Shared tmp_fileName As String
    Public Shared arrFile As List(Of DS_File) = New List(Of DS_File)
    Public Shared stFileTypes As String = System.Configuration.ConfigurationSettings.AppSettings("FILE_U")
    Private Shared MAX_FILE_SIZE As String = System.Configuration.ConfigurationManager.AppSettings("MAX_FILE_SIZE")


    Private Shared Sub setType()
        'AllowedFileTypes = New Dictionary(Of String, String)
        'AllowedFileTypes.Add("gif", "image/gif")
        'AllowedFileTypes.Add("jpg", "image/jpeg,image/jpeg,image/pjpeg")
        'AllowedFileTypes.Add("png", "image/png")
        'AllowedFileTypes.Add("zip", "application/octet-stream,application/x-zip-compressed")
        'AllowedFileTypes.Add("rar", "application/octet-stream")
        'AllowedFileTypes.Add("html", "text/html")
        'AllowedFileTypes.Add("txt", "text/plain")
        'AllowedFileTypes.Add("pdf", "application/pdf")
        'AllowedFileTypes.Add("mpg", "video/mpeg,video/mpg")
        'AllowedFileTypes.Add("mp3", "audio/mpeg3")
        'AllowedFileTypes.Add("xls", "application/vnd.ms-excel")
        'AllowedFileTypes.Add("doc", "application/msword")
        NoneFileImg = New Dictionary(Of String, String)
        NoneFileImg.Add("pdf", "img/pdf.jpg")
        NoneFileImg.Add("doc", "img/doc.jpg")
        NoneFileImg.Add("docx", "img/doc.jpg")
        NoneFileImg.Add("xls", "img/xls.jpg")
        NoneFileImg.Add("xlsx", "img/xls.jpg")
        NoneFileImg.Add("zip", "img/zip.jpg")
        NoneFileImg.Add("rar", "img/zip.jpg")
        NoneFileImg.Add("msg", "img/msg.jpg")
    End Sub
    'Public Shared ReadOnly Property chkFileInputClass() As String
    '    Get
    '        setType()
    '        If stFileInput = String.Empty Then
    '            For Each FileType As String In AllowedFileTypes.Values
    '                stFileInput &= String.Concat(FileType, ",")
    '            Next
    '            stFileInput = stFileInput.Substring(0, stFileInput.Length - 1)
    '        End If
    '        Return stFileInput
    '    End Get
    'End Property
    Public Shared WriteOnly Property TempDir() As String
        Set(ByVal value As String)
            stTempDir = value
        End Set
    End Property
    Public Shared Function addFile(ByVal AllFiles As HttpFileCollection, ByVal hdnDes As String) As Boolean
        If arrFile Is Nothing Then
            arrFile = New List(Of DS_File)
        End If

        Dim dtlFile() As String = hdnDes.Split(CChar(","))
        If chkFileTypeList(AllFiles) Then
            If saveFile(AllFiles, dtlFile) Then
                Return True
            Else
                DelFile()
                Return False
            End If
        Else
            Return False
        End If
    End Function
    Private Shared Function DelFile() As Boolean
        Dim found As Boolean = True
        For i As Integer = 0 To arrFile.Count - 1
            Try
                If arrFile(i).FileError Then
                    FileIO.FileSystem.DeleteFile(String.Format("{0}\{1}", stTempDir, arrFile(i).FileName))
                End If
            Catch ex As Exception
                arrFile(i).FileMsg = String.Format("{0}: {1}", arrFile(i).FileName, ex.Message)
                arrFile(i).FileError = False
                found = False
            End Try
        Next i
        Return found
    End Function
    Private Shared Function saveFile(ByVal txtFile As HttpFileCollection, ByVal dtlFile() As String) As Boolean
        Dim found As Boolean = True
        Dim nFl As Integer = arrFile.Count - 1
        For i As Integer = 0 To txtFile.Count - 1
            Try
                If arrFile(nFl).FileError Then
                    txtFile(i).SaveAs(String.Format("{0}\{1}", stTempDir, arrFile(nFl).FileName))
                    arrFile(nFl).FileMsg = String.Format("{0} saved", arrFile(nFl).FileName)
                    arrFile(nFl).DesFile = dtlFile(i)
                    arrFile(nFl).no = CStr(nFl + 1)
                End If
            Catch ex As Exception
                arrFile(nFl).FileMsg = String.Format("{0}: {1}", arrFile(nFl).FileName, ex.Message)
                arrFile(nFl).FileError = False
                found = False
            End Try
        Next i
        Return found
    End Function
    Public Shared Function chkFileSize(ByVal txtFile As HttpFileCollection) As Boolean
        Dim found As Boolean = True
        For i As Integer = 0 To txtFile.Count - 1
            Try
                valFileSize += txtFile(i).ContentLength
                If valFileSize > Val(MAX_FILE_SIZE) Then
                    'Dim scriptString As String = "<script type=text/javascript>"
                    'scriptString += "alert('ขนาดไฟล์รวมต้องไม่เกิน " + Trim(Str(Val(MAX_FILE_SIZE) / 1024)) + " KB');"
                    'scriptString += "</script>"
                    'Page.RegisterStartupScript("ShowMessage", scriptString)
                    valFileSize -= txtFile(i).ContentLength
                    found = False
                End If
            Catch ex As Exception
                found = False
            End Try
        Next i
        Return found
    End Function

    Public Shared Function chkFileSizeVal() As Integer
        Dim found As Integer = valFileSize
        Return found
    End Function

    Private Shared Function chkFileTypeList(ByVal txtFile As HttpFileCollection) As Boolean
        Dim ValidType As Boolean = True
        Dim dsFile As DS_File = Nothing
        Dim ThisFileType As String = String.Empty
        Dim found As Boolean = True
        Dim arrType() As String = stFileTypes.Split(",")
        setType()
        For i As Integer = 0 To txtFile.Count - 1
            dsFile = New DS_File()

            'For Each FileTypeList As String In AllowedFileTypes.Values()
            '    For Each FileType As String In FileTypeList.Split(CChar(","))
            '        If FileType.ToLower().Equals(txtFile(i).ContentType.ToLower()) Then
            '            ThisFileType = FileType.ToLower()
            '            ValidType = True
            '            Exit For
            '        End If
            '    Next
            '    If ValidType = True Then Exit For
            'Next
            Dim st() As String = tmp_fileName.Split(".") 'txtFile(i).FileName.Split(".")
            ThisFileType = st(st.Length - 1).ToLower()
            For Each FileType As String In arrType
                If FileType.ToLower() = st(st.Length - 1).ToLower() Then
                    ThisFileType = String.Empty
                    ValidType = False
                    Exit For
                End If
            Next
            dsFile.FileName = IO.Path.GetFileName(tmp_fileName) 'IO.Path.GetFileName(txtFile(i).FileName)
            dsFile.OFilePath = stTempDir
            dsFile.FileType = ThisFileType
            If ValidType = False Then
                dsFile.FileMsg = String.Format("{0}: Invalid File Type of {1}", dsFile.FileName, dsFile.FileType)
                dsFile.FileError = False
                found = False
            Else
                dsFile.FileError = True
            End If
            arrFile.Add(dsFile)
            ValidType = True
        Next i
        Return found
    End Function
    Public Shared ReadOnly Property FileList() As List(Of DS_File)
        Get
            Return arrFile
        End Get
    End Property
End Class