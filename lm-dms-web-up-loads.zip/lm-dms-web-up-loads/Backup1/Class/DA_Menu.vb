﻿Imports WebLibrary
Imports WebUpLoads.GetDMS_Require

Public Class DA_Menu
    Private dt As DataTable = Nothing
    Private mysql As String
    Private conn As Database = Nothing
    Private MySearchData As New ImageService1

    Private Region As String = System.Configuration.ConfigurationSettings.AppSettings("Region")
    Private EMCSRegion As String = System.Configuration.ConfigurationSettings.AppSettings("EMCSRegion")

    Public Sub New(ByVal Confname As String)
        conn = New Database(Confname)
    End Sub

    Public Function getDMS_MenuDoc(ByVal doc_no As String, ByVal sys_id As String, ByVal groupId As String, ByVal user As String) As DataTable
        dt = New DataTable()
        conn.addParameterST50("@txtdoc_no", doc_no)
        conn.addParameterST4("@txtSystemId", sys_id)
        ' conn.addParameter("@txtLavel", Database.ParaType.ParaChar, "U")
        conn.addParameterST50("@txtUser", user)
        conn.addParameter("@txtGroupId", Database.ParaType.ParaInt, CInt(groupId))
        conn.SqlQueryByStore("DMS_MenuDoc_I_DMS", dt)
        Return dt
    End Function
    Public Function getOther_MenuDoc(ByRef doc_form As String, ByVal t_doc_no As String, ByVal t_policy As String, ByVal licenseno As String, ByVal keyfield As String) As Integer
        Dim cnt_doc As Integer = 0
        Dim results As DataSet = New DataSet()
        If Mid(doc_form, 1, 3) <> "DMS" Then
            If doc_form = "NSIS" Then
                results = MySearchData.wsSearchNSIS(licenseno, keyfield)
                If results.Tables("Search_NSIS_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
                    cnt_doc = results.Tables("t_nsis").Rows.Count
                End If
            ElseIf doc_form = "LCIS" Then
                results.Tables.Add(getLCIS(t_policy))
                cnt_doc = results.Tables(0).Rows(0).Item(0).ToString.Trim
            ElseIf doc_form = "DIY" Then
                results = MySearchData.wsSearchDIY(t_doc_no)
                If results.Tables("Search_DIY_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
                    cnt_doc = results.Tables("t_diy").Rows.Count
                End If
            ElseIf doc_form = "MI" Then
                results = MySearchData.wsSearchMI(t_doc_no)
                If results.Tables("Search_MI_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
                    cnt_doc = results.Tables("t_mi").Rows.Count
                End If
                results = MySearchData.wsSearchMI_BKK(t_doc_no)
                If results.Tables("Search_MI_BKK_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
                    cnt_doc = cnt_doc + results.Tables("t_mi_bkk").Rows.Count
                End If
            ElseIf doc_form = "EMCS" Then
                If (Region = EMCSRegion) Then
                    results = MySearchData.wsSearchEMCS(t_doc_no)
                    If (results.Tables("Search_EMCS_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1") Then
                        cnt_doc = results.Tables("t_emcs").Rows.Count
                    End If
                End If
            ElseIf Mid(doc_form, 1, 5) = "PRINT" Then
                If t_policy.Trim.Length <> 0 Then
                    results = MySearchData.wsSearchPRINT(t_policy, Right(doc_form, 2))
                    If results.Tables("Search_PRINT_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
                        cnt_doc = results.Tables("t_PRINT").Rows.Count
                    End If
                End If
            Else
                Dim t_doctype, t_system_nm As String
                Select Case doc_form
                    Case "TP-DRY"
                        t_doctype = "ADJ"
                        t_system_nm = "TP-DryClaim"
                    Case "NON-EMCS"
                        t_doctype = "EIT"
                        t_system_nm = "NON-EMCS"
                    Case "TP-ECrash"
                        t_doctype = "EIT"
                        t_system_nm = "TP-ECrash"
                    Case "EIV"
                        t_doctype = "PAY"
                        t_system_nm = "E-Invoice"
                    Case "TP-EIV"
                        t_doctype = "PAY"
                        t_system_nm = "TP-EInvoice"
                    Case Else
                        t_doctype = doc_form
                        t_system_nm = "WUP"
                End Select
                results = MySearchData.wsSearchWUP(t_doc_no, t_doctype, t_system_nm)
                If results.Tables("Search_WUP_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
                    cnt_doc = results.Tables("t_wup").Rows.Count
                End If
            End If
            Return cnt_doc
        End If
    End Function

    Public Function getLCIS(ByVal t_policy As String) As DataTable
        dt = New DataTable()
        mysql = "SELECT COUNT(doc_no) AS cnt_doc " & _
                       "FROM dbo.DMS_loaddocument " & _
                       "WHERE (system_id = 4) " & _
                       "AND (doc_main_id = 2) " & _
                       "AND (doc_submain_id = 2) " & _
                       "AND (doc_no = '" & t_policy & "') " & _
                       "AND (delete_flag = 'N') "
        conn.SqlQuery(mysql, dt)
        Return dt
    End Function



    Public Function getDMS_CheckMenuDoc(ByVal sys_id As String, ByVal groupId As String) As DataTable
        dt = New DataTable()
        conn.addParameterST4("@txtSystemId", sys_id)
        '  conn.addParameter("@txtLavel", Database.ParaType.ParaChar, "U")
        conn.addParameter("@txtGroupId", Database.ParaType.ParaInt, CInt(groupId))

        conn.SqlQueryByStore("DMS_CheckMenuDoc_I_DMS", dt)
        Return dt
    End Function

    Public Function getDMS_CheckMenuDoc(ByVal sys_id As String) As String
        dt = New DataTable()
        Dim sql As String = "select system_name from DMS_system where system_id = @txtSystemId"
        conn.addParameterInt("@txtSystemId", CInt(sys_id))
        conn.SqlQuery(sql, dt)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return String.Empty
        End If

    End Function

    Public Function getGroupID(ByVal sys_id As String, ByVal uName As String) As String
        dt = New DataTable()
        Dim sql As String = "select distinct U.GroupID " & _
                            "from [I-DMS_USER] U " & _
                            "left JOIN DMS_GroupRole_Detail D on U.GroupID = D.GroupID " & _
                            "where D.system_id = @txtSystemId and U.user_name = @txtUser"



        conn.addParameterInt("@txtSystemId", CInt(sys_id))
        conn.addParameterST("@txtUser", uName, 30)
        conn.SqlQuery(sql, dt)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return String.Empty
        End If
    End Function

    Public Function getLvl(ByVal groupId As String) As String
        dt = New DataTable()
        Dim sql As String = "select top 1 Lavel from DMS_GroupRole where groupId = @groupId"
        conn.addParameterInt("@groupId", CInt(groupId))
        conn.SqlQuery(sql, dt)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return String.Empty
        End If
    End Function

    Public Function getDocSub(ByVal sys_id As String, ByVal doc_id As String, ByVal groupId As String, ByVal doc_sub As String) As DataTable
        'Dim sql As String = " select sm.Doc_submain_id,Replace(Replace(sm.doc_submain_nm,'&nbsp;', ''),' - ', '') as doc_submain_nm ,sm.split_doc_flag " & _
        '                    " From DMS_GroupRole_detail g" & _
        '                    " inner join DMS_doc_submain sm on g.system_id = sm.system_id " & _
        '                    " And g.doc_main_id = sm.doc_main_id " & _
        '                    " where  g.GroupID = @group_id" & _
        '                    " And g.System_id = @sys_id " & _
        '                    " And g.Doc_main_id = @doc_id " & _
        '                    " And sm.doc_form Like 'DMS%' " & _
        '                    " And (g.Doc_submain_id = @doc_sub " & _
        '                    " Or g.Doc_submain_id = 0)" & _
        '                    " Order By sm.Doc_submain_id"
        Dim sql As String = " select sm.Doc_submain_id," & _
                            "CASE isnull(sm.doc_group_submain, '') WHEN '' THEN '' ELSE sm.doc_group_submain + ' - ' END + " & _
                            "Replace(Replace(sm.doc_submain_nm,'&nbsp;', ''),' - ', '') as doc_submain_nm ,sm.split_doc_flag " & _
                            " From DMS_GroupRole_detail g" & _
                            " inner join DMS_doc_submain sm on g.system_id = sm.system_id " & _
                            " where  g.GroupID = @group_id" & _
                            " And g.System_id = @sys_id " & _
                            " And sm.doc_main_id = @doc_id " & _
                            " And sm.doc_form Like 'DMS%' " & _
                            " And (g.Doc_submain_id = @doc_sub " & _
                            " Or g.Doc_submain_id = 0)" & _
                            " Order By sm.Doc_submain_id"

        conn.addParameterST50("@sys_id", sys_id)
        conn.addParameterInt("@doc_id", doc_id)
        conn.addParameterInt("@doc_sub", doc_sub)
        conn.addParameterInt("@group_id", CInt(groupId))

        conn.SqlQuery(sql, dt)

        Return dt
    End Function

    Public Function getDocform(ByVal sys_id As String, ByVal doc_id As String, ByVal doc_sub As String) As String
        Dim sql As String = " select sm.doc_form " & _
                            " From DMS_doc_submain sm  " & _
                            " where sm.System_id = @sys_id " & _
                            " And sm.Doc_main_id = @doc_id " & _
                            " And sm.doc_submain_id = @doc_sub "

        conn.addParameterInt("@sys_id", sys_id)
        conn.addParameterInt("@doc_id", doc_id)
        conn.addParameterInt("@doc_sub", doc_sub)


        conn.SqlQuery(sql, dt)

        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return String.Empty
        End If
    End Function
    Public Function getDocSubSt(ByVal sys_id As String, ByVal doc_id As String, ByVal doc_sub As String) As String
        Dim sql As String = " select sm.doc_submain_nm " & _
                            " From DMS_doc_submain sm  " & _
                            " where sm.System_id = @sys_id " & _
                            " And sm.Doc_main_id = @doc_id " & _
                            " And sm.doc_submain_id = @doc_sub "

        conn.addParameterInt("@sys_id", sys_id)
        conn.addParameterInt("@doc_id", doc_id)
        conn.addParameterInt("@doc_sub", doc_sub)


        conn.SqlQuery(sql, dt)

        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return String.Empty
        End If
    End Function
    Public Function getDocMain(ByVal sys_id As String, ByVal doc_id As String, ByVal groupId As String)
        'Dim sql As String = " select m.doc_main_id,m.doc_main_name " & _
        '                    " From DMS_GroupRole_detail g " & _
        '                    " inner join DMS_doc_main m on g.System_id = m.system_id " & _
        '                    " And g.doc_main_id = m.doc_main_id " & _
        '                    " Where g.GroupID = @GroupID " & _
        '                    " And g.System_id = @sys_id " & _
        '                    " Order By m.doc_main_id "
        Dim sql As String = " select m.doc_main_id,m.doc_main_name " & _
                    " From DMS_GroupRole_detail g " & _
                    " inner join DMS_doc_main m on g.System_id = m.system_id " & _
                    " Where g.GroupID = @GroupID " & _
                    " And g.System_id = @sys_id " & _
                    " And (g.doc_main_id = @doc_id " & _
                    " or g.doc_main_id = 0) " & _
                    " Order By m.doc_main_id "

        conn.addParameterST50("@sys_id", sys_id)
        conn.addParameterST50("@doc_id", doc_id)
        conn.addParameterInt("@GroupID", CInt(groupId))

        conn.SqlQuery(sql, dt)

        Return dt
    End Function

    Public Function getDocFlag(ByVal sys_id As String, ByVal doc_main As String, ByVal doc_sub As String) As String

        Dim sql As String = " select split_doc_flag From  DMS_doc_submain sm" & _
                            " Where sm.system_id = @sys_id " & _
                            " And sm.doc_main_id = @doc_main" & _
                            " And sm.doc_submain_id = @doc_sub" & _
                            " And sm.doc_form Like 'DMS%' "

        conn.addParameterST50("@sys_id", sys_id)
        conn.addParameterST50("@doc_main", doc_main)
        conn.addParameterInt("@doc_sub", doc_sub)

        conn.SqlQuery(sql, dt)

        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return String.Empty
        End If

    End Function

    Public Function getArchiveDataDMS(ByVal doc_no As String) As String
        Dim sql As String = " select convert(varchar(10), Archive_Date, 103) As Archive_Date" & _
                            " from dbo.DMS_maindocument " & _
                            " Where doc_no = @doc_no " & _
                            " and (isnull(Archive_Flag, 'N') = 'Y')"

        conn.addParameterST50("@doc_no", doc_no)
        conn.SqlQuery(sql, dt)

        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return String.Empty
        End If

    End Function

    Public Function getArchiveDataWUP(ByVal doc_no As String) As String
        Dim sql As String = " select convert(varchar(10), Archive_Date, 103) As Archive_Date" & _
                            " from dbo.DMS_ClaimMonitor " & _
                            " Where CLAIM_NO = @doc_no " & _
                            " and (isnull(Archive_Flag, 'N') = 'Y')"

        conn.addParameterST50("@doc_no", doc_no)
        conn.SqlQuery(sql, dt)

        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return String.Empty
        End If

    End Function

    Public Function getProvince() As DataTable

        Dim myDatarow As DataRow
        dt = New DataTable()

        mysql = "select KEY_FIELD,PROVINCE_CODE,PROVINCE_NAME from SETUP_PROVINCES"
        conn.SqlQuery(mysql, dt)
        myDatarow = dt.NewRow
        myDatarow.Item("PROVINCE_NAME") = "ทุกจังหวัด"
        myDatarow.Item("KEY_FIELD") = "0"
        dt.Rows.InsertAt(myDatarow, 0)
        Return dt
    End Function
    Public Function getLob() As DataTable

        dt = New DataTable()

        mysql = "SELECT GT_KEY " & _
                "FROM dbo.SETUP_GENERAL_TABLE " & _
                "WHERE (GT_CODE = 'GINHB') " & _
                "AND (GT_DESC_1 LIKE 'ประกันภัยรถยนต์%') " & _
                "ORDER BY GT_KEY"

        conn.SqlQuery(mysql, dt)
        Return dt
    End Function
    Public Function getT_Agent(Optional ByVal search_agent As String = "") As DataTable
        Dim myDatarow As DataRow
        dt = New DataTable("T_AGENT")
        mysql = "SELECT [SubAgent Code] AS Agent_Code, LTRIM(SUBSTRING([Sub Agent Name], 9, 100)) AS Agent_Name " & _
                       "FROM dbo.DIM_AGENT_TYPE_FLV2 " & _
                       "WHERE ([Agent Type] <> 'No_A') "
        If search_agent.Trim.Length <> 0 Then
            mysql = mysql & "AND ([Sub Agent Name] like '%" & search_agent.Trim & "%') "
        End If
        mysql = mysql & "ORDER BY [SubAgent Code]"

        conn.SqlQuery(mysql, dt)

        myDatarow = dt.NewRow
        myDatarow.Item("Agent_Name") = ""
        myDatarow.Item("Agent_Code") = "--ระบุ--"
        dt.Rows.InsertAt(myDatarow, 0)

        Return dt
    End Function
    Public Function getUserRole(ByVal sys_id As String, ByVal uName As String) As DataTable
        dt = New DataTable


        'mysql = "SELECT dbo.DMS_User_Role.*, dbo.DMS_system.system_name, YEAR(GETDATE()) AS UW_YEAR, " & _
        '      " MONTH(GETDATE()) AS UW_MONTH, " & _
        '      " " & _
        '      "FROM dbo.DMS_User_Role " & _
        '      " INNER JOIN dbo.DMS_system " & _
        '      "ON DMS_User_Role.system_id = DMS_system.system_id " & _
        '      "WHERE (dbo.DMS_User_Role.User_Name = @txtUser) "

        mysql = "SELECT distinct D.system_id, U.User_Name,U.Preview,U.Upload,U.Print_doc,U.Admin,U.last_updated,U.GroupID ,G.Lavel, DS.system_name, YEAR(GETDATE()) AS UW_YEAR, " & _
                " MONTH(GETDATE()) AS UW_MONTH " & _
                " FROM [I-DMS_USER] U " & _
                "  LEFT JOIN DMS_GroupRole G ON U.groupId = G.groupId " & _
                " LEFT JOIN DMS_GroupRole_Detail D ON U.GroupId = D.GroupId " & _
                " INNER JOIN DMS_system DS " & _
                " ON D.system_id = DS.system_id " & _
                " WHERE (U.User_Name = @txtUser) "

        If sys_id IsNot Nothing AndAlso sys_id <> String.Empty Then
            mysql &= "AND (D.system_id = @txtSystemId)"
            conn.addParameterInt("@txtSystemId", CInt(sys_id))
        End If
        conn.addParameterST("@txtUser", uName, 30)
        conn.SqlQuery(mysql, dt)
        Return dt
    End Function
    'Public Function getUser(ByVal sys_id As String, ByVal uName As String) As DataTable
    '    dt = New DataTable
    '    mysql = "SELECT *,  " & _
    '          "FROM dbo.DMS_User_Role " & _
    '          "WHERE (User_Name = @txtUser) " & _
    '          "AND (system_id = @txtSystemId)"
    '    conn.addParameterInt("@txtSystemId", CInt(sys_id))
    '    conn.addParameterST("@txtUser", uName, 30)
    '    conn.SqlQuery(mysql, dt)
    '    Return dt
    'End Function
    Public Function getYear(ByVal t_year As String) As DataTable
        dt = New DataTable
        Dim row As DataRow = Nothing
        dt.Columns.Add("YearText")
        dt.Columns.Add("YearValue")
        For i As Integer = -5 To 5
            row = dt.NewRow
            row("YearText") = Trim(Str(Val(t_year) + i))
            row("YearValue") = Trim(Str(Val(t_year) + i))
            dt.Rows.Add(row)
        Next
        Return dt
    End Function
    Public Function getMonth()
        dt = New DataTable
        Dim row As DataRow = Nothing
        dt.Columns.Add("MonthText")
        dt.Columns.Add("MonthValue")
        For i As Integer = 1 To 12
            row = dt.NewRow
            row("MonthText") = String.Format("{0:00}", i)
            row("MonthValue") = String.Format("{0:00}", i)
            dt.Rows.Add(row)
        Next
        Return dt
    End Function
    Public Function InsertMemo(ByVal sys_id As String, ByVal DocID As String, ByVal submain_memo As String, ByVal t_doc_no As String, ByVal filedate As String, ByVal uName As String) As Boolean
        Try
            mysql = "INSERT INTO dbo.DMS_loaddocument " & _
                    "(system_id, doc_main_id, doc_submain_id, doc_no, doc_type, picture_no, picture_name, " & _
                    "create_date, create_by, Region, office_code, program_name, delete_flag, delete_date, delete_by, new_vol_flag) " & _
                    "VALUES (" & sys_id.Trim & ", " & DocID.Trim & ", " & Str(submain_memo).Trim & ", '" & _
                    t_doc_no.ToUpper.Trim & "', '" & _
                    "IN001', 1, '" & t_doc_no & filedate & "_M.xls" & _
                    "', GETDATE(), '" & uName & "', '" & Region & "', '" & _
                    "00', 'DMS', 'N', NULL, NULL, 'Y')"

            conn.SqlQuery(mysql)
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function

    Public Function InsertRecovery(ByVal claim_no As String, ByVal group_name As String, ByVal fast_track As String, ByVal uName As String) As Boolean
        Try
            mysql = "INSERT INTO dbo.DMS_Recovery_Detail " & _
                    "(claim_no, group_name, fast_track, create_by, update_by) " & _
                    "VALUES ('" & claim_no.ToUpper.Trim & "', '" & group_name.Trim & "', '" & fast_track.Trim & "', '" & _
                    uName.ToUpper.Trim & "', '" & uName.ToUpper.Trim & "')"
            conn.SqlQuery(mysql)
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function
    Public Function get_path(ByVal sys_id As String, ByVal region As String, ByVal Intranet_flag As String, ByVal create_date As String) As String
        Dim sql As String = ""
        If Intranet_flag = "N" Then
            sql = " SELECT external_path_name as ss FROM dbo.DMS_doc_path WHERE (system_id = @sys_id) "
        Else
            sql = " SELECT path_name as ss FROM dbo.DMS_doc_path WHERE (system_id = @sys_id) "
        End If
        If (create_date <> "") Then
            sql = String.Concat(New String() {sql, "AND (convert(varchar(10), date_st , 102) <= '", create_date, "') AND (convert(varchar(10), isnull(date_sp, getdate()) , 102) >= '", create_date, "') "})
        Else
            sql &= " AND (Region = @region) " & _
                  " AND (convert(varchar(10), date_st , 102) <= convert(varchar(10), getdate(), 102)) AND (convert(varchar(10), isnull(date_sp, getdate()) , 102) >= convert(varchar(10), getdate(), 102)) "
        End If
        conn.addParameterST50("@sys_id", sys_id)
        conn.addParameterST50("@region", region)
        conn.SqlQuery(sql, dt)

        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return String.Empty
        End If
    End Function
End Class
