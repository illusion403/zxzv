﻿Imports System.Data
Imports WebLibrary
Imports WebLibrary.Database

Public Class DA_Paper
    Dim conn As Database = New Database(System.Configuration.ConfigurationSettings.AppSettings("DB"))
    Dim dt As DataTable = Nothing
    Public Function getMasster(ByVal num As Integer) As String
        Dim obj1 As String = String.Empty
        dt = New DataTable()
        conn.SqlQuery("select * from dms_ms where ms_state = " + num.ToString(), dt)
        obj1 += "[new Option('select data',0,true),"
        For Each row As DataRow In dt.Rows
            obj1 += "new Option('" + row("ms_name").ToString() + "'," + IIf(row("ms_msg").ToString() = "1", "-", String.Empty) + row("ms_id").ToString() + "),"
        Next
        obj1 = obj1.Substring(0, obj1.Length - 1)
        obj1 += "]"
        Return obj1
    End Function
    Public Function getSeq(ByVal office_code As String, ByVal user_update As String) As String
        dt = New DataTable()
        conn.addParameterInt("@office_code", CInt(office_code))
        conn.addParameterST50("@user_update", user_update)
        conn.SqlQueryByStore("DMS_UpdatePaperSeq", dt)

        Dim con_id As String = String.Empty
        Dim row As DataRow = dt.Rows(0)
        con_id = String.Format("{0:00}-{1:0000}-{2:00000}", CInt(row("office_code").ToString()), CInt(row("seq_year").ToString()), CInt(row("seq_no").ToString()))

        Return con_id
    End Function
    Public Function insPaper(ByVal ConId As String, ByVal remark As String, ByVal createU As String) As Integer
        Dim sql As String = "insert into DMS_Paper(pp_con_id,pp_state,pp_remark,pp_create_user,pp_create_date,user_update,last_update)" & _
                            "values(@pp_con_id,'U',@pp_remark,@pp_create_user,getdate(),@user_update,getdate())"

        conn.addParameter("@pp_con_id", ParaType.ParaChar, 13, ConId)
        conn.addParameter("@pp_remark", ParaType.ParaText, remark)
        conn.addParameterST50("@user_update", createU)
        conn.addParameterST50("@pp_create_user", createU)

        Try
            Return conn.SqlQuery(sql)
        Catch ex As Exception
            Return 0
        End Try
    End Function
    Public Function insPaperDtl(ByVal ds As DS_Paper) As Integer
        Dim sql As String = "insert into DMS_Paper_Detail(pp_con_id,pp_no,pp_msg,pp_ms_id,pp_num,pp_money,user_update,last_update)" & _
                            "values(@pp_con_id,@pp_no,@pp_msg,@pp_ms_id,@pp_num,@pp_money,@user_update,getdate())"

        conn.addParameterInt("@pp_num", CInt(ds.Pnum))
        conn.addParameter("@pp_money", ParaType.ParaMoney, 8, ds.Pmoney)
        conn.addParameterInt("@pp_no", CInt(ds.No))
        conn.addParameter("@pp_con_id", ParaType.ParaChar, 13, ds.ConId)
        conn.addParameterInt("@pp_ms_id", CInt(ds.MsId))
        conn.addParameterST50("@user_update", ds.Puser)
        conn.addParameterST50("@pp_msg", ds.Msg)

        Try
            Return conn.SqlQuery(sql)
        Catch ex As Exception
            Return 0
        End Try
    End Function

    Public Function updPaper(ByVal conId As String, ByVal state As String, ByVal remark As String, ByVal pUser As String) As Integer
        Dim sql As String = " update DMS_Paper set pp_state = @pp_state,pp_remark = @pp_remark, user_update = @user_update,last_update = getdate()" & _
                            " where pp_con_id = @pp_con_id"

        conn.addParameter("@pp_state", ParaType.ParaChar, 1, state)
        conn.addParameterST50("@user_update", pUser)
        conn.addParameter("@pp_con_id", ParaType.ParaChar, 13, conId)
        conn.addParameter("@pp_remark", ParaType.ParaText, remark)
        Try
            Return conn.SqlQuery(sql)
        Catch ex As Exception
            Return 0
        End Try
    End Function
    Public Function sctPaper(ByVal conId As String) As DataTable
        dt = New DataTable()
        Dim sql As String = " select pp_con_id,pp_state,pp_remark,pp_create_user,convert(varchar,pp_create_date,103) as create_date" & _
                            " from DMS_Paper " & _
                            " where pp_con_id = @pp_con_id"

        conn.addParameter("@pp_con_id", ParaType.ParaChar, 13, conId)
        conn.SqlQuery(sql, dt)
        Return dt
    End Function
    Public Function sctPaperDtl(ByVal conId As String) As DataTable
        dt = New DataTable()
        Dim sql As String = " select (select count(*) from DMS_ms ss where  ss.ms_state = m.ms_state and ss.ms_id < m.ms_id) + 1 as  num ," & _
                            " p.pp_con_id, p.pp_no, p.pp_ms_id, p.pp_msg, p.pp_num, p.pp_money, m.ms_state" & _
                            " from DMS_Paper_Detail p" & _
                            " left join DMS_ms m on p.pp_ms_id = m.ms_id" & _
                            " where p.pp_con_id = @pp_con_id"

        conn.addParameter("@pp_con_id", ParaType.ParaChar, 13, conId)
        conn.SqlQuery(sql, dt)
        Return dt
    End Function

    Public Function delPaperDtl(ByVal conId As String) As Integer
        Dim sql As String = "delete DMS_Paper_Detail where pp_con_id = @pp_con_id"
        conn.addParameter("@pp_con_id", ParaType.ParaChar, 13, conId)
        Try
            Return conn.SqlQuery(sql)
        Catch ex As Exception
            Return 0
        End Try
    End Function
    Public Function schPaper(ByVal office_id As String, Optional ByVal stconid As String = "", Optional ByVal ststate As String = "", Optional ByVal stcreateDate As String = "") As DataTable
        dt = New DataTable()
        Dim sql As String = " select (select count(*) from DMS_Paper Ps where  Ps.pp_id < Pp.pp_id) + 1 pp_num," & _
                            " pp_con_id,pp_state,pp_create_user,pp_remark from   DMS_Paper Pp " & _
                            " where pp_state <> 'D' " 
        If office_id <> "ALL" Then
            sql += " and subString( pp_con_id ,1,2) in (" + office_id + ") "
        End If
        If stconid <> String.Empty Then
            sql += " and pp_con_id like '" + stconid + "%'"
            'sql += " and pp_con_id = @pp_con_id "
            'conn.addParameter("@pp_con_id", ParaType.ParaChar, 13, stconid)
        End If
        If stcreateDate <> String.Empty Then
            sql += " and convert(varchar,pp_create_date,103) = @pp_create_date "
            conn.addParameterST20("@pp_create_date", stcreateDate)
        End If
        If ststate <> String.Empty Then
            sql += " and pp_state in ('" + ststate + "')"
        End If
        'conn.addParameterST50("@office_id", office_id)
        conn.SqlQuery(sql, dt)
        Return dt
    End Function
    Public Function getUser(ByVal user_id As String) As DataTable
        dt = New DataTable()
        Dim sql As String = " select [user_name],gf.office_code,lvl,mail from DMS_User_Office u inner join DMS_Office_Group gf on u.office_group = gf.office_group " & _
                            " where [user_Id] = @user_Id "
        conn.addParameterST50("@user_Id", user_id)
        conn.SqlQuery(sql, dt)
        Return dt
    End Function
    Public Function getUserDMS(ByVal user_id As String) As DataTable
        dt = New DataTable()
        Dim sql As String = " select u.User_Name from [I-DMS_USER] u inner join DMS_GroupRole_Detail gr on u.GroupID = gr.GroupID " & _
                            " where u.User_Name = @user_Id " & _
                            " and gr.System_id = 6 "
        conn.addParameterST50("@user_Id", user_id)
        conn.SqlQuery(sql, dt)
        Return dt
    End Function

    Public Function getUserRole(ByVal sys_id As String, ByVal uName As String) As DataTable
        dt = New DataTable

        Dim mysql As String = "SELECT distinct D.system_id, U.User_Name,U.Preview,U.Upload,U.Print_doc,G.Lavel,U.Admin,U.last_updated,U.GroupID, DS.system_name, YEAR(GETDATE()) AS UW_YEAR, " & _
                " MONTH(GETDATE()) AS UW_MONTH " & _
                " FROM [I-DMS_USER] U " & _
                 " LEFT JOIN DMS_GroupRole G ON U.groupId = G.groupId " & _
                " LEFT JOIN DMS_GroupRole_Detail D ON U.GroupId = D.GroupId " & _
                " INNER JOIN DMS_system DS " & _
                " ON D.system_id = DS.system_id " & _
                " WHERE (U.User_Name = @txtUser) "

        If sys_id IsNot Nothing AndAlso sys_id <> String.Empty Then
            mysql &= "AND (D.system_id = @txtSystemId)"
            conn.addParameterInt("@txtSystemId", CInt(sys_id))
        End If
        conn.addParameterST("@txtUser", uName, 30)
        conn.SqlQuery(mysql, dt)
        Return dt
    End Function
End Class
