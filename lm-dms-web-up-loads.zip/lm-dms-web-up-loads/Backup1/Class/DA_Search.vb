﻿Imports WebLibrary

Public Class DA_Search
    Private dt As DataTable = Nothing
    Private MySearchAegis As New wsSearchAegis.aegisWebService
    Private conn As Database = Nothing
    Public Sub New(ByVal Confname As String)
        conn = New Database(Confname)
    End Sub
    Public Function searchClaim(ByVal ds As DS_SchPolicy) 
        Dim mysql As String
        dt = New DataTable()
        mysql = "SELECT dbo.POLICY_AUTO_INFO.POLICY_NO, " & _
        "Replace(ISNULL(dbo.POLICY_AUTO_INFO.VEHICLE_PREFIX_LICENSE_NO, ''), ' ', '') AS LICENSE_NO, " & _
        "dbo.POLICY_AUTO_INFO.KEY_FIELD, " & _
        "ISNULL(P.PROVINCE_NAME, '') AS PROVINCE_NAME, " & _
        "ISNULL(dbo.COSL_MASTER.CLAIM_NO, '') AS Claim_no, " & _
        "Replace(ISNULL(dbo.POLICY_AUTO_INFO.VEHICLE_PREFIX_LICENSE_NO, ''), ' ', '') + " & _
        "dbo.POLICY_AUTO_INFO.KEY_FIELD AS LICENSE_KEY " & _
        "FROM dbo.POLICY_AUTO_INFO INNER JOIN dbo.COSL_MASTER " & _
        "ON dbo.POLICY_AUTO_INFO.POLICY_NO = dbo.COSL_MASTER.POLICY_NO " & _
        "INNER JOIN center_setup.dbo.SETUP_MAX_ENDORSEMENT M " & _
        "ON dbo.POLICY_AUTO_INFO.POLICY_NO = M.POLICY_NO " & _
        "AND dbo.POLICY_AUTO_INFO.POLICY_ENDORSEMENT_NO = M.MAX_ENDORSEMENT " & _
        "LEFT OUTER JOIN center_setup.dbo.SETUP_PROVINCES P " & _
        "ON dbo.POLICY_AUTO_INFO.KEY_FIELD = P.KEY_FIELD " & _
        "WHERE (substring(dbo.POLICY_AUTO_INFO.POLICY_NO,4,2) in ('AV', 'AC')) "



        'If ds.VEHICLE_PREFIX_LICENSE_NO_PAR.Trim.Length <> 0 And ds.VEHICLE_LICENSE_NO_PAR.Trim.Length <> 0 Then
        '    mysql = mysql & "AND (dbo.POLICY_AUTO_INFO.VEHICLE_PREFIX_LICENSE_NO = @PREFIX_LICENSE) "
        '    conn.addParameter("@PREFIX_LICENSE", Database.ParaType.ParaNVarChar, 8, ds.VEHICLE_PREFIX_LICENSE_NO_PAR.Trim & " " & ds.VEHICLE_LICENSE_NO_PAR.Trim)
        'End If

        If (ds.VEHICLE_PREFIX_LICENSE_NO_PAR.Trim.Length + ds.VEHICLE_LICENSE_NO_PAR.Trim.Length) <> 0 Then
            mysql = mysql & "AND (dbo.POLICY_AUTO_INFO.VEHICLE_PREFIX_LICENSE_NO like '" & ds.VEHICLE_PREFIX_LICENSE_NO_PAR.Trim & "%" & ds.VEHICLE_LICENSE_NO_PAR.Trim & "') "
        End If


        If ds.PROVINCE_LICENSE_NO_PAR <> "0" And ds.PROVINCE_LICENSE_NO_PAR <> "" Then
            mysql = mysql & "AND (dbo.POLICY_AUTO_INFO.KEY_FIELD = @PROVINCE_LICENSE) "
            conn.addParameter("@PROVINCE_LICENSE", Database.ParaType.ParaNVarChar, 2, ds.PROVINCE_LICENSE_NO_PAR)
        End If
        If ds.POLICY_NO_PAR.Trim.Length <> 0 Then
            mysql = mysql & "AND (dbo.POLICY_AUTO_INFO.POLICY_NO = @POLICY_NO) "
            conn.addParameter("@POLICY_NO", Database.ParaType.ParaNVarChar, 28, ds.POLICY_NO_PAR.Trim)
        End If
        If ds.CLAIM_NO_PAR.Trim.Length <> 0 Then
            mysql = mysql & "AND (dbo.COSL_MASTER.CLAIM_NO = @CLAIM_NO) "
            conn.addParameter("@CLAIM_NO", Database.ParaType.ParaNVarChar, 21, ds.CLAIM_NO_PAR.Trim)
        End If
        If ds.LOSS_DATE_PAR.Trim.Length <> 0 Then
            mysql = mysql & "AND (dbo.COSL_MASTER.LOSS_DATE = convert(datetime, @LOSS_DATE + ' 00:00:00', 103)) "
            conn.addParameter("@LOSS_DATE", Database.ParaType.ParaNVarChar, 10, Mid(ds.LOSS_DATE_PAR.Trim, 7, 4) & "-" & _
               Mid(ds.LOSS_DATE_PAR.Trim, 4, 2) & "-" & Mid(ds.LOSS_DATE_PAR.Trim, 1, 2))
        End If
        mysql = mysql & "ORDER BY Replace(ISNULL(dbo.POLICY_AUTO_INFO.VEHICLE_PREFIX_LICENSE_NO, ''), ' ', '') + " & _
        "dbo.POLICY_AUTO_INFO.KEY_FIELD"

        conn.Timeout = 120000L
        conn.SqlQuery(mysql, dt)
        Return dt
    End Function
    Public Function searchRecovery(ByVal claim_no As String, ByVal create_date As String)
        Dim mysql As String
        dt = New DataTable()
        mysql = "SELECT idcolumn, claim_no, group_name, fast_track, import_flag, update_date, update_by " & _
        "FROM dbo.DMS_Recovery_Detail " & _
        "WHERE (import_flag <> 'D') "
        If claim_no.Trim.Length <> 0 Then
            mysql = mysql & "AND (claim_no = @CLAIM_NO) "
            conn.addParameter("@CLAIM_NO", Database.ParaType.ParaNVarChar, 21, claim_no.Trim)
        End If
        If create_date.Trim.Length <> 0 Then
            mysql = mysql & "AND (CONVERT (varchar(10), create_date, 102) = @create_date) "
            conn.addParameter("@create_date", Database.ParaType.ParaNVarChar, 10, Mid(create_date.Trim, 7, 4) & "." & _
               Mid(create_date.Trim, 4, 2) & "." & Mid(create_date.Trim, 1, 2))
        End If
        mysql = mysql & "ORDER BY update_date DESC, claim_no"
        conn.Timeout = 120000L
        conn.SqlQuery(mysql, dt)
        Return dt
    End Function
    Public Function delRecovery(ByVal key As String, ByVal uname As String) As Boolean
        Dim mysql As String
        Try
            mysql = "update dbo.DMS_Recovery_Detail " & _
            "set import_flag = 'D', " & _
            "update_date = getdate(), " & _
            "update_by = '" & uname & "' " & _
            "where (create_by = '" & uname & "') " & _
            "and (import_flag = 'N') "
            If (key.Length > 0) Then
                mysql += " and ([idcolumn] = " + key + ")"
            End If
            Return conn.SqlQuery(mysql) > 0
        Catch ex As Exception
            Return False
        End Try
    End Function

    Function getCoslMaster(ByVal ds As DS_SchPolicy)
        Dim mysql As String
        mysql = "SELECT C.POLICY_NO, C.CLAIM_NO, " & _
        "C.REFERENCE_NO AS LICENSE_NO, " & _
        "'99' AS KEY_FIELD, " & _
        "'Non' AS PROVINCE_NAME, " & _
        "'Non' AS LICENSE_KEY " & _
        "FROM dbo.NM_COSL_MASTER C " & _
        "WHERE (NOT C.POLICY_NO IS NULL) "
        If ds.POLICY_NO_PAR.Trim.Length <> 0 Then
            mysql = mysql & "AND (C.POLICY_NO = @POLICY_NO) "
            conn.addParameter("@POLICY_NO", Database.ParaType.ParaNVarChar, 28, ds.POLICY_NO_PAR.Trim)
        End If
        If ds.CLAIM_NO_PAR.Trim.Length <> 0 Then
            mysql = mysql & "AND (C.CLAIM_NO = @CLAIM_NO) "
            conn.addParameter("@CLAIM_NO", Database.ParaType.ParaNVarChar, 21, ds.CLAIM_NO_PAR.Trim)
        End If
        If ds.REFERENCE_NO_PAR.Trim.Length <> 0 Then
            'mysql = mysql & "AND (C.REFERENCE_NO LIKE %@REFERENCE_NO%) "
            'conn.addParameter("@REFERENCE_NO", Database.ParaType.ParaNVarChar, 30, ds.REFERENCE_NO.Trim)
            mysql = mysql & "AND (C.REFERENCE_NO LIKE '%" + ds.REFERENCE_NO_PAR.Trim + "%') "
        End If
        If ds.LOSS_DATE_PAR.Trim.Length <> 0 Then
            mysql = mysql & "AND (C.LOSS_DATE = convert(datetime, @LOSS_DATE + ' 00:00:00', 103)) "
            conn.addParameter("@LOSS_DATE", Database.ParaType.ParaNVarChar, 10, Mid(ds.LOSS_DATE_PAR.Trim, 7, 4) & "-" & _
               Mid(ds.LOSS_DATE_PAR.Trim, 4, 2) & "-" & Mid(ds.LOSS_DATE_PAR.Trim, 1, 2))
        End If
        mysql = mysql & "ORDER BY C.POLICY_NO"


        conn.Timeout = 120000L
        conn.SqlQuery(mysql, dt)
        Return dt
    End Function
    Private Function createTable() As DataTable
        Dim MyTable As DataTable = New DataTable
        MyTable.TableName = "search_policy_claim_info"
        MyTable.Columns.Add("CALLER")
        MyTable.Columns.Add("REFERENCE_NO")
        MyTable.Columns.Add("POLICY_NO_PAR")
        MyTable.Columns.Add("CLAIM_NO_PAR")
        MyTable.Columns.Add("VEHICLE_PREFIX_LICENSE_NO_PAR")
        MyTable.Columns.Add("VEHICLE_LICENSE_NO_PAR")
        MyTable.Columns.Add("PROVINCE_LICENSE_NO_PAR")
        MyTable.Columns.Add("REFERENCE_NO_PAR")
        MyTable.Columns.Add("LOSS_DATE_PAR")
        Return MyTable
    End Function

    Public Function schDoc(ByVal ds As DS_Underwrite) As DataTable
        Dim mysql As String
        dt = New DataTable
        mysql = "SELECT policy_no as doc_no, insured_name, chassis_no, policy_no, reference_no, " & _
       "prefix_license_no + license_no AS license_no, " & _
       "province_key, ISNULL(P.PROVINCE_NAME, '') AS PROVINCE_NAME, " & _
       "'addUnderwite.aspx?sys_id=4&act_type=EDIT&AA=" & ds.AA & "&doc_no='+ doc_no AS edit_url, " & _
       "doc_status " & _
       "FROM dbo.DMS_UWMOTOR_MAIN " & _
       "LEFT OUTER JOIN center_setup.dbo.SETUP_PROVINCES P " & _
       "ON province_key = P.KEY_FIELD " & _
       "WHERE (UW_Year = '" & ds.T4 & "') "
        If ds.Fcode.Trim.Length <> 0 Then
            mysql = mysql & "AND (prefix_license_no = '" & ds.Fcode.Trim & "') "
        End If
        If ds.Ecode.Trim.Length <> 0 Then
            mysql = mysql & "AND (license_no = '" & ds.Ecode.Trim & "') "
        End If
        If ds.Provinces <> "0" Then
            mysql = mysql & "AND (province_key = '" & ds.Provinces & "') "
        End If
        If ds.Ref_no.Trim.Length <> 0 Then
            mysql = mysql & "AND (reference_no = '" & ds.Ref_no.Trim & "') "
        End If
        If ds.CarNum.Trim.Length <> 0 Then
            mysql = mysql & "AND (chassis_no like '%" & ds.CarNum.Trim & "%') "
        End If
        If ds.InsureName.Trim.Length <> 0 Then
            mysql = mysql & "AND (insured_name like '%" & ds.InsureName.Trim & "%') "
        End If
        If ds.T1.Trim.Length <> 0 Then
            mysql = mysql & "AND (policy_no like '" & ds.T1.Trim & "-" & ds.T2 & "-"
        Else
            mysql = mysql & "AND (policy_no like '%" & ds.T2 & "-"
        End If
        If ds.T3.Trim.Length <> 0 Then
            mysql = mysql & ds.T3.Trim & "%" & ds.T4 & "-" & ds.T5 & "') "
        Else
            mysql = mysql & "%" & ds.T4 & "-" & ds.T5 & "') "
        End If
        If ds.IdCard.Trim.Length <> 0 Then
            mysql = mysql & "AND (card_id = '" & ds.IdCard.Trim & "') "
        End If
        If ds.ManName.Trim.Length <> 0 Then
            mysql = mysql & "AND (agent_code = '" & ds.ManValue.Trim & "') "
        End If
        'If DD_status.SelectedValue <> "ALL" Then
        '    mysql = mysql & "AND (doc_status = '" & DD_status.SelectedValue & "') "
        'End If
        mysql = mysql & "ORDER BY doc_no"
        conn.SqlQuery(mysql, dt)
        dt.TableName = "t_search"
        Return dt
    End Function
    Public Function schDocSvc(ByVal ds As DS_Underwrite)
        Dim ds_search As DataSet = New DataSet
        Dim res As DataSet = New DataSet
        Dim dt_search As DataTable = New DataTable
        'dt = New DataTable("t_search")
        ds_search.Tables.Add("search_policy_claim_info")
        ds_search.Tables(0).Columns.Add("CALLER")
        ds_search.Tables(0).Columns.Add("REFERENCE_NO")
        ds_search.Tables(0).Columns.Add("POLICY_NO_PAR")
        ds_search.Tables(0).Columns.Add("CLAIM_NO_PAR")
        ds_search.Tables(0).Columns.Add("VEHICLE_PREFIX_LICENSE_NO_PAR")
        ds_search.Tables(0).Columns.Add("VEHICLE_LICENSE_NO_PAR")
        ds_search.Tables(0).Columns.Add("PROVINCE_LICENSE_NO_PAR")
        ds_search.Tables(0).Columns.Add("REFERENCE_NO_PAR")
        ds_search.Tables(0).Columns.Add("LOSS_DATE_PAR")

        Dim dr As DataRow = ds_search.Tables(0).NewRow



        dr("CALLER") = ds.AA
        dr("REFERENCE_NO") = Now().ToString("yyyyMMddhhmmss") 'ds.Ref_no
        If ds.Doc_no.Length = 0 Then
            dr("POLICY_NO_PAR") = ""
        Else
            dr("POLICY_NO_PAR") = ds.Doc_no
        End If

        dr("CLAIM_NO_PAR") = ""
        If ds.Fcode.Trim.Length = 0 And ds.Ecode.Trim.Length = 0 Then
            dr("VEHICLE_PREFIX_LICENSE_NO_PAR") = ""
            dr("VEHICLE_LICENSE_NO_PAR") = ""
        Else
            dr("VEHICLE_PREFIX_LICENSE_NO_PAR") = ds.Fcode.Trim
            dr("VEHICLE_LICENSE_NO_PAR") = ds.Ecode.Trim
        End If

        If ds.Provinces = "0" Then
            dr("PROVINCE_LICENSE_NO_PAR") = ""
        Else
            dr("PROVINCE_LICENSE_NO_PAR") = ds.Provinces
        End If
        dr("REFERENCE_NO_PAR") = ""
        dr("LOSS_DATE_PAR") = ""
        ds_search.Tables(0).Rows.Add(dr)

        res = MySearchAegis.wsSearchPolicyClaimInfo(ds_search)


        'Dim dt_search As DataTable = New DataTable
        If res.Tables("ws_return_data").Rows(0).Item("WS_RETURN_CODE") = "1" Then
            Dim rows_dt As DataRow
            dt_search.TableName = "t_search"
            dt_search.Columns.Add("POLICY_NO")
            dt_search.Columns.Add("LICENSE_NO")
            dt_search.Columns.Add("KEY_FIELD")
            dt_search.Columns.Add("PROVINCE_NAME")
            dt_search.Columns.Add("LICENSE_KEY")
            dt_search.Columns.Add("CLAIM_NO")

            For Each dr In res.Tables("ws_return_policy_data").Rows
                Dim t_license1() As String = dr.Item("policy_unit_description").ToString.Split("License:")
                Dim tmp_license2 As String = ""
                Dim l As Integer
                For l = 0 To t_license1.Length - 1
                    If t_license1(l).StartsWith("icense:") Then
                        Dim t_license2() As String = t_license1(l).ToString.Split("C")
                        tmp_license2 = t_license2(0).ToString.Replace("icense: ", "").Replace(" ", "")
                    End If
                Next
                rows_dt = dt_search.NewRow()
                rows_dt("POLICY_NO") = dr.Item("POLICY_NO")
                rows_dt("LICENSE_NO") = tmp_license2.Trim
                rows_dt("KEY_FIELD") = dr.Item("PROVINCE_LICENSE_NO_CODE")
                rows_dt("PROVINCE_NAME") = dr.Item("PROVINCE_LICENSE_NO_NAME")
                rows_dt("LICENSE_KEY") = tmp_license2.Trim & dr.Item("PROVINCE_LICENSE_NO_CODE")
                rows_dt("CLAIM_NO") = ""
                dt_search.Rows.Add(rows_dt)
            Next

        End If

        Return dt_search
    End Function


    Public Function schPolicyClaimInfo3(ByVal dsTable As DataTable) As DataTable
        Dim res As New DataSet
        Dim dr, rows_dt As DataRow
        dt = New DataTable
        Dim ds As DataSet = New DataSet()
        ds.Tables.Add(dsTable)

        res = MySearchAegis.wsSearchPolicyClaimInfo(ds)

        If res.Tables("ws_return_data").Rows(0).Item("WS_RETURN_CODE") = "1" Then
            If res.Tables("ws_return_claim_data").Rows.Count > 0 Then
                dt = New DataTable
                dt.TableName = "t_search"
                dt.Columns.Add("POLICY_NO")
                dt.Columns.Add("LICENSE_NO")
                dt.Columns.Add("KEY_FIELD")
                dt.Columns.Add("PROVINCE_NAME")
                dt.Columns.Add("Claim_no")
                dt.Columns.Add("LICENSE_KEY")
                For Each dr In res.Tables("ws_return_claim_data").Rows
                    Dim dataPolicy = From c In res.Tables("ws_return_policy_data") _
                                              Where c.Item("POLICY_NO") = dr.Item("POLICY_NO") _
                                              And Not (c.Item("lob") Like "A*")

                    If dataPolicy.Count > 0 Then
                        For Each t_datapolicy In dataPolicy
                            rows_dt = dt.NewRow()
                            rows_dt("POLICY_NO") = t_datapolicy.Item("POLICY_NO")
                            rows_dt("LICENSE_NO") = dr.Item("CLAIM_REFERENCE_NO")
                            rows_dt("KEY_FIELD") = "99"
                            rows_dt("PROVINCE_NAME") = t_datapolicy.Item("policy_unit_description")
                            rows_dt("Claim_no") = dr.Item("Claim_no")
                            rows_dt("LICENSE_KEY") = "Non"
                            dt.Rows.Add(rows_dt)
                            Exit For
                        Next
                    End If
                Next
            End If
        End If
        Return dt
    End Function

    Public Function schPolicyClaimInfo(ByVal dsTable As DataTable) As DataTable
        Dim res As New DataSet
        Dim dr, rows_dt As DataRow
        dt = New DataTable
        Dim ds As DataSet = New DataSet()
        ds.Tables.Add(dsTable)

        res = MySearchAegis.wsSearchPolicyClaimInfo(ds)
        If res.Tables("ws_return_data").Rows(0).Item("WS_RETURN_CODE") = "1" Then

            If res.Tables("ws_return_claim_data").Rows.Count > 0 Then
                dt = New DataTable
                dt.TableName = "t_search"
                dt.Columns.Add("POLICY_NO")
                dt.Columns.Add("LICENSE_NO")
                dt.Columns.Add("KEY_FIELD")
                dt.Columns.Add("PROVINCE_NAME")
                dt.Columns.Add("Claim_no")
                dt.Columns.Add("LICENSE_KEY")
                dt.Columns.Add("PREVPOL")
                dt.Columns.Add("NEXTPOL")

                For Each dr In res.Tables("ws_return_claim_data").Rows
                    Dim dataPolicy = From c In res.Tables("ws_return_policy_data") _
                                          Where c.Item("POLICY_NO") = dr.Item("POLICY_NO") _
                                          And c.Item("lob") Like "A*"

                    If dataPolicy.Count > 0 Then
                        For Each t_datapolicy In dataPolicy
                            Dim t_license1() As String = t_datapolicy.Item("policy_unit_description").ToString.Split("License:")
                            Dim tmp_license2 As String = ""
                            Dim l As Integer
                            For l = 0 To t_license1.Length - 1
                                If t_license1(l).StartsWith("icense:") Then
                                    Dim t_license2() As String = t_license1(l).ToString.Split("C")
                                    tmp_license2 = t_license2(0).ToString.Replace("icense: ", "").Replace(" ", "")
                                End If
                            Next
                            rows_dt = dt.NewRow()
                            rows_dt("POLICY_NO") = t_datapolicy.Item("POLICY_NO")
                            rows_dt("LICENSE_NO") = tmp_license2.Trim
                            rows_dt("KEY_FIELD") = t_datapolicy.Item("PROVINCE_LICENSE_NO_CODE")
                            rows_dt("PROVINCE_NAME") = t_datapolicy.Item("PROVINCE_LICENSE_NO_NAME")
                            rows_dt("Claim_no") = dr.Item("Claim_no")
                            rows_dt("LICENSE_KEY") = tmp_license2.Trim & t_datapolicy.Item("PROVINCE_LICENSE_NO_CODE")
                            rows_dt("PREVPOL") = t_datapolicy.Item("PREVPOL")
                            rows_dt("NEXTPOL") = t_datapolicy.Item("NEXTPOL")
                            dt.Rows.Add(rows_dt)
                        Next
                    End If
                Next
            End If
        End If
        Return dt
    End Function
    Public Function srhDoc(ByVal doc_no As String) As DS_Underwrite
        Dim mysql As String = String.Empty
        Dim ds As DS_Underwrite = New DS_Underwrite
        mysql = "SELECT TOP 1 doc_no, insured_name, chassis_no, policy_no, reference_no, " & _
        "prefix_license_no, license_no, province_key, card_id, UW_Year, " & _
        "isnull(agent_code, '') AS agent_code, isnull(agent_name, '') AS agent_name, " & _
        "isnull(doc_status, 'I') as doc_status " & _
        "FROM dbo.DMS_UWMOTOR_MAIN " & _
        "WHERE (doc_no = @ProlicyNo)"

        conn.addParameterST50("@ProlicyNo", doc_no)
        conn.SqlQuery(mysql, dt)
        ds.Doc_no = dt.Rows(0)("doc_no")
        ds.Ref_no = dt.Rows(0)("reference_no")
        ds.InsureName = dt.Rows(0)("insured_name")
        ds.ManValue = dt.Rows(0)("agent_code")
        ds.ManName = dt.Rows(0)("agent_name")
        ds.IdCard = dt.Rows(0)("card_id")
        ds.Fcode = dt.Rows(0)("prefix_license_no")
        ds.Ecode = dt.Rows(0)("license_no")
        ds.Provinces = dt.Rows(0)("province_key")
        ds.CarNum = dt.Rows(0)("chassis_no")
        ds.T4 = dt.Rows(0)("UW_Year")
        Return ds
    End Function
    Public Function updDoc(ByVal ds As DS_Underwrite) As Integer
        Dim mysql As String = String.Empty
        mysql = "UPDATE dbo.DMS_UWMOTOR_MAIN " & _
                   "SET insured_name = @InsureName, " & _
                   "chassis_no = @CarNum, " & _
                   "policy_no = @ProlicyNo, " & _
                   "reference_no = @Ref_no, " & _
                   "prefix_license_no = @Fcode, " & _
                   "license_no = @Ecode, " & _
                   "card_id = @IdCard, " & _
                   "UW_Year = @T4, " & _
                   "agent_code = @ManValue, " & _
                   "agent_name = @ManName, " & _
                   "province_key = @Provinces, " & _
                   "user_name = @AA, " & _
                   "last_update = getdate() " & _
                   "WHERE (doc_no = @Doc_no) "

        conn.addParameterST50("@ProlicyNo", ds.Doc_no)
        conn.addParameterST50("@Doc_no", ds.Doc_no)
        conn.addParameterST50("@Ref_no", ds.Ref_no)
        conn.addParameterST4("@T4", ds.T4)
        conn.addParameterST("@ManValue", ds.ManValue, 7)
        conn.addParameterST50("@ManName", ds.ManName)
        conn.addParameterST20("@IdCard", ds.IdCard)
        conn.addParameterST("@InsureName", ds.InsureName, 80)
        conn.addParameterST("@CarNum", ds.CarNum, 25)
        conn.addParameterST4("@Fcode", ds.Fcode)
        conn.addParameterST10("@Ecode", ds.Ecode)
        conn.addParameterST2("@Provinces", ds.Provinces)
        conn.addParameterST50("@AA", ds.AA)
        ' conn.addParameterST255("@status", ds.Status)
        Return conn.SqlQuery(mysql)
    End Function
    Public Function insDoc(ByVal ds As DS_Underwrite) As Integer
        Dim mysql As String = String.Empty

        mysql = "INSERT INTO dbo.DMS_UWMOTOR_MAIN " & _
        "(doc_no, policy_no, reference_no, UW_Year, agent_code, agent_name, card_id, insured_name, " & _
        "chassis_no, prefix_license_no, license_no, province_key, user_name, last_update) " & _
        "VALUES (@ProlicyNo,@ProlicyNo,@Ref_no,@T4,@ManValue,@ManName,@IdCard,@InsureName,@CarNum,@Fcode,@Ecode,@Provinces,@AA,GETDATE())"

        conn.addParameterST50("@ProlicyNo", ds.ProlicyNo)
        conn.addParameterST50("@Ref_no", ds.Ref_no)
        conn.addParameterST4("@T4", ds.T4)
        conn.addParameterST("@ManValue", ds.ManValue, 7)
        conn.addParameterST50("@ManName", ds.ManName)
        conn.addParameterST20("@IdCard", ds.IdCard)
        conn.addParameterST("@InsureName", ds.InsureName, 80)
        conn.addParameterST("@CarNum", ds.CarNum, 25)
        conn.addParameterST4("@Fcode", ds.Fcode)
        conn.addParameterST10("@Ecode", ds.Ecode)
        conn.addParameterST2("@Provinces", ds.Provinces)
        conn.addParameterST50("@AA", ds.AA)
        ' conn.addParameterST255("@status", ds.Status)
        Return conn.SqlQuery(mysql)
    End Function
    Public Function schDocCC2(ByVal ds As DS_Underwrite, ByVal part As String)

        Dim dsPolicy As New DataSet
        Dim RowsCount As Integer
        Dim mysql As String
        Dim Search_Policy As DataTable = MakeTableDetail("Search_Policy")
        Dim dataRows As DataRow = Nothing
        Dim myds As DataSet = New DataSet

        myds.Tables.Add(Search_Policy)

        ' dsPolicy = MySearchPolicy.wsSearchPolicyCC2(ds.CarNum, ds.T2, ds.T3, "", ds.T4, _
        ' ds.T5, "", "", "", "")

        dsPolicy.WriteXml(part & "/policy.xml")

        Try
            RowsCount = dsPolicy.Tables("policy_information_CC2").Rows.Count
        Catch ex As Exception
            RowsCount = 0
        End Try

        If RowsCount <> 0 Then
            For i As Integer = 0 To RowsCount - 1
                dataRows = myds.Tables("Search_Policy").NewRow()

                With dsPolicy.Tables("cx").Rows(i)

                    dataRows("DOC_NO") = .Item("CORP_ID").ToString() & _
                                         .Item("POLICY_LINE_OF_BUSINESS").ToString() & _
                                         .Item("POLICY_SERIAL_NUMBER").ToString() & _
                                         .Item("POLICY_SERIAL_SUFFIX").ToString() & _
                                         .Item("POLICY_EFFECTIVE_YEAR").ToString() & _
                                         .Item("POLICY_EFFECTIVE_MONTH").ToString()

                    dataRows("POLICY_NO") = .Item("CORP_ID").ToString() & _
                                            "-" & _
                                            .Item("POLICY_LINE_OF_BUSINESS").ToString() & _
                                            "-" & _
                                            .Item("POLICY_SERIAL_NUMBER").ToString() & _
                                            "-" & _
                                            .Item("POLICY_SERIAL_SUFFIX").ToString() & "-" & _
                                            .Item("POLICY_EFFECTIVE_YEAR").ToString() & _
                                            "-" & .Item("POLICY_EFFECTIVE_MONTH").ToString()

                    dataRows("INSURED_NAME") = .Item("INSURED_NAME").ToString()

                    dataRows("LICENSE_CAR") = .Item("VEHICLE_PREFIX_LICENSE_NO").ToString() & _
                                                 .Item("VEHICLE_LICENSE_NO").ToString()

                    If .Item("PROVINCE_LICENSE_NO").ToString() = "99" Then
                        dataRows("PREFIX_LICENSE_NO") = " "
                    Else
                        dataRows("PREFIX_LICENSE_NO") = .Item("VEHICLE_PREFIX_LICENSE_NO").ToString()
                    End If

                    dataRows("LICENSE_NO") = .Item("VEHICLE_LICENSE_NO").ToString()

                    dataRows("PROVINCE_CODE") = .Item("PROVINCE_LICENSE_NO").ToString()

                    mysql = "SELECT PROVINCE_NAME " & _
                            "FROM dbo.SETUP_PROVINCES " & _
                            "WHERE (KEY_FIELD = @PROVINCE_LICENSE_NO) "
                    conn.addParameter("@PROVINCE_LICENSE_NO", Database.ParaType.ParaNVarChar, 21, .Item("PROVINCE_LICENSE_NO").ToString())
                    conn.SqlQuery(mysql, dt)
                    dataRows("PROVINCE_NAME") = dt.Rows(0)("PROVINCE_NAME").ToString()
                    dataRows("CHASSIS_NO") = .Item("VEHICLE_CHASSIS_NO").ToString()
                    dataRows("UW_YEAR") = .Item("POLICY_EFFECTIVE_YEAR").ToString()

                End With
                myds.Tables("Search_Policy").Rows.Add(dataRows)
            Next
        End If
        Return myds.Tables("Search_Policy")
    End Function
    Public Function schFinance(ByVal com_code As String, ByVal fName As String, ByVal tex_id As String) As DataTable
        Dim mysql As String = String.Empty
        dt = New DataTable()
        mysql = "SELECT COMPANY_CODE AS AGENT_CODE, ISNULL(SALUTATION, '') AS SALUTATION, " & _
        "FULL_NAME, TAX_ID_NO AS ID_CARD " & _
        "FROM dbo.SETUP_COMPANY " & _
        "WHERE (SUBSTRING(COMPANY_CODE, 1, 2) IN ('AG', 'BR')) "

        If com_code.Trim.Length <> 0 Then
            mysql = mysql & "AND (COMPANY_CODE = '" & com_code & "') "
        End If
        If fName.Trim.Length <> 0 Then
            mysql = mysql & "AND (FULL_NAME like '%" & fName & "%') "
        End If
        If tex_id.Trim.Length <> 0 Then
            mysql = mysql & "AND (TAX_ID_NO like '%" & tex_id & "%') "
        End If
        mysql = mysql & "ORDER BY FULL_NAME"

        conn.SqlQuery(mysql, dt)
        Return dt
    End Function
    Public Function getArchive(ByVal t_doc_no As String, ByVal URL_LINK As String) As DataTable
        Dim mysql As String = String.Empty
        dt = New DataTable()
        mysql = "SELECT Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date " & _
        "FROM dbo.DMS_maindocument " & _
        "WHERE (doc_no = '" & t_doc_no & "') "
        If URL_LINK = "DMS" Then
            mysql &= "AND (Archive_Flag = 'Y') "
        End If
        mysql &= "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"
        conn.SqlQuery(mysql, dt)
        Return dt
    End Function



    Private Function MakeTableDetail(ByVal TABLE_NAME As String) As DataTable
        Dim myTable As DataTable = New DataTable(TABLE_NAME)

        myTable.Columns.Add("DOC_NO")
        myTable.Columns.Add("POLICY_NO")
        myTable.Columns.Add("INSURED_NAME")
        myTable.Columns.Add("LICENSE_CAR")
        myTable.Columns.Add("PREFIX_LICENSE_NO")
        myTable.Columns.Add("LICENSE_NO")
        myTable.Columns.Add("PROVINCE_CODE")
        myTable.Columns.Add("PROVINCE_NAME")
        myTable.Columns.Add("CHASSIS_NO")
        myTable.Columns.Add("UW_YEAR")

        Return myTable

    End Function
End Class
