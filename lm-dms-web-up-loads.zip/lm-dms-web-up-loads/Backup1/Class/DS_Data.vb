﻿Public Class DS_Data
    Private _groupName As String
    Private _groupValue As String
    Private _typeName As String
    Private _typeValue As String
    Private _claimId As String
    Private _typeClaim As String
    Private _typeClaimValue As String
    Private _noClaim As String
    Private _tranJob As String
    Private _tranJobValue As String
    Private _createDate As DateTime

    Public Property GroupName() As String
        Get
            Return _groupName
        End Get
        Set(ByVal value As String)
            _groupName = value
        End Set
    End Property
    Public Property GroupValue() As String
        Get
            Return _groupValue
        End Get
        Set(ByVal value As String)
            _groupValue = value
        End Set
    End Property
    Public Property TypeName() As String
        Get
            Return _typeName
        End Get
        Set(ByVal value As String)
            _typeName = value
        End Set
    End Property
    Public Property TypeValue() As String
        Get
            Return _typeValue
        End Get
        Set(ByVal value As String)
            _typeValue = value
        End Set
    End Property
    Public Property ClaimId() As String
        Get
            Return _claimId
        End Get
        Set(ByVal value As String)
            _claimId = value
        End Set
    End Property
    Public ReadOnly Property FileSaveName() As String
        Get
            Dim stClaim() As String = _claimId.Split("-")
            Return stClaim(0) + stClaim(1) + stClaim(2) + stClaim(3) + stClaim(4) + stClaim(5) + _createDate.ToString("yyyyMMddThhmmss") + "_"
        End Get
    End Property

    Public Property TypeClaim() As String
        Get
            Return _typeClaim
        End Get
        Set(ByVal value As String)
            _typeClaim = value
        End Set
    End Property
    Public Property TypeClaimValue() As String
        Get
            Return _typeClaimValue
        End Get
        Set(ByVal value As String)
            _typeClaimValue = value
        End Set
    End Property
    Public Property NoClaim() As String
        Get
            Return _noClaim
        End Get
        Set(ByVal value As String)
            _noClaim = value
        End Set
    End Property
    Public Property TranJob() As String
        Get
            Return _tranJob
        End Get
        Set(ByVal value As String)
            _tranJob = value
        End Set
    End Property
    Public Property TranJobValue() As String
        Get
            Return _tranJobValue
        End Get
        Set(ByVal value As String)
            _tranJobValue = value
        End Set
    End Property
    Public Property CreateDate() As DateTime
        Get
            Return _createDate
        End Get
        Set(ByVal value As DateTime)
            _createDate = value
        End Set
    End Property
End Class
