﻿Public Class DS_DisFile
    Private _fileName As String
    Private _fileDis As String
    Private _filePath As String
    Private _no As String
    Private _del As Boolean
    Private _move As Boolean
    Private _pathDis As String
    Private _msg As String
    Private _pnt As String


    Public Property no() As String
        Get
            Return _no
        End Get
        Set(ByVal value As String)
            _no = value
        End Set
    End Property
   
    Public Property FileName() As String
        Get
            Return _fileName
        End Get
        Set(ByVal value As String)
            _fileName = value
        End Set
    End Property
    Public Property PathDis() As String
        Get
            Return _pathDis
        End Get
        Set(ByVal value As String)
            _pathDis = value
        End Set
    End Property
    Public Property FileDis() As String
        Get
            Return _fileDis
        End Get
        Set(ByVal value As String)
            _fileDis = value
        End Set
    End Property
    Public Property FilePath() As String
        Get
            Return _filePath
        End Get
        Set(ByVal value As String)
            _filePath = value
        End Set
    End Property
    Public Property FileDel() As Boolean
        Get
            Return _del
        End Get
        Set(ByVal value As Boolean)
            _del = value
        End Set
    End Property
    Public Property FileMove() As Boolean
        Get
            Return _move
        End Get
        Set(ByVal value As Boolean)
            _move = value
        End Set
    End Property
    Public ReadOnly Property chkStatus() As Boolean
        Get
            If _del Or _move Then
                Return True
            Else
                Return False
            End If
        End Get

    End Property
    Public Property Msg() As String
        Get

            Return _msg

        End Get
        Set(ByVal value As String)
            _msg = value
        End Set
    End Property
    Public Property Pnt() As String
        Get

            Return _pnt

        End Get
        Set(ByVal value As String)
            _pnt = value
        End Set
    End Property
    Public ReadOnly Property showFile()
        Get
            Return (_filePath & _fileName).Replace("\", "\\")
        End Get
    End Property
    Public ReadOnly Property toType() As String
        Get
            Dim stype() As String = _fileName.Split(".")
            Return stype(stype.Length - 1).ToLower
        End Get
    End Property
End Class
