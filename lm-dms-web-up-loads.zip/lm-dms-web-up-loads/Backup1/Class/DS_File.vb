﻿Public Class DS_File
    Private _fileName As String
    Private _OfilePath As String
    Private _filePath As String
    Private _fileType As String
    Private _fileNew As String
    Private _des As String
    Private _msg As String
    Private _found As Boolean = True
    Private _no As String
    Private _errDtl As String

    Public Property no() As String
        Get
            Return _no
        End Get
        Set(ByVal value As String)
            _no = value
        End Set
    End Property
    Public ReadOnly Property toType() As String
        Get
            Dim stype() As String = _fileName.Split(".")
            Return "." + stype(stype.Length - 1)
        End Get
    End Property
    Public Property FileName() As String
        Get
            Return _fileName
        End Get
        Set(ByVal value As String)
            _fileName = value
        End Set
    End Property
    Public Property FileNew() As String
        Get
            Return _fileNew
        End Get
        Set(ByVal value As String)
            _fileNew = value
        End Set
    End Property
    Public Property OFilePath() As String
        Get
            Return _OfilePath
        End Get
        Set(ByVal value As String)
            _OfilePath = value
        End Set
    End Property
    Public Property FilePath() As String
        Get
            Return _filePath
        End Get
        Set(ByVal value As String)
            _filePath = value
        End Set
    End Property
    Public Property FileType() As String
        Get
            Return _fileType
        End Get
        Set(ByVal value As String)
            _fileType = value
        End Set
    End Property
    Public Property DesFile() As String
        Get
            Return _des
        End Get
        Set(ByVal value As String)
            _des = value
        End Set
    End Property
    Public Property FileMsg() As String
        Get
            Return _msg
        End Get
        Set(ByVal value As String)
            _msg = value
        End Set
    End Property
    Public Property FileError() As Boolean
        Get
            Return _found
        End Get
        Set(ByVal value As Boolean)
            _found = value
        End Set
    End Property
    Public Property ErrorDtl() As String
        Get
            Return _errDtl
        End Get
        Set(ByVal value As String)
            _errDtl = value
        End Set
    End Property

    Public Function FileFullPath(ByVal strChar) As String
        Return _OfilePath + strChar + _fileName
    End Function
    Public Function FileFullPath() As String
        Return Me.FileFullPath("\")
    End Function
    Public Function FileNewFullPath(ByVal strChar) As String
        Return _filePath + _fileNew
    End Function
    Public Function FileNewFullPath() As String
        Return Me.FileNewFullPath("\")
    End Function
End Class
