﻿Public Class DS_Menu
    Private _doc_main_id As String
    Private _system_id As String
    Private _doc_group As String
    Private _doc_submain_id As String
    Private _doc_main_name As String
    Private _doc_submain_name As String
    Private _doc_form As String
    Private _arr_doc_type As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

    Public Property Doc_main_id() As String
        Get
            Return _doc_main_id
        End Get
        Set(ByVal value As String)
            _doc_main_id = value
        End Set
    End Property
    Public Property System_id() As String
        Get
            Return _system_id
        End Get
        Set(ByVal value As String)
            _system_id = value
        End Set
    End Property
    Public Property Doc_group() As String
        Get
            Return _doc_group
        End Get
        Set(ByVal value As String)
            _doc_group = value
        End Set
    End Property
    Public Property Doc_submain_id() As String
        Get
            Return _doc_submain_id
        End Get
        Set(ByVal value As String)
            _doc_submain_id = value
        End Set
    End Property
    Public Property Doc_main_name() As String
        Get
            Return _doc_main_name
        End Get
        Set(ByVal value As String)
            _doc_main_name = value
        End Set
    End Property
    Public Property Doc_form() As String
        Get
            Return _doc_form
        End Get
        Set(ByVal value As String)
            _doc_form = value
        End Set
    End Property

    Public Sub setDoc_type(ByVal doc_type_name As String, ByVal doc_type_value As Integer)
        _arr_doc_type.Add(doc_type_name, doc_type_value)
    End Sub

    Public Function getDoc_type(ByVal doc_type_name As String) As Integer
        Return _arr_doc_type(doc_type_name)
    End Function
End Class
