﻿Imports Microsoft.VisualBasic

Public Class DS_Paper
    Private pp_con_id As String
    Private pp_no As String
    Private ms_id As String
    Private pp_num As String
    Private pp_money As String
    Private pp_update As String
    Private pp_user As String
    Private pp_msg As String
    Public Property ConId() As String
        Get
            Return pp_con_id
        End Get
        Set(ByVal value As String)
            pp_con_id = value
        End Set
    End Property
    Public Property No() As String
        Get
            Return pp_no
        End Get
        Set(ByVal value As String)
            pp_no = value
        End Set
    End Property
    Public Property MsId() As String
        Get
            Return ms_id
        End Get
        Set(ByVal value As String)
            ms_id = value
        End Set
    End Property
    Public Property Msg() As String
        Get
            Return pp_msg
        End Get
        Set(ByVal value As String)
            pp_msg = value
        End Set
    End Property
    Public Property Pnum() As String
        Get
            Return pp_num
        End Get
        Set(ByVal value As String)
            pp_num = value
        End Set
    End Property
    Public Property Pmoney() As String
        Get
            Return pp_money
        End Get
        Set(ByVal value As String)
            pp_money = value
        End Set
    End Property
    Public Property Pupdate() As String
        Get
            Return pp_update
        End Get
        Set(ByVal value As String)
            pp_update = value
        End Set
    End Property
    Public Property Puser() As String
        Get
            Return pp_user
        End Get
        Set(ByVal value As String)
            pp_user = value
        End Set
    End Property

End Class
