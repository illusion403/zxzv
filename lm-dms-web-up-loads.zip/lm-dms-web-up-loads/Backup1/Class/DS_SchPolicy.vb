﻿Public Class DS_SchPolicy
    Private _CALLER As String = String.Empty
    Private _REFERENCE_NO As String = String.Empty
    Private _POLICY_NO_PAR As String = String.Empty
    Private _CLAIM_NO_PAR As String = String.Empty
    Private _VEHICLE_PREFIX_LICENSE_NO_PAR As String = String.Empty
    Private _VEHICLE_LICENSE_NO_PAR As String = String.Empty
    Private _PROVINCE_LICENSE_NO_PAR As String = String.Empty
    Private _REFERENCE_NO_PAR As String = String.Empty
    Private _LOSS_DATE_PAR As String = String.Empty
    Private dsTable As DataTable
    Private dsRow As DataRow
    Public Sub New()
        dsTable = New DataTable
        dsTable.TableName = "search_policy_claim_info"
        dsTable.Columns.Add("CALLER", System.Type.GetType("System.String"))
        dsTable.Columns.Add("REFERENCE_NO", System.Type.GetType("System.String"))
        dsTable.Columns.Add("POLICY_NO_PAR", System.Type.GetType("System.String"))
        dsTable.Columns.Add("CLAIM_NO_PAR", System.Type.GetType("System.String"))
        dsTable.Columns.Add("VEHICLE_PREFIX_LICENSE_NO_PAR", System.Type.GetType("System.String"))
        dsTable.Columns.Add("VEHICLE_LICENSE_NO_PAR", System.Type.GetType("System.String"))
        dsTable.Columns.Add("PROVINCE_LICENSE_NO_PAR", System.Type.GetType("System.String"))
        dsTable.Columns.Add("REFERENCE_NO_PAR", System.Type.GetType("System.String"))
        dsTable.Columns.Add("LOSS_DATE_PAR", System.Type.GetType("System.String"))
        dsRow = dsTable.NewRow
        dsTable.Rows.Add(dsRow)
    End Sub
    Public ReadOnly Property SchPolicyTable()
        Get
            Return dsTable
        End Get
    End Property
    Public Property CALLER() As String
        Get

            Return _CALLER
        End Get
        Set(ByVal value As String)
            _CALLER = value
            dsTable.Rows(0)("CALLER") = value
        End Set
    End Property
    Public Property REFERENCE_NO() As String
        Get
            Return _REFERENCE_NO
        End Get
        Set(ByVal value As String)
            _REFERENCE_NO = value
            dsTable.Rows(0)("REFERENCE_NO") = _REFERENCE_NO
        End Set
    End Property
    Public Property POLICY_NO_PAR() As String
        Get
            Return _POLICY_NO_PAR
        End Get
        Set(ByVal value As String)
            _POLICY_NO_PAR = value
            dsTable.Rows(0)("POLICY_NO_PAR") = _POLICY_NO_PAR
        End Set
    End Property
    Public Property CLAIM_NO_PAR() As String
        Get
            Return _CLAIM_NO_PAR
        End Get
        Set(ByVal value As String)
            _CLAIM_NO_PAR = value
            dsTable.Rows(0)("CLAIM_NO_PAR") = _CLAIM_NO_PAR
        End Set
    End Property
    Public Property VEHICLE_PREFIX_LICENSE_NO_PAR() As String
        Get
            Return _VEHICLE_PREFIX_LICENSE_NO_PAR
        End Get
        Set(ByVal value As String)
            _VEHICLE_PREFIX_LICENSE_NO_PAR = value
            dsTable.Rows(0)("VEHICLE_PREFIX_LICENSE_NO_PAR") = _VEHICLE_PREFIX_LICENSE_NO_PAR
        End Set
    End Property
    Public Property VEHICLE_LICENSE_NO_PAR() As String
        Get
            Return _VEHICLE_LICENSE_NO_PAR
        End Get
        Set(ByVal value As String)
            _VEHICLE_LICENSE_NO_PAR = value
            dsTable.Rows(0)("VEHICLE_LICENSE_NO_PAR") = _VEHICLE_LICENSE_NO_PAR
        End Set
    End Property
    Public Property PROVINCE_LICENSE_NO_PAR() As String
        Get
            Return _PROVINCE_LICENSE_NO_PAR
        End Get
        Set(ByVal value As String)
            _PROVINCE_LICENSE_NO_PAR = value
            dsTable.Rows(0)("PROVINCE_LICENSE_NO_PAR") = _PROVINCE_LICENSE_NO_PAR
        End Set
    End Property
    Public Property REFERENCE_NO_PAR() As String
        Get
            Return _REFERENCE_NO_PAR
        End Get
        Set(ByVal value As String)
            _REFERENCE_NO_PAR = value
            dsTable.Rows(0)("REFERENCE_NO_PAR") = _REFERENCE_NO_PAR
        End Set
    End Property
    Public Property LOSS_DATE_PAR() As String
        Get
            Return _LOSS_DATE_PAR
        End Get
        Set(ByVal value As String)
            _LOSS_DATE_PAR = value
            dsTable.Rows(0)("LOSS_DATE_PAR") = _LOSS_DATE_PAR
        End Set
    End Property
End Class
