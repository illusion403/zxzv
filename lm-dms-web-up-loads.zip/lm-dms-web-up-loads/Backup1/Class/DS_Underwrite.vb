﻿Public Class DS_Underwrite
    Private _t1 As String
    Private _t2 As String
    Private _t3 As String
    Private _t4 As String
    Private _t5 As String
    Private _ref_no As String
    Private _insureName As String
    Private _idCard As String
    Private _fcode As String
    Private _ecode As String
    Private _provinces As String
    Private _carNum As String
    Private _man As String
    Private _manName As String
    Private _manValue As String
    Private _status As String
    Private _aa As String
    Private _update As String
    Private _doc_no As String
    Public Property Doc_no() As String
        Get
            Return _doc_no
        End Get
        Set(ByVal value As String)
            _doc_no = value
        End Set
    End Property
    Public Property Status() As String
        Get
            Return _status
        End Get
        Set(ByVal value As String)
            _status = value
        End Set
    End Property

    Public Property AA() As String
        Get
            Return _aa
        End Get
        Set(ByVal value As String)
            _aa = value
        End Set
    End Property

    Public ReadOnly Property ProlicyNo() As String
        Get
            Return _t1 & "-" & _t2 & "-" & _t3 & "-" & _t4 & "-" & _t5
        End Get
    End Property

    Public Property T1() As String
        Get
            Return _t1
        End Get
        Set(ByVal value As String)
            _t1 = value
        End Set
    End Property
    Public Property T2() As String
        Get
            Return _t2
        End Get
        Set(ByVal value As String)
            _t2 = value
        End Set
    End Property
    Public Property T3() As String
        Get
            Return _t3
        End Get
        Set(ByVal value As String)
            _t3 = value
        End Set
    End Property
    Public Property T4() As String
        Get
            Return _t4
        End Get
        Set(ByVal value As String)
            _t4 = value
        End Set
    End Property
    Public Property T5() As String
        Get
            Return _t5
        End Get
        Set(ByVal value As String)
            _t5 = value
        End Set
    End Property
    Public Property Ref_no() As String
        Get
            Return _ref_no
        End Get
        Set(ByVal value As String)
            _ref_no = value
        End Set
    End Property
    Public Property InsureName() As String
        Get
            Return _insureName
        End Get
        Set(ByVal value As String)
            _insureName = value
        End Set
    End Property
    Public Property IdCard() As String
        Get
            Return _idCard
        End Get
        Set(ByVal value As String)
            _idCard = value
        End Set
    End Property
    Public Property Fcode() As String
        Get
            Return _fcode
        End Get
        Set(ByVal value As String)
            _fcode = value
        End Set
    End Property
    Public Property Ecode() As String
        Get
            Return _ecode
        End Get
        Set(ByVal value As String)
            _ecode = value
        End Set
    End Property
    Public Property Provinces() As String
        Get
            Return _provinces
        End Get
        Set(ByVal value As String)
            _provinces = value
        End Set
    End Property
    Public Property CarNum() As String
        Get
            Return _carNum
        End Get
        Set(ByVal value As String)
            _carNum = value
        End Set
    End Property
    Public Property Man() As String
        Get
            Return _man
        End Get
        Set(ByVal value As String)
            _man = value
        End Set
    End Property
    Public Property ManName() As String
        Get
            Return _manName
        End Get
        Set(ByVal value As String)
            _manName = value
        End Set
    End Property
    Public Property ManValue() As String
        Get
            Return _manValue
        End Get
        Set(ByVal value As String)
            _manValue = value
        End Set
    End Property
    Public Property Update() As String
        Get
            Return _update
        End Get
        Set(ByVal value As String)
            _update = value
        End Set
    End Property
End Class
