﻿Public Class DT_File
    Private objData As DS_Data = Nothing
    Private objFile As List(Of DS_File) = Nothing
    Private newPath As String
    Private AllowedFileTypes As Dictionary(Of String, ResizeImage.ResizeImage.ImgFormat)

    Public Sub New()    
        AllowedFileTypes = New Dictionary(Of String, ResizeImage.ResizeImage.ImgFormat)
        AllowedFileTypes.Add("image/gif", ResizeImage.ResizeImage.ImgFormat.Gif)
        AllowedFileTypes.Add("image/jpeg", ResizeImage.ResizeImage.ImgFormat.Jpeg)
        AllowedFileTypes.Add("image/pjpeg", ResizeImage.ResizeImage.ImgFormat.Jpeg)
        AllowedFileTypes.Add("image/png", ResizeImage.ResizeImage.ImgFormat.Png)
        AllowedFileTypes.Add("image/Bmp", ResizeImage.ResizeImage.ImgFormat.Bmp)
    End Sub
    Public Sub SaveData()
        ' add data to data base
    End Sub
    Public Function SaveFile(ByVal dsData As DS_Data, ByVal dsFile As List(Of DS_File)) As Boolean
        Dim resize As ResizeImage.ResizeImage = New ResizeImage.ResizeImage()
        Dim found As Boolean = False
        objFile = dsFile
        objData = dsData
        For i As Integer = 0 To objFile.Count - 1
            Try
                If Not FileIO.FileSystem.DirectoryExists(objFile(i).FilePath) Then
                    FileIO.FileSystem.CreateDirectory(objFile(i).FilePath)
                End If


                If (objFile(i).FileType IsNot Nothing) AndAlso (AllowedFileTypes.ContainsKey(objFile(i).FileType)) Then
                    resize.sizeImageByPercent(objFile(i).FileFullPath(), _
                                              objFile(i).FileNewFullPath(), _
                                              30.0, _
                                              CLng(1000), _
                                              AllowedFileTypes.Item(objFile(i).FileType))
                Else
                    FileIO.FileSystem.CopyFile(objFile(i).FileFullPath(), _
                                               objFile(i).FileNewFullPath())
                End If
            Catch ex As Exception
                objFile(i).FileError = False
                found = True
                objFile(i).ErrorDtl = ex.Message
            End Try
            FileIO.FileSystem.DeleteFile(objFile(i).FileFullPath())
        Next i
        If found Then DelError()
        Return found
    End Function
    Private Sub DelError()
        For i As Integer = 0 To objFile.Count - 1
            If objFile(i).FileError Then
                FileIO.FileSystem.DeleteFile(objFile(i).FileNewFullPath())
            End If
        Next i
    End Sub
    Public Sub setPath(ByVal dataPath As String)
        newPath = dataPath
    End Sub
End Class
