﻿Public Partial Class DMSMaster
    Inherits System.Web.UI.MasterPage
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lb_version.Text = "Version: " & New System.IO.FileInfo(Server.MapPath("bin/WebUpLoads.dll")).LastWriteTime.ToString("yyyy.MM.dd.HH.mm.ss")
        Page.Title = "LMG Insurance Co., Ltd."
        setUser = UCase(Request.QueryString("AA"))
        ' setUser = "GR00004"
    End Sub
    Public ReadOnly Property FormName() As String
        Get
            Return form1.ClientID
        End Get
    End Property
    Public WriteOnly Property setHLink() As String
        Set(ByVal value As String)
            lnkH.Text = value
            lnkH.BackColor = Drawing.Color.LawnGreen
        End Set
    End Property

    Public Property setUser() As String
        Set(ByVal value As String)
            lb_user_id.Text = value
        End Set
        Get
            Return lb_user_id.Text
        End Get
    End Property
    Public WriteOnly Property setdocType() As String
        Set(ByVal value As String)
            lb_doc_type.Text = value
        End Set
    End Property
    Public WriteOnly Property setSysName() As String
        Set(ByVal value As String)
            lb_t_sys_nm.Text = value
        End Set
    End Property
    Public Property SysId() As String
        Get
            Return hdnSysId.Value
        End Get
        Set(ByVal value As String)
            hdnSysId.Value = value
        End Set
    End Property
End Class