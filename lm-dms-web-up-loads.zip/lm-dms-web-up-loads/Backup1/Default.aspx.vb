﻿Public Partial Class _Default
    Inherits System.Web.UI.Page
    Private aa As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        aa = Request.QueryString("AA")
        If aa Is Nothing Then
            Dim auth_user() As String = Request.ServerVariables.Item("AUTH_USER").Split("\")
            aa = (auth_user(auth_user.Length - 1)).ToUpper
        End If
        hdnAA.Value = aa
        Page.Title = "LMG Insurance Co., Ltd."
    End Sub

End Class