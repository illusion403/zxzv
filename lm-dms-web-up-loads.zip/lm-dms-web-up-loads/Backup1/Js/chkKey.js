﻿function chkClaimKeyDown()
{
    var dpText = window.event.srcElement;
    var icate = getCaretPosition(dpText);
    
    if(event.keyCode == 8 ||event.keyCode == 46)
        return;
    if((event.keyCode <= 57 && event.keyCode >= 48) || 
       (event.keyCode <= 105 && event.keyCode >= 96) ||
       (event.keyCode <= 110 && event.keyCode >= 109) ||
       (event.keyCode == 190 ) )
    {
        if(icate == 3 )
        {
            //alert(dpText.value.charAt (icate));
           icate = icate +3;
            dpText.value = event.keyCode;
        }
        
        event.returnValue = true;
    }
    else
    {
        event.returnValue = false;
    }

}
function getCaretPosition(obj)
{
    var i = obj.value.length+1;
    if(obj.createTextRange)
    {
        objCaret = document.selection.createRange().duplicate();
        while(objCaret.parentElement()==obj && objCaret.move("character",1)==1) --i;
    }
    return i;
}