﻿Partial Public Class Upload
    Inherits System.Web.UI.Page

    Private sys_id As String
    Public doc_id As String
    Private sub_id As String
    Private doc_no As String
    Private region As String
    Private party_key As String
    Private office_code As String
    Private program_name As String
    Private Lvl As String
    Private aa As String
    Private groupId As String
    Private dt As DataTable
    Private tl As System.Web.UI.WebControls.ListItem
    ' Upload.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&region={4}&party_key={5}&office_code={6}&program_nm={7}
    Private daMenu As DA_Menu = New DA_Menu(ConfigurationSettings.AppSettings.Get("DB"))
    Private config_region As String = ConfigurationSettings.AppSettings.Get("Region")
    Private DMS_share As String = System.Configuration.ConfigurationSettings.AppSettings("DMS_share")
    Private UW_Share As String = System.Configuration.ConfigurationManager.AppSettings("UW_Share")
    Private MEMO_share As String = System.Configuration.ConfigurationSettings.AppSettings("MEMO_share")
    Private DMSUW_share As String = System.Configuration.ConfigurationSettings.AppSettings("UW_Share")
    Private DMSFN_share As String = System.Configuration.ConfigurationSettings.AppSettings("DMSFN_share")
    Private URL_LINK As String = System.Configuration.ConfigurationSettings.AppSettings("URL_LINK")
    Private MysendInfo As New wsSendInformation.SendData
    Private MyGetReqData As New GetDMS_Require.ImageService1
    Private err_page As String = ConfigurationSettings.AppSettings.Get("error_page")
    Private Intranet_flag As String = ConfigurationSettings.AppSettings.Get("Intranet")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            loadPage()
        End If
        loadData()
    End Sub


    Sub loadData()
        sys_id = Request.QueryString("sys_id")
        doc_id = Request.QueryString("doc_id")
        sub_id = Request.QueryString("sub_id")
        doc_no = Request.QueryString("doc_no")
        region = Request.QueryString("region")
        party_key = Request.QueryString("party_key")
        office_code = Request.QueryString("office_code")
        program_name = Request.QueryString("program_nm")
        aa = UCase(Request.QueryString("AA"))
    End Sub

    Private Sub loadPage()
        Session("ObjSave") = Nothing
        DA_File.arrFile.Clear()
        dt = setData()
        Dim dr As DataRow = dt.NewRow

        sys_id = Request.QueryString("sys_id")
        doc_id = Request.QueryString("doc_id")
        sub_id = Request.QueryString("sub_id")
        doc_no = Request.QueryString("doc_no")
        region = Request.QueryString("region")
        party_key = Request.QueryString("party_key")
        office_code = Request.QueryString("office_code")
        program_name = Request.QueryString("program_nm")
        aa = UCase(Request.QueryString("AA"))

        'sys_id = "1"
        'doc_id = "1"
        'sub_id = "1"
        'doc_no = "00-AV1-00001229-00000-2005-02"
        'region = "bangkok"
        'office_code = "00"
        'program_name = "DMS"
        'aa = "GR00004"

        dr("sys_id") = sys_id
        dr("doc_id") = doc_id
        dr("sub_id") = sub_id
        dr("doc_no") = doc_no
        dr("region") = region
        dr("party_key") = party_key
        dr("office_code") = office_code
        dr("program_name") = program_name
        dr("aa") = aa
        If URL_LINK = "DMS" Then
            lb_remrak.Visible = False
            tb_remrak.Visible = False
        End If
        dt.Rows.Add(dr)
        hndData.DataSource = dt
        hndData.DataBind()
        Try
            groupId = daMenu.getGroupID(sys_id, aa)

            If groupId <> String.Empty Then

                dt = daMenu.getDocMain(sys_id, doc_id, groupId)

                Lvl = daMenu.getLvl(groupId)
                CType(Master, DMSMaster).setSysName = daMenu.getDocSubSt(sys_id, doc_id, sub_id)
                If Lvl = "U" Or Lvl = "L" Then


                    ddlGroupData.DataSource = dt
                    ddlGroupData.DataTextField = "doc_main_name"
                    ddlGroupData.DataValueField = "Doc_main_id"
                    ddlGroupData.DataBind()

                    If doc_id <> "0" Then
                        ddlGroupData.SelectedValue = doc_id
                        ddlGroupData.Enabled = False
                    End If

                    List_subid()

                    If (doc_no <> "") Then
                        txtClaimId.Text = doc_no
                        txtClaimId.ReadOnly = True
                    End If



                    If (region <> "") Then
                        ddlJob.SelectedValue = region
                    Else
                        ddlJob.SelectedValue = config_region
                    End If

                    ddlJob.Enabled = False

                    If ddlType.SelectedValue <> "0" And party_key = "" Then
                        List_type()
                        If ddlType.SelectedValue = "OD" Then
                            txtNo.Enabled = False
                        End If
                    End If
                Else
                    Response.Redirect(err_page)
                End If
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub

    Private Sub List_subid()
        groupId = daMenu.getGroupID(hndData.Rows(0).Cells(0).Text, aa)

        If sub_id Is Nothing Then
            sub_id = "0"
        End If

        'dt = daMenu.getDocSub(sys_id, doc_id, groupId, sub_id)

        dt = daMenu.getDocSub(hndData.Rows(0).Cells(0).Text, ddlGroupData.SelectedValue, groupId, sub_id)
        If party_key = "" Then

            ddlTypeData.DataSource = dt
            ddlTypeData.DataTextField = "doc_submain_nm"
            ddlTypeData.DataValueField = "doc_submain_id"
            ddlTypeData.DataBind()

            ddlType.Enabled = True
        ElseIf party_key = "0" Then
            For Each p As DataRow In dt.Rows
                If p("split_doc_flag") = "I" Or p("split_doc_flag") = "N" Or p("split_doc_flag") = "Y" Then
                    tl = New System.Web.UI.WebControls.ListItem
                    tl.Text = p("doc_submain_nm")
                    tl.Value = p("doc_submain_id")
                    ddlTypeData.Items.Add(tl)
                End If
            Next

            tl = New System.Web.UI.WebControls.ListItem
            tl.Text = "กรุณาระบุ"
            tl.Value = "0"
            ddlTypeData.Items.Add(tl)
            ddlTypeData.DataBind()

            ddlType.SelectedValue = "OD"
            txtNo.Text = ""
            ddlType.Enabled = False
        Else
            For Each p As DataRow In dt.Rows
                If p("split_doc_flag") = "T" Or p("split_doc_flag") = "Y" Then
                    tl = New System.Web.UI.WebControls.ListItem
                    tl.Text = p("doc_submain_nm")
                    tl.Value = p("doc_submain_id")
                    ddlTypeData.Items.Add(tl)
                End If
            Next
            tl = New System.Web.UI.WebControls.ListItem
            tl.Text = "กรุณาระบุ"
            tl.Value = "0"
            ddlTypeData.Items.Add(tl)
            ddlTypeData.DataBind()

            ddlType.SelectedValue = "TP"
            txtNo.Text = party_key
            ddlType.Enabled = False
            txtNo.Enabled = False
        End If

        If sub_id <> "0" Then
            Dim chk_id As String = "N"
            For s As Integer = 0 To ddlTypeData.Items.Count - 1
                If ddlTypeData.Items(s).Value = sub_id Then
                    chk_id = "Y"
                    Exit For
                End If
            Next
            If chk_id = "Y" Then
                ddlTypeData.SelectedValue = sub_id
                ddlTypeData.Enabled = False
            Else
                ddlTypeData.SelectedValue = "0"
            End If
        Else
            ddlTypeData.SelectedValue = "0"
            ddlTypeData.Enabled = True
        End If
    End Sub

    Private Sub List_type()
        Dim t_split_doc_flag As String = daMenu.getDocFlag(hndData.Rows(0).Cells(0).Text, ddlGroupData.SelectedValue, ddlTypeData.SelectedValue)

        If t_split_doc_flag = "Y" Then
            ddlType.Enabled = True
            txtNo.Enabled = True
        Else
            ddlType.Enabled = False
            If (t_split_doc_flag = "N") Or (t_split_doc_flag = "I") Then
                ddlType.SelectedValue = "OD"
                txtNo.Text = ""
                txtNo.Enabled = False
            Else
                ddlType.SelectedValue = "TP"
                txtNo.Text = "1"
                txtNo.Enabled = True
            End If
        End If
    End Sub
    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim lstSave As List(Of DS_File) = Nothing
        Dim dsData As DS_Data = Nothing
        Dim t_party_key As String = ""
        Dim dtData As DT_File = New DT_File()
        Dim p_step As String = "0"
        Try
            If Session("ObjSave") IsNot Nothing Then


                lstSave = CType(Session("ObjSave"), List(Of DS_File))
                dsData = New DS_Data()
                If URL_LINK <> "DMS" And tb_remrak.Text.Trim.Length = 0 Then
                    lb_message.Text = "กรุณาระบุเหตุผลที่ต้องทำการ Upload"
                    Exit Sub
                End If

                Dim t_doc_no As String = txtClaimId.Text.Trim.Replace("-", "")
                Dim format = Now.GetDateTimeFormats
                Dim formatdate = format(105)
                Dim filedate As String

                filedate = "D" + Replace(Mid(formatdate, 1, 10), "-", "") + Mid(formatdate, 11, 9)
                filedate = filedate.Replace(":", "")
                filedate = filedate.Replace(" ", "")
                dt = createTable()
                'If dsData.TypeValue <> "0" Then
                For i As Integer = 0 To lstSave.Count - 1
                    'Dim dsFile As DS_File = lstSave(i)

                    lstSave(i).FileNew = t_doc_no & filedate & "_" & Trim(Str(i + 1)) & Mid(lstSave(i).FileName, lstSave(i).FileName.Trim.LastIndexOf(".") + 1)
                    Dim save_path As String = ""
                    Dim doc_form As String

                    doc_form = daMenu.getDocform(hndData.Rows(0).Cells(0).Text, hndData.Rows(0).Cells(1).Text, hndData.Rows(0).Cells(2).Text)
                    save_path = daMenu.get_path(hndData.Rows(0).Cells(0).Text, ddlJob.SelectedValue, Intranet_flag, "")
                    ' Start remove moo
                    'If (InStr(1, LCase(doc_form), "-memo") > 0) Then
                    '    save_path = MEMO_share.Substring(0, MEMO_share.Length - 1)
                    'ElseIf hndData.Rows(0).Cells(0).Text <> "4" Then
                    '    save_path = DMS_share & ddlJob.SelectedValue
                    'Else
                    '    save_path = UW_Share & ddlJob.SelectedValue
                    'End If
                    ' End remove moo
                    p_step = save_path
                    If (InStr(1, LCase(doc_form), "-memo") > 0) Then
                        save_path &= "MEMO\"
                        'ElseIf hndData.Rows(0).Cells(0).Text = "4" Then
                        '    save_path = DMSUW_share & ddlJob.SelectedValue
                        'ElseIf hndData.Rows(0).Cells(0).Text = "5" Or hndData.Rows(0).Cells(0).Text = "6" Then
                        '    save_path = DMSFN_share & ddlJob.SelectedValue
                    Else
                        save_path &= ddlJob.SelectedValue & "\"
                    End If

                    'If IsDBNull(dr.Item("new_vol_flag")) Or dr.Item("new_vol_flag").ToString = "N" Then
                    '    t_date_path = ""
                    'Else
                    '    t_date_path = CDate(dr.Item("create_date").ToString).ToString("yyyy\\MM\\")
                    'End If

                    '   If UCase(save_path).StartsWith("\\SV") Then
                    save_path &= Now().ToString("yyyy\\MM") & "\" 'Replace(Now.GetDateTimeFormats()(105), "-", "\").Substring(0, 8) '
                    '  Else
                    '   save_path = Server.MapPath(save_path) & "/" & Now().ToString("yyyy/MM") & "/"
                    '   End If
                    lstSave(i).FilePath = save_path

                    Dim dr As DataRow
                    dr = dt.NewRow()
                    dr("SYSTEM_ID") = hndData.Rows(0).Cells(0).Text ' sys_id
                    dr("MAIN_ID") = ddlGroupData.SelectedValue
                    dr("SUBMAIN_ID") = ddlTypeData.SelectedValue
                    dr("DOC_NO") = txtClaimId.Text
                    If ddlType.SelectedValue = "OD" Then
                        t_party_key = "IN001"
                    Else
                        t_party_key = "TP" & Right((Val(txtNo.Text) + 1000).ToString, 3)
                    End If
                    dr("DOC_TYPE") = t_party_key
                    dr("FILE_NAME") = lstSave(i).FileNew
                    dr("FILE_NO") = (i + 1).ToString.Trim
                    dr("USER_ID") = hndData.Rows(0).Cells(hndData.Rows(0).Cells.Count - 1).Text ' aa
                    dr("REGION") = ddlJob.SelectedValue
                    If hndData.Rows(0).Cells(6).Text <> "" Then
                        dr("OFFICE_CODE") = hndData.Rows(0).Cells(6).Text
                    Else
                        If CInt(hndData.Rows(0).Cells(0).Text) <= 4 Then
                            dr("OFFICE_CODE") = Mid(txtClaimId.Text, 1, 2) ' office_code
                        Else
                            dr("OFFICE_CODE") = "00"
                        End If
                    End If
                    If hndData.Rows(0).Cells(7).Text <> "" Then
                        dr("APP_CALLER") = hndData.Rows(0).Cells(7).Text ' program_name
                    Else
                        dr("APP_CALLER") = "I-DMS"
                    End If
                    dr("REMARK") = tb_remrak.Text.Trim
                    dr("ARCHIVE_FLAG") = "N"
                    dr("FILE_DESC") = lstSave(i).DesFile
                    dr("new_vol_flag") = "Y"
                    dt.Rows.Add(dr)
                Next i

                If Not dtData.SaveFile(dsData, lstSave) Then
                    Dim ds As New DataSet
                    Dim fsave As Boolean = True
                    ds.Tables.Add(dt)
                    Try
                        Dim res As DataSet = MysendInfo.SendInformation(ds)
                        Dim ws_retrun = From wsr In res.Tables("WS_RETURN") _
                Where wsr.Item("WS_RETURE_CODE") = "-1" _
                Select wsr.Item("FILE_NAME")
                        If ws_retrun.Count = 0 Then
                            Dim ds_getdoc As New DataSet
                            Dim myDataRow1 As DataRow
                            Dim r As Integer = 1
                            Dim message As String = "เอกสารที่ต้อง Upload เพิ่มมีดังนี้\n"
                            ds_getdoc = MyGetReqData.wsDMS_Require_DS(txtClaimId.Text.ToUpper.Trim, hndData.Rows(0).Cells(0).Text, _
                            ddlGroupData.SelectedValue.ToString.Trim, ddlTypeData.SelectedValue.ToString.Trim, t_party_key)
                            If ds_getdoc.Tables("Search_REQUIRE_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
                                For Each myDataRow1 In ds_getdoc.Tables("t_require").Rows
                                    message = message & r.ToString.Trim & ". " & myDataRow1.Item("doc_submain_nm") & "\n"
                                    r = r + 1
                                Next
                                Dim scriptString As String = "<script type=text/javascript>"
                                scriptString += "alert('" + message + "');"
                                scriptString += "</script>"
                                If (IsStartupScriptRegistered("MessageBox") <> True) Then
                                    Page.RegisterStartupScript("ShowMessage", scriptString)
                                End If

                            End If
                        Else
                            fsave = False
                            lb_message.Text = "Insert data error: " & ws_retrun.ToString
                        End If

                    Catch ex As Exception
                        fsave = False
                        lb_message.Text = ex.Message()

                    End Try
                    If fsave Then
                        lb_message.Text = String.Empty
                        'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('" + "ทำการ Uploads File เรียบร้อยแล้ว" + "');", True)
                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "setData", "setData();", True)
                        'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Close", "window.close();", True)
                    End If
                Else
                    Dim stErr As String = String.Empty
                    For i As Integer = 0 To lstSave.Count - 1
                        If lstSave(i).FileError = False Then
                            stErr &= lstSave(i).ErrorDtl & "\n"
                        End If
                    Next i
                    lb_message.Text = stErr

                End If

            Else
                lb_message.Text = "Not Session"

            End If
        Catch ex As Exception
            'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
            lb_message.Text = ex.Message

        Finally
            Session("ObjSave") = New List(Of DS_File)
        End Try
    End Sub

    Private Function createTable() As DataTable
        Dim MyTable As New DataTable
        Dim MyColumn As New DataColumn

        MyTable.TableName = "InputData"
        MyColumn = New DataColumn("SYSTEM_ID", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("MAIN_ID", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("SUBMAIN_ID", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("DOC_NO", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("DOC_TYPE", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("FILE_NAME", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("FILE_NO", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("USER_ID", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("REGION", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("OFFICE_CODE", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("APP_CALLER", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("REMARK", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("ARCHIVE_FLAG", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("FILE_DESC", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("new_vol_flag", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        Return MyTable
    End Function
    Private Function setData() As DataTable
        Dim mytable As DataTable = New DataTable()
        For Each col As DataControlField In hndData.Columns
            mytable.Columns.Add(col.HeaderText)
        Next col
        Return mytable
    End Function


    Public Function getSaveName() As String
        Return btnSave.ClientID
    End Function

    Protected Sub ddlGroupData_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlGroupData.SelectedIndexChanged
        List_subid()
    End Sub
End Class