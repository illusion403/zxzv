Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging

Partial Public Class UploadDoc
    Inherits System.Web.UI.Page
    Private sys_id As String
    Public doc_id As String
    Private sub_id As String
    Private doc_no As String
    Private party_key As String
    Private office_code As String
    Private program_name As String
    Private Lvl As String
    Private aa As String
    Private groupId As String
    Private myconn As SqlConnection
    Private mycommand As SqlCommand
    Private myda As SqlDataAdapter
    Private myds As DataSet
    Private myDataRow As DataRow
    Private mysql As String
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")
    Private DMS_share As String = System.Configuration.ConfigurationSettings.AppSettings("DMS_share")
    Private DMSUW_share As String = System.Configuration.ConfigurationSettings.AppSettings("DMSUW_share")
    Private DMSFN_share As String = System.Configuration.ConfigurationSettings.AppSettings("DMSFN_share")
    Private MEMO_share As String = System.Configuration.ConfigurationSettings.AppSettings("MEMO_share")
    Private Region As String = System.Configuration.ConfigurationSettings.AppSettings("Region")
    Private Memo_Orj As String = System.Configuration.ConfigurationSettings.AppSettings("Memo_Orj")
    Private URL_LINK As String = System.Configuration.ConfigurationSettings.AppSettings("URL_LINK")
    Private daMenu As DA_Menu = New DA_Menu(ConfigurationSettings.AppSettings.Get("DB"))
    Private Intranet_flag As String = ConfigurationSettings.AppSettings.Get("Intranet")
    Protected WithEvents TB_doc_main As System.Web.UI.WebControls.TextBox
    Protected WithEvents TB_doc_sub As System.Web.UI.WebControls.TextBox
    Protected WithEvents TB_doc_no As System.Web.UI.WebControls.TextBox
    Protected WithEvents TB_sysid As System.Web.UI.WebControls.TextBox
    Protected WithEvents TB_docid As System.Web.UI.WebControls.TextBox
    'Protected WithEvents LB_Header1 As System.Web.UI.WebControls.Label
    'Protected WithEvents LB_Header2 As System.Web.UI.WebControls.Label
    Protected WithEvents LB_Remark As System.Web.UI.WebControls.Label
    Protected WithEvents lb_doc As System.Web.UI.WebControls.Label
    Protected WithEvents TB_Remark As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents TB_subid As System.Web.UI.WebControls.TextBox

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents DropDownList2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents RangeValidator1 As System.Web.UI.WebControls.RangeValidator
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents FILE1 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents FILE2 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents FILE3 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents FILE4 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents FILE5 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents FILE6 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents FILE7 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents FILE8 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            'Me.Button1.Attributes.Add("onClick", "return buttonClick('Button1');")
            myconn = New SqlConnection(DMS_data)
            If (Request.QueryString("sys_id") <> "") And (Request.QueryString("doc_id") <> "") And _
            (Request.QueryString("sub_id") <> "") And (Request.QueryString("doc_no") <> "") Then
                TB_sysid.Text = Request.QueryString("sys_id")
                TB_docid.Text = Request.QueryString("doc_id")
                TB_subid.Text = Request.QueryString("sub_id")
                Label3.Text = "�������͡���"
                Label6.Text = "������"
                Label4.Text = "�ӴѺ���"
                lb_doc.Text = "������͡���"
                LB_Remark.Text = "�˵ؼ�㹡�� Upload"
                RangeValidator1.Text = "������Ţ 1-99"
                RangeValidator1.ErrorMessage = "�����������١��ͧ"
                DropDownList2.Items.Add(New ListItem("�����һ�Сѹ", "OD"))
                DropDownList2.Items.Add(New ListItem("���ó�", "TP"))
                If TB_sysid.Text = "4" Then
                    Label1.Text = "�Ţ����������"
                ElseIf TB_sysid.Text = "5" Then
                    Label1.Text = "���ʵ��᷹"
                ElseIf TB_sysid.Text = "1" Or TB_sysid.Text = "2" Or TB_sysid.Text = "3" Then
                    Label1.Text = "�Ţ������"
                    Dim t_Archive As String
                    Dim n As Integer
                    Dim wup_data As String = System.Configuration.ConfigurationSettings.AppSettings("WUP_data")
                    'Dim URL_LINK As String = System.Configuration.ConfigurationSettings.AppSettings("URL_LINK")
                    Dim dr As DataRow
                    Dim myconnWUP As SqlConnection

                    If TB_sysid.Text <> "3" Then


                        If URL_LINK = "DMS" Then
                            t_Archive = "AND (ISNULL(Archive_Flag, 'N') IN ('Y', 'H')) "
                        Else
                            t_Archive = ""
                        End If
                        mysql = "SELECT ISNULL(Archive_Flag, 'N') AS Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date " & _
                        "FROM dbo.DMS_ClaimMonitor " & _
                        "WHERE (CLAIM_NO = '" & Request.QueryString("doc_no") & "') " & t_Archive & _
                        "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"
                        Try
                            myconnWUP = New SqlConnection(wup_data)
                            myda = New SqlDataAdapter(mysql, myconnWUP)
                            myds = New DataSet
                            myconnWUP.Open()
                            myda.Fill(myds, "t_Archive")
                            myconnWUP.Close()
                        Catch ex As Exception
                            If myconnWUP.State = ConnectionState.Open Then
                                myconnWUP.Close()
                            End If
                        End Try

                        mysql = "SELECT ISNULL(Archive_Flag, 'N') AS Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date " & _
                        "FROM dbo.DMS_maindocument " & _
                        "WHERE (doc_no = '" & Request.QueryString("doc_no") & "') " & t_Archive & _
                        "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"
                        Try
                            myconn = New SqlConnection(DMS_data)
                            myda = New SqlDataAdapter(mysql, myconn)
                            myconn.Open()
                            myda.Fill(myds, "t_Archive")
                            myconn.Close()
                        Catch ex As Exception
                            If myconn.State = ConnectionState.Open Then
                                myconn.Close()
                            End If
                        End Try
                        Try
                            n = myds.Tables("t_Archive").Rows.Count
                        Catch ex As Exception
                            n = 0
                        End Try
                        If URL_LINK = "DMS" Then
                            If n <> 0 Then
                                Label2.Text = "�����Ź������价�� "
                                Notupload()
                            Else
                                Dim t_hk As String = "N"
                                Dim t_hk_date As String
                                For Each dr In myds.Tables("t_Archive").Rows
                                    If dr.Item("Archive_Flag").ToString = "H" Then
                                        t_hk = "Y"
                                        t_hk_date = dr.Item("Archive_Date").ToString
                                        Exit For
                                    End If
                                Next
                                If t_hk = "Y" Then
                                    Label2.Text = "�����Ź��Դ����" & " ������ѹ��� " & t_hk_date
                                    Notupload()
                                End If

                            End If
                        Else
                            If n = 0 Then
                                Label2.Text = "�����Ź���ѧ���١ Archive"
                                Notupload()
                            Else
                                Dim t_hk As String = "N"
                                Dim t_hk_date As String
                                For Each dr In myds.Tables("t_Archive").Rows
                                    If dr.Item("Archive_Flag").ToString = "H" Then
                                        t_hk = "Y"
                                        t_hk_date = dr.Item("Archive_Date").ToString
                                        Exit For
                                    End If
                                Next
                                If t_hk = "Y" Then
                                    Label2.Text = "�����Ź��Դ����" & " ������ѹ��� " & t_hk_date
                                    Notupload()
                                End If
                            End If
                        End If
                    End If
                Else
                    Label1.Text = "�Ţ����͡���"
                End If
                Dim t_sys_nm As String
                mysql = "SELECT system_name " & _
                "FROM dbo.DMS_system " & _
                "WHERE (system_id = '" & Request.QueryString("sys_id") & "') "
                myconn.Open()
                mycommand = New SqlCommand(mysql, myconn)
                t_sys_nm = mycommand.ExecuteScalar
                myconn.Close()

                mysql = "SELECT doc_main_name " & _
                "FROM dbo.DMS_doc_main " & _
                "WHERE (system_id = '" & Request.QueryString("sys_id") & "') " & _
                "AND (doc_main_id = " & Request.QueryString("doc_id") & ")"
                myconn.Open()
                mycommand = New SqlCommand(mysql, myconn)
                TB_doc_main.Text = Trim(mycommand.ExecuteScalar)
                myconn.Close()

                mysql = "SELECT ISNULL(doc_group_submain + ' -', '') + REPLACE(REPLACE(doc_submain_nm,'&nbsp;', ''), ' - ', '') AS doc_submain_nm " & _
                "FROM dbo.DMS_doc_submain " & _
                "WHERE (system_id = '" & Request.QueryString("sys_id") & "') " & _
                "AND (doc_main_id = " & Request.QueryString("doc_id") & ") " & _
                "AND (doc_submain_id = " & Request.QueryString("sub_id") & ")"
                myconn.Open()
                mycommand = New SqlCommand(mysql, myconn)
                TB_doc_sub.Text = mycommand.ExecuteScalar
                myconn.Close()
                TB_doc_no.Text = Request.QueryString("doc_no")
                If TB_sysid.Text <> "5" Then
                    Label4.Visible = True
                    Label6.Visible = True
                    DropDownList2.Visible = True
                    TextBox2.Visible = True
                    List_type(Request.QueryString("sys_id"), Request.QueryString("doc_id"), Request.QueryString("sub_id"))
                Else
                    Label4.Visible = False
                    Label6.Visible = False
                    DropDownList2.Visible = False
                    TextBox2.Visible = False
                End If
                If URL_LINK = "DMS" Then
                    LB_Remark.Visible = False
                    TB_Remark.Visible = False
                Else
                    LB_Remark.Visible = True
                    TB_Remark.Visible = True
                End If
            Else
                Label2.Text = "Error"
            End If
        End If
        loadData()
    End Sub
    Sub loadData()
        sys_id = Request.QueryString("sys_id")
        doc_id = Request.QueryString("doc_id")
        sub_id = Request.QueryString("sub_id")
        doc_no = Request.QueryString("doc_no")
        Region = Request.QueryString("region")
        party_key = Request.QueryString("party_key")
        office_code = Request.QueryString("office_code")
        program_name = Request.QueryString("program_nm")
        aa = UCase(Request.QueryString("AA"))
    End Sub

    Private Sub Notupload()
        Button1.Visible = False
        FILE1.Visible = False
        FILE2.Visible = False
        FILE3.Visible = False
        FILE4.Visible = False
        FILE5.Visible = False
        FILE6.Visible = False
        FILE7.Visible = False
        FILE8.Visible = False
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim fileName(10), chk_file, t_doc_no, t_party_key As String
        Dim t_date_path As String
        'System.Threading.Thread.Sleep(10000)
        myconn = New SqlConnection(DMS_data)
        If URL_LINK <> "DMS" And Len(Trim(TB_Remark.Text)) = 0 Then
            Label2.Text = "��س��к��˵ؼŷ���ͧ�ӡ�� Upload"
        Else
            chk_file = "0"
            Label2.Text = ""
            TB_doc_no.DataBind()
            If ((Mid(DropDownList2.SelectedItem.Text, 1, 2) <> "TP") Or _
            (Mid(DropDownList2.SelectedItem.Text, 1, 2) = "TP" And TextBox2.Text.Trim.Length <> 0)) And _
            (TB_doc_no.Text.Trim.Length <> 0) Then

                Dim i, j As Integer
                Dim tot_size As Decimal
                Dim filedest As String
                Dim format = Now.GetDateTimeFormats
                Dim formatdate = format(103)
                Dim filedate As String
                'MEMO to file
                mysql = "SELECT doc_form " & _
                "FROM dbo.DMS_doc_submain " & _
                "WHERE (system_id = " & TB_sysid.Text & ") " & _
                "AND (doc_main_id = " & TB_docid.Text & ") " & _
                "AND (doc_submain_id = " & TB_subid.Text & ") "
                myconn.Open()
                mycommand = New SqlCommand(mysql, myconn)
                Dim doc_form_memo As String = mycommand.ExecuteScalar
                myconn.Close()

                t_date_path = Now().ToString("yyyy\\MM\\")
                '(sys_id = 1) And (doc_id = 1) And (sub_id = 2)
                filedest = daMenu.get_path(TB_sysid.Text, Region, Intranet_flag, "")
                If (InStr(1, LCase(doc_form_memo), "-memo") > 0) Then
                    filedest = MEMO_share & t_date_path
                    'Else
                    '    If TB_sysid.Text = "4" Then
                    '        filedest = DMSUW_share & Region & "\" & t_date_path
                    '    ElseIf TB_sysid.Text = "5" Then
                    '        filedest = DMSFN_share & Region & "\" & t_date_path
                    '    Else
                    '        filedest = DMS_share & Region & "\" & t_date_path
                    '    End If
                End If
                filedate = "D" + Replace(Mid(formatdate, 1, 10), "-", "") + "T" + Mid(formatdate, 12, 8)
                filedate = filedate.Replace(":", "")
                filedate = filedate.Replace(" ", "")
                Try
                    ' Upload File	
                    i = 1
                    t_doc_no = TB_doc_no.Text.Trim.Replace("-", "")

                    If Not (FILE1.PostedFile.FileName = "") Then
                        tot_size = tot_size + FILE1.PostedFile.ContentLength
                    End If
                    If Not (FILE2.PostedFile.FileName = "") Then
                        tot_size = tot_size + FILE2.PostedFile.ContentLength
                    End If
                    If Not (FILE3.PostedFile.FileName = "") Then
                        tot_size = tot_size + FILE3.PostedFile.ContentLength
                    End If
                    If Not (FILE4.PostedFile.FileName = "") Then
                        tot_size = tot_size + FILE4.PostedFile.ContentLength
                    End If
                    If Not (FILE5.PostedFile.FileName = "") Then
                        tot_size = tot_size + FILE5.PostedFile.ContentLength
                    End If
                    If Not (FILE6.PostedFile.FileName = "") Then
                        tot_size = tot_size + FILE6.PostedFile.ContentLength
                    End If
                    If Not (FILE7.PostedFile.FileName = "") Then
                        tot_size = tot_size + FILE7.PostedFile.ContentLength
                    End If
                    If Not (FILE8.PostedFile.FileName = "") Then
                        tot_size = tot_size + FILE8.PostedFile.ContentLength
                    End If
                    If tot_size > 2048000 Then
                        Label2.Text = "<P>��Ҵ��������ͧ����Թ 2,048,000 KB</P><P>��Ҵ��� � �͹��� ��� " & FormatNumber(tot_size, 0) & " KB</P>"
                        Exit Sub
                    End If
                    If Not (FILE1.PostedFile.FileName = "") Then
                        fileName(i) = t_doc_no & filedate & "_" & Trim(Str(i)) & _
                        Mid(FILE1.PostedFile.FileName, FILE1.PostedFile.FileName.Trim.LastIndexOf(".") + 1)
                        FILE1.PostedFile.SaveAs(filedest & fileName(i))
                        chk_file = "1"
                        i = i + 1
                    End If
                    If Not (FILE2.PostedFile.FileName = "") Then
                        fileName(i) = t_doc_no & filedate & "_" & Trim(Str(i)) & _
                        Mid(FILE2.PostedFile.FileName, FILE2.PostedFile.FileName.Trim.LastIndexOf(".") + 1)
                        FILE2.PostedFile.SaveAs(filedest & fileName(i))
                        chk_file = "1"
                        i = i + 1
                    End If
                    If Not (FILE3.PostedFile.FileName = "") Then
                        fileName(i) = t_doc_no & filedate & "_" & Trim(Str(i)) & _
                        Mid(FILE3.PostedFile.FileName, FILE3.PostedFile.FileName.Trim.LastIndexOf(".") + 1)
                        FILE3.PostedFile.SaveAs(filedest & fileName(i))
                        chk_file = "1"
                        i = i + 1
                    End If
                    If Not (FILE4.PostedFile.FileName = "") Then
                        fileName(i) = t_doc_no & filedate & "_" & Trim(Str(i)) & _
                        Mid(FILE4.PostedFile.FileName, FILE4.PostedFile.FileName.Trim.LastIndexOf(".") + 1)
                        FILE4.PostedFile.SaveAs(filedest & fileName(i))
                        chk_file = "1"
                        i = i + 1
                    End If
                    If Not (FILE5.PostedFile.FileName = "") Then
                        fileName(i) = t_doc_no & filedate & "_" & Trim(Str(i)) & _
                        Mid(FILE5.PostedFile.FileName, FILE5.PostedFile.FileName.Trim.LastIndexOf(".") + 1)
                        FILE5.PostedFile.SaveAs(filedest & fileName(i))
                        chk_file = "1"
                        i = i + 1
                    End If
                    If Not (FILE6.PostedFile.FileName = "") Then
                        fileName(i) = t_doc_no & filedate & "_" & Trim(Str(i)) & _
                        Mid(FILE6.PostedFile.FileName, FILE6.PostedFile.FileName.Trim.LastIndexOf(".") + 1)
                        FILE6.PostedFile.SaveAs(filedest & fileName(i))
                        chk_file = "1"
                        i = i + 1
                    End If
                    If Not (FILE7.PostedFile.FileName = "") Then
                        fileName(i) = t_doc_no & filedate & "_" & Trim(Str(i)) & _
                        Mid(FILE7.PostedFile.FileName, FILE7.PostedFile.FileName.Trim.LastIndexOf(".") + 1)
                        FILE7.PostedFile.SaveAs(filedest & fileName(i))
                        chk_file = "1"
                        i = i + 1
                    End If
                    If Not (FILE8.PostedFile.FileName = "") Then
                        fileName(i) = t_doc_no & filedate & "_" & Trim(Str(i)) & _
                        Mid(FILE8.PostedFile.FileName, FILE8.PostedFile.FileName.Trim.LastIndexOf(".") + 1)
                        FILE8.PostedFile.SaveAs(filedest & fileName(i))
                        chk_file = "1"
                        i = i + 1
                    End If
                    If Mid(DropDownList2.SelectedValue, 1, 2) = "TP" Then
                        t_party_key = "TP" & Right(Str(Val(TextBox2.Text) + 1000), 3)
                    Else
                        t_party_key = "IN001"
                    End If
                    myconn = New SqlConnection(DMS_data)
                    Dim max_pic_no As Integer
                    mysql = "SELECT Max(picture_no) AS max_pic_no " & _
                    "FROM dbo.DMS_loaddocument " & _
                    "WHERE (doc_no = '" & TB_doc_no.Text.Trim & "') " & _
                    "AND (system_id = " & TB_sysid.Text & ") " & _
                    "AND (doc_main_id = " & TB_docid.Text & ") " & _
                    "AND (doc_submain_id = " & TB_subid.Text & ") " & _
                    "AND (doc_type = '" & t_party_key & "')"
                    Try
                        myconn.Open()
                        mycommand = New SqlCommand(mysql, myconn)
                        max_pic_no = mycommand.ExecuteScalar
                        myconn.Close()
                    Catch ex As Exception
                        If myconn.State = ConnectionState.Open Then
                            myconn.Close()
                        End If
                        max_pic_no = 0
                    End Try

                    ''myconn.Open()
                    If chk_file = "1" Then
                        For j = 1 To i - 1
                            mysql = "INSERT INTO dbo.DMS_loaddocument " & _
                                    "(system_id, doc_main_id, doc_submain_id, doc_no, doc_type, picture_no, picture_name, " & _
                                    "create_date, create_by, Region, office_code, program_name, delete_flag, delete_date, delete_by, Remark, new_vol_flag) " & _
                                    "VALUES (" & TB_sysid.Text & ", " & TB_docid.Text & ", " & _
                                    TB_subid.Text & ", '" & TB_doc_no.Text.ToUpper.Trim & "', '" & _
                                    t_party_key & "', " & Trim(Str(max_pic_no + j)) & ", '" & fileName(j) & _
                                    "', GETDATE(), '" & aa & "', '" & Region & "', '" & _
                                    "00', 'I-DMS', 'N', NULL, NULL, '" & TB_Remark.Text.Trim & "', 'Y')"
                            myconn.Open()
                            mycommand = New SqlCommand(mysql, myconn)
                            mycommand.ExecuteNonQuery()
                            myconn.Close()
                        Next
                        Dim cnt_load, row As Integer
                        'For Each myDataRow In Session("dsCount").Tables("DMS_Count_Trans").Select("doc_main_id = '" & TB_docid.Text & _
                        '"' AND doc_submain_id = '" & TB_subid.Text & "'")
                        '    cnt_load = Val(myDataRow.Item("count_trans")) + (i - 1)
                        '    row = Val(myDataRow.Item("row_index"))
                        'Next
                        'Session("dsCount").Tables("DMS_Count_Trans").Rows(row).Item("count_trans") = cnt_load.ToString.Trim
                        'Session("dsCount").Tables("DMS_Count_Trans").Rows(row).AcceptChanges()

                        Dim Cnt_claim As Integer
                        mysql = "SELECT Count(*) AS cnt_clm FROM dbo.DMS_maindocument " & _
                        "WHERE (system_id = " & TB_sysid.Text & ") " & _
                        "AND (doc_no = '" & TB_doc_no.Text.ToUpper.Trim & "') " & _
                        "AND (doc_main_id = " & TB_docid.Text.Trim & ") "
                        myconn.Open()
                        mycommand = New SqlCommand(mysql, myconn)
                        Cnt_claim = mycommand.ExecuteScalar
                        myconn.Close()
                        If Cnt_claim = 0 Then
                            mysql = "INSERT INTO dbo.DMS_maindocument " & _
                            "(system_id, doc_main_id, doc_no, create_date, Last_update, update_by, Archive_Flag, Approve_Date) " & _
                            "VALUES (" & TB_sysid.Text & ", " & TB_docid.Text.Trim & ", '" & _
                            TB_doc_no.Text.ToUpper.Trim & "', GETDATE(), GETDATE(), '" & Session("USERLOGIN") & _
                            "', NULL, NULL) "
                            myconn.Open()
                            mycommand = New SqlCommand(mysql, myconn)
                            mycommand.ExecuteNonQuery()
                            myconn.Close()
                        Else
                            mysql = "UPDATE dbo.DMS_maindocument " & _
                            "SET Last_update = GETDATE(), " & _
                            "update_by = '" & Session("USERLOGIN") & "' " & _
                            "WHERE (system_id = " & TB_sysid.Text & ") " & _
                            "AND (doc_no = '" & TB_doc_no.Text.ToUpper.Trim & "') " & _
                            "AND (doc_main_id = " & TB_docid.Text.Trim & ") "

                            myconn.Open()
                            mycommand = New SqlCommand(mysql, myconn)
                            mycommand.ExecuteNonQuery()
                            myconn.Close()

                        End If
                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "setData", "setData();", True)
                        'Label2.Text = "�ӡ�� Upload ���º��������"
                    Else
                        Label2.Text = "��س������� File ����ͧ��� Upload"
                    End If
                    'myconn.Close()
                Catch ex As Exception
                    If myconn.State = ConnectionState.Open Then
                        myconn.Close()
                    End If
                    Label2.Text = ex.Message
                End Try
            Else
                If Mid(DropDownList2.SelectedItem.Text, 1, 2) = "TP" And TextBox2.Text.Trim.Length = 0 Then
                    Label2.Text = "��س�����ӴѺ���١��ͧ"
                End If
                If TB_doc_no.Text.Trim.Length = 0 Then
                    Label2.Text = "��س�����Ţ�͡���"
                End If
            End If
        End If

    End Sub
    Private Sub List_type(ByVal t_sys_id As String, ByVal t_doc_id As String, ByVal t_sub_id As String)
        Dim t_split_doc_flag As String
        mysql = "SELECT split_doc_flag " & _
                "FROM dbo.DMS_doc_submain " & _
                "WHERE (system_id = " & t_sys_id & ") " & _
                "AND (doc_main_id = " & t_doc_id & ") " & _
                "AND (doc_submain_id = " & t_sub_id & ") " & _
                "AND (doc_form LIKE 'DMS%')"
        Try
            myconn.Open()
            mycommand = New SqlCommand(mysql, myconn)
            t_split_doc_flag = mycommand.ExecuteScalar
            myconn.Close()
        Catch ex As Exception
            If myconn.State = ConnectionState.Open Then
                myconn.Close()
            End If
            t_split_doc_flag = "N"
        End Try
        If t_split_doc_flag = "Y" Then
            DropDownList2.Enabled = True
            TextBox2.Enabled = True
        Else
            DropDownList2.Enabled = False
            If (t_split_doc_flag = "N") Or (t_split_doc_flag = "I") Then
                DropDownList2.SelectedValue = "OD"
                TextBox2.Text = ""
                '               TextBox2.Enabled = False
            Else
                DropDownList2.SelectedValue = "TP"
                TextBox2.Text = "1"
                '                TextBox2.Enabled = True
            End If
        End If
        If DropDownList2.SelectedValue = "TP" Then
            TextBox2.Enabled = True
        Else
            TextBox2.Enabled = False
        End If

    End Sub

    Private Sub DropDownList2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DropDownList2.SelectedIndexChanged
        If DropDownList2.SelectedValue = "TP" Then
            TextBox2.Text = "1"
            TextBox2.Enabled = True
        Else
            TextBox2.Text = ""
            TextBox2.Enabled = False
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Write("<SCRIPT LANGUAGE='Jscript'>opener='this'</SCRIPT>")
        Response.Write("<SCRIPT LANGUAGE='Jscript'>close()</SCRIPT>")
    End Sub
End Class
