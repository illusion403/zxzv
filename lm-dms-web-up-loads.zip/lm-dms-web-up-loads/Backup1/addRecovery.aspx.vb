﻿Imports System.Data
Imports System.Data.SqlClient

Partial Public Class addRecovery
    Inherits System.Web.UI.Page

    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")
    'Private da As DA_Search = New DA_Search(DTW_data)
    Private daMenu As DA_Menu = New DA_Menu(DMS_data)
    Private dsPolicy As DS_SchPolicy = Nothing
    Private aa As String
    Private region As String
    Private program_name As String
    'Private chkStatus As String
    Private sys_id As String
    Private dt As DataTable = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            PageLoad()
        End If
    End Sub
    Private Sub PageLoad()

        aa = UCase(Request.QueryString("AA"))
        hdnLoad.Value = Request.RawUrl()

        hdnAA.Value = aa
        'daMenu = New DA_Menu(DMS_data)
        'dt = daMenu.getUserRole(sys_id, aa)

        '        CType(Master, DMSMaster).setSysName = dt.Rows(0)("system_name")

    End Sub

    Protected Sub bntReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntReset.Click
        Response.Redirect(hdnLoad.Value)
    End Sub

    Protected Sub bntAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntAdd.Click
        Dim t_FastTack As String = "N"
        Dim t_GroupName As String = "Standard"
        If cb_fast_track.Checked Then
            t_FastTack = "Y"
        End If
        If cb_extra.Checked Then
            t_GroupName = "ALL"
        End If
        daMenu = New DA_Menu(DMS_data)
        If daMenu.InsertRecovery(txtClaim.Text, t_GroupName, t_FastTack, hdnAA.Value) Then
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('บันทึกรายการเรียบร้อย');", True)
            Response.Redirect(hdnLoad.Value)
        Else
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('เกิดความผิดพลาด กรุณาลองใหม่อีกครั้ง');", True)
        End If
    End Sub
End Class