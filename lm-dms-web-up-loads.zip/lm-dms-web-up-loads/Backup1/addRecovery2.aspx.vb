﻿Imports System.Data
Imports System.Data.SqlClient
Partial Public Class addRecovery2
    Inherits System.Web.UI.Page
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")
    'Private da As DA_Search = New DA_Search(DTW_data)
    Private daMenu As DA_Menu = New DA_Menu(DMS_data)
    Private dsPolicy As DS_SchPolicy = Nothing
    Private aa As String
    Private region As String
    Private program_name As String
    'Private chkStatus As String
    Private sys_id As String
    Private dt As DataTable = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadPage()
        End If

    End Sub
    Protected Sub LoadPage()
        aa = UCase(Request.QueryString("AA"))
        Dim txt_url As String = Request.RawUrl()
        If InStr(txt_url, "&") > 0 Then
            txt_url = Mid(txt_url, 1, InStr(txt_url, "&") - 1)
        End If
        hdnLoad.Value = txt_url

        hdnAA.Value = aa
        If (Request.QueryString("claim_no") <> Nothing) Then
            txtClaim.Text = Request.QueryString("claim_no").ToString().ToUpper
        End If
    End Sub

    Protected Sub buttonReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles buttonReset.Click
        Response.Redirect(hdnLoad.Value)
    End Sub

    Private Sub buttonAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles buttonAdd.Click
        Dim t_FastTack As String = "N"
        Dim t_GroupName As String = "Standard"
        If cb_fast_track.Checked Then
            t_FastTack = "Y"
        End If
        If cb_extra.Checked Then
            t_GroupName = "ALL"
        End If
        daMenu = New DA_Menu(DMS_data)
        If daMenu.InsertRecovery(txtClaim.Text.ToUpper, t_GroupName, t_FastTack, hdnAA.Value) Then
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('บันทึกรายการเรียบร้อย');", True)
            Response.Redirect(hdnLoad.Value)
        Else
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('เกิดความผิดพลาด กรุณาลองใหม่อีกครั้ง');", True)
        End If

    End Sub
End Class