﻿Public Partial Class addUnderwite
    Inherits System.Web.UI.Page

    Private dsUnder As DS_Underwrite = Nothing
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")
    Private DWPROD_data As String = System.Configuration.ConfigurationSettings.AppSettings("DWPROD_data")
    Private SETUP_data As String = System.Configuration.ConfigurationSettings.AppSettings("SETUP_data")
    Private daAdd As DA_Search = New DA_Search(DMS_data)
    Private daMenu As DA_Menu = Nothing
    Private dt As DataTable = Nothing
    Private sys_id As String
    Private act_type As String
    Public aa As String
    Private t_month As String
    Private t_year As String
    Private doc_no As String



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            PageLoad()
        End If
    End Sub
    Private Sub PageLoad()
        Try
            sys_id = Request.QueryString("sys_id")
            aa = Request.QueryString("AA")
            doc_no = Request.QueryString("doc_no")

            CType(Master, DMSMaster).setHLink = "<a href='schUnderwite.aspx?sys_id=4&AA=" + aa + "'  id='lnkSearch' target='ifr' >หน้าหลัก</a>"
            If sys_id = 4 Then

                If Request.QueryString("act_type") IsNot Nothing Then
                    bntUpdate.Visible = True
                    bntSave.Visible = False

                    txtT1.Visible = False
                    ddlT2.Visible = False
                    txtT3.Visible = False
                    ddlT4.Visible = False
                    ddlT5.Visible = False
                    TB_policy.Visible = True
                End If

                ' sys_id = "1"
                'aa = CType(Master, DMSMaster).setUser
                hdnSysId.Value = sys_id
                hdnAA.Value = aa
                daMenu = New DA_Menu(SETUP_data)
                dt = daMenu.getProvince()
                ddlProvinces.DataSource = dt
                ddlProvinces.DataTextField = "PROVINCE_NAME"
                ddlProvinces.DataValueField = "KEY_FIELD"
                ddlProvinces.DataBind()

                dt = daMenu.getLob()
                ddlT2.DataSource = dt
                ddlT2.DataTextField = "GT_KEY"
                ddlT2.DataValueField = "GT_KEY"
                ddlT2.DataBind()

                daMenu = New DA_Menu(DMS_data)
                dt = daMenu.getUserRole(sys_id, aa)

                CType(Master, DMSMaster).setSysName = dt.Rows(0)("system_name")
                t_year = dt.Rows(0)("UW_YEAR")
                t_month = dt.Rows(0)("UW_MONTH")

                dt = daMenu.getYear(t_year)
                ddlT4.DataSource = dt
                ddlT4.DataTextField = "YearText"
                ddlT4.DataValueField = "YearValue"
                ddlT4.DataBind()
                ddlT4.SelectedValue = t_year
                dt = daMenu.getMonth()
                ddlT5.DataSource = dt
                ddlT5.DataTextField = "MonthText"
                ddlT5.DataValueField = "MonthValue"
                ddlT5.DataBind()
                ddlT5.SelectedValue = Right(Str(Val(t_month) + 100), 2)

                daMenu = New DA_Menu(DWPROD_data)
                dt = daMenu.getT_Agent()
                ddlManName.DataSource = dt
                ddlManName.DataTextField = "Agent_Code"
                ddlManName.DataValueField = "Agent_Name"
                ddlManName.DataBind()
                If doc_no IsNot Nothing Then
                    ' Bill()
                    dsUnder = daAdd.srhDoc(doc_no)
                    setData()
                End If
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub
    Protected Sub bntSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntSave.Click
        Bill()
        Try
            Dim nFound As Integer = daAdd.insDoc(dsUnder)
            If nFound > -1 Then
                bntSave.Visible = False
                bntUpdate.Visible = True
                Response.Redirect("addUnderwite.aspx?sys_id=" + hdnSysId.Value + "&act_type=EDIT&AA=" + hdnAA.Value + "&doc_no=" + dsUnder.ProlicyNo, True)
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('เพิ่มข้อมูล Error');", True)
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub
    Private Sub Bill()
        dsUnder = New DS_Underwrite()

        dsUnder.T1 = txtT1.Text
        dsUnder.T2 = ddlT2.SelectedValue
        dsUnder.T3 = txtT3.Text
        dsUnder.T4 = ddlT4.SelectedValue
        dsUnder.T5 = ddlT5.SelectedValue
        If txtT1.Text <> String.Empty Then
            dsUnder.Doc_no = dsUnder.ProlicyNo
        Else
            dsUnder.Doc_no = TB_policy.Text
        End If
        dsUnder.Ref_no = txtRef_no.Text
        dsUnder.InsureName = txtInsureName.Text
        dsUnder.IdCard = txtIdCard.Text
        dsUnder.Fcode = txtFcode.Text
        dsUnder.Ecode = txtEcode.Text
        dsUnder.Provinces = ddlProvinces.SelectedValue
        dsUnder.CarNum = txtCarNum.Text
        dsUnder.Man = txtManName.Text
        dsUnder.ManName = ddlManName.Items(ddlManName.SelectedIndex).Text
        dsUnder.ManValue = txtManName.Text
        dsUnder.AA = hdnAA.Value

    End Sub


    Private Sub setData()
        TB_policy.Text = dsUnder.Doc_no    
        ddlT4.SelectedValue = dsUnder.T4
        txtRef_no.Text = dsUnder.Ref_no
        txtInsureName.Text = dsUnder.InsureName
        txtIdCard.Text = dsUnder.IdCard
        txtFcode.Text = dsUnder.Fcode
        txtEcode.Text = dsUnder.Ecode
        ddlProvinces.SelectedValue = dsUnder.Provinces
        txtCarNum.Text = dsUnder.CarNum
        txtManName.Text = dsUnder.ManName
        ddlManName.SelectedValue = dsUnder.ManName
        txtManName.Text = dsUnder.ManName
    End Sub

    Protected Sub bntSchMan_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntSchMan.Click
        Try
            If txtMan.Text.Trim <> String.Empty Then
                daMenu = New DA_Menu(DWPROD_data)
                dt = daMenu.getT_Agent(txtMan.Text)
                ddlManName.DataSource = dt
                ddlManName.DataTextField = "Agent_Code"
                ddlManName.DataValueField = "Agent_Name"
                ddlManName.DataBind()
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub

    Protected Sub bntUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntUpdate.Click
        Try
            Bill()
            daAdd.updDoc(dsUnder)
            Response.Redirect("addUnderwite.aspx?sys_id=" + hdnSysId.Value + "&act_type=EDIT&AA=" + hdnAA.Value + "&doc_no=" + dsUnder.Doc_no, True)
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub

    Protected Sub bntReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntReset.Click
        Response.Redirect("addUnderwite.aspx?sys_id=" + hdnSysId.Value + "&AA=" + hdnAA.Value, True)
    End Sub

    'Protected Sub bntsch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntsch.Click
    '    Response.Redirect("schUnderwite.aspx?sys_id=" + hdnSysId.Value + "&AA=" + hdnAA.Value, True)
    'End Sub
End Class