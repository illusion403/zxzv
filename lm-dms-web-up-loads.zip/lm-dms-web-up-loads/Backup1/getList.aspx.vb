﻿Public Partial Class getList
    Inherits System.Web.UI.Page

    Private doc_no As String
    Private policy As String
    Private licenseno As String
    Private keyfield As String
    Private doc_form As String
    Private cntDoc As Integer
    Private daMenu As DA_Menu = New DA_Menu(ConfigurationSettings.AppSettings.Get("DB"))
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        doc_no = Request.QueryString("doc_no")
        policy = Request.QueryString("policy")
        licenseno = Request.QueryString("licenseno")
        keyfield = Request.QueryString("keyfield")
        doc_form = Request.QueryString("doc_form")
        cntDoc = daMenu.getOther_MenuDoc(doc_form, doc_no, policy, licenseno, keyfield)
        If cntDoc <> 0 Then
            Response.Write(doc_form + "|" + "(" + cntDoc.ToString() + ")")
        Else
            Response.Write(doc_form + "|")
        End If

    End Sub

End Class



