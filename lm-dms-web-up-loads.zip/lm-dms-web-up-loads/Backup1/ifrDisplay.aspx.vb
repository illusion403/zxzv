﻿Imports System.Drawing
Imports System.Drawing.Drawing2D
Partial Public Class ifrDisplay
    Inherits System.Web.UI.Page
    'Private imgOriginal As Image

    Private chkFile As String
    Private nameFile As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim sContent As String = String.Empty
        chkFile = Request.QueryString("Ftype")
        nameFile = Request.QueryString("Fname")
        If chkFile IsNot Nothing And nameFile IsNot Nothing Then
            If chkFile = "pdf" Then
                sContent = "application/pdf"
            ElseIf chkFile = "jpeg" Or chkFile = "jpg" Then
                sContent = "image/jpeg"
            ElseIf chkFile = "gif" Then
                sContent = "image/gif"
            ElseIf chkFile = "bmp" Then
                sContent = "image/bmp"
            ElseIf chkFile = "zip" Then
                sContent = "text/HTML"
            ElseIf chkFile = "doc" Then
                sContent = "application/msword"
            Else
                ' error file
                sContent = "text/HTML"
            End If

            If Request.QueryString("fprnt") = "0" And (chkFile = "jpeg" Or chkFile = "jpg" Or chkFile = "gif" Or chkFile = "png") Then
                tabImg.Src = nameFile
                tabImg.Attributes.Add("GALLERYIMG", "no")
                'Response.Write("<img src='" & nameFile & "'>")
                hdnPnt.Value = Request.QueryString("prnt")
                'imgOriginal = tabImg
            Else
                Try
                    Response.ClearContent()
                    Response.ClearHeaders()
                    Response.ContentType = sContent
                    Response.Buffer = True
                    If chkFile <> "xls" Then
                        Response.WriteFile(nameFile)
                    End If
                Catch ex As Exception
                    Response.Write(ex.Message)
                Finally
                    Response.Flush()
                    Response.Close()
                End Try
            End If



        End If
    End Sub
    'Public Function PictureBoxZoom(ByVal img As Image, ByVal size As Size) As Image
    '    Dim bm As Bitmap = New Bitmap(img, Convert.ToInt32(img.Width * size.Width), Convert.ToInt32(img.Height * size.Height))
    '    Dim grap As Graphics = Graphics.FromImage(bm)
    '    grap.InterpolationMode = InterpolationMode.HighQualityBicubic
    '    Return bm
    'End Function

    'Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
    '    tabImg = PictureBoxZoom(imgOriginal, New Size(zoomSlider.Value, zoomSlider.Value))
    'End Sub
End Class

'If chkFile = "pdf" Then
'                    Response.ContentType = "application/pdf"
''ElseIf chkFile = "asp" Then
''    Response.ContentType = "text/asp"
''ElseIf chkFile = "htm" Or chkFile = "html" Then
''    Response.ContentType = "text/html"
''ElseIf chkFile = "rtf" Then
''    Response.ContentType = "application/rtf"
''ElseIf chkFile = "mpeg" Or chkFile = "mpg" Then
''    Response.ContentType = "video/mpeg"
''ElseIf chkFile = "mp3" Then
''    Response.ContentType = "audio/mpeg3"
''ElseIf chkFile = "wav" Then
''    Response.ContentType = "audio/wav"
'                ElseIf chkFile = "jpeg" Or chkFile = "jpg" Then
'                    Response.ContentType = "image/jpeg"
'                ElseIf chkFile = "gif" Then
'                    Response.ContentType = "image/gif"
'' ElseIf chkFile = "xls" Then
''Response.ContentType = "file"
'' Response.ContentType = "application/vnd.ms-excel"
'                ElseIf chkFile = "zip" Then
'                    Response.ContentType = "text/HTML"
''Response.ContentType = "application/zip"
'                ElseIf chkFile = "doc" Then
'                    Response.ContentType = "application/msword"
''ElseIf chkFile = "avi" Then
''    Response.ContentType = "video/avi"
''ElseIf chkFile = "asf" Then
''    Response.ContentType = "video/x-ms-asf"
'                Else
'' error file
'                    Response.ContentType = "text/html"
'                End If