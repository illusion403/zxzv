﻿Imports System.IO
Imports System.Xml.Serialization
Imports System.Xml

Partial Public Class ifrImg
    Inherits System.Web.UI.Page
    Private lstFile As List(Of DS_DisFile)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'Dim xF As FileStream = Nothing
            'Dim xR As XmlReader = Nothing
            Try
                'xF = New FileStream(Server.MapPath(ConfigurationSettings.AppSettings.Get("TEMP_PATH")) + ConfigurationSettings.AppSettings.Get("TEMP_FILE"), FileMode.Open)
                'xR = New XmlTextReader(xF)
                'Dim ser As XmlSerializer = New XmlSerializer(GetType(List(Of DS_DisFile)))
                If Session("ObjDis") IsNot Nothing Then
                    lstFile = CType(Session("ObjDis"), List(Of DS_DisFile)) 'CType(ser.Deserialize(xR), List(Of DS_DisFile))
                    Dim daf As DA_DisFile = New DA_DisFile()
                    daf.ServerPath = Server.MapPath("")
                    daf.setDisImage(lstFile)
                    divDis.InnerHtml = daf.setDisStr(lstFile)
                Else
                    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('No Session');", True)
                End If
            Catch ex As Exception
                ' ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('" + ex.Message + "');", True)
                'If xR IsNot Nothing Then
                '    xR.Close()
                'End If
                'If xF IsNot Nothing Then
                '    xF.Close()
                'End If
            End Try
        End If
    End Sub
End Class