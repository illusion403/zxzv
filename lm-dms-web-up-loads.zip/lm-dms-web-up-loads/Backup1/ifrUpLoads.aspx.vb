﻿Imports System.Xml.Serialization
Imports System.Xml
Imports System.IO

Partial Public Class ifrUpLoads
    Inherits System.Web.UI.Page
    Public pathName As String = System.Configuration.ConfigurationSettings.AppSettings("TEMP_PATH")
    Private MAX_FILE_SIZE As String = System.Configuration.ConfigurationManager.AppSettings("MAX_FILE_SIZE")


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not (IsPostBack) Then
            '       File1.Attributes("accept") = DA_File.chkFileInputClass
            ' File1.Attributes.Add(, )
           
        End If

    End Sub

    Protected Function setMessage(ByVal arr As List(Of DS_File)) As String
        Dim stMsg As String = String.Empty
        For i As Integer = 0 To arr.Count - 1
            If arr(i).FileError = False Then
                stMsg += arr(i).FileMsg + Char.Parse("|")
            End If
        Next i
        Return stMsg
    End Function

    Private Sub ifUpLoads_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        'Message.Visible = Not String.IsNullOrEmpty(Message.InnerHtml)
    End Sub

    Protected Sub bntF_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntF.Click
        ' If Session("ObjSave") IsNot Nothing Then
        If Session("ObjSave") Is Nothing Then
            Session("ObjSave") = New List(Of DS_File)
            DA_File.valFileSize = 0
        End If
        DA_File.arrFile = CType(Session("ObjSave"), List(Of DS_File))
        ' End If

        Try
            DA_File.TempDir = Server.MapPath(pathName)
            Dim tmp_st() As String = Request.Files.Item(0).FileName.Split(".")
            Dim tmp_FileType As String = tmp_st(tmp_st.Length - 1).ToLower()

            DA_File.tmp_fileName = Context.Request.ServerVariables("REMOTE_ADDR").ToString.Replace(".", "") & "_" & Now().ToString("yyyyMMddHHmmss") & "." & tmp_FileType
            If DA_File.chkFileSize(Request.Files) = False Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('ขนาดไฟล์รวมต้องไม่เกิน " + Trim(Str(Val(MAX_FILE_SIZE) / 1024)) + " KB');", True)
            Else
                If DA_File.addFile(Request.Files, hdnDes.Value) = False Then
                    Throw New Exception()
                End If
            End If
            DisplayFile()
            Session("ObjSave") = DA_File.FileList
        Catch ex As Exception
            Session("ObjSave") = New List(Of DS_File)
            DA_File.valFileSize = 0
            delData()
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('กรุณาเลือก File ให้ถูกต้อง');", True)
        End Try
    End Sub
    Protected Sub DisplayFile()
        Dim sTable As String = String.Empty
        msg.InnerHtml = String.Empty
        If DA_File.FileList.Count > 0 Then
            Dim i As Integer = 0
            For Each ds As DS_File In DA_File.FileList
                Dim ss As String = ds.toType().Split(".")(1)
                If DA_File.NoneFileImg.ContainsKey(ss) Then
                    sTable = "<table cellpadding ='0' cellspacing ='0' border ='1'  class='upLoadImg' ><tr id='dis'><td  class='upImg1'>" + ds.DesFile + "</td><td class='upImg2'><img  src='" + DA_File.NoneFileImg.Item(ss) + "'  class='disp' /></td><td class='upImg4'><a href='#' onclick='File1_Del(" + i.ToString() + ")' >X</a></td></tr></table>"
                Else
                    sTable = "<table cellpadding ='0' cellspacing ='0' border ='1'  class='upLoadImg' ><tr id='dis'><td  class='upImg1'>" + ds.DesFile + "</td><td class='upImg2'><img  src='" + pathName + "/" + ds.FileName + "'  class='disp' /></td><td class='upImg4'><a href='#' onclick='File1_Del(" + i.ToString() + ")' >X</a></td></tr></table>"
                End If

                msg.InnerHtml += sTable
                i += 1
            Next
        End If
    End Sub
    Protected Sub bntD_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntD.Click
        Try
            If Session("ObjSave") IsNot Nothing Then
                DA_File.arrFile = CType(Session("ObjSave"), List(Of DS_File))
            End If
            Dim fs As New System.IO.FileStream(String.Format("{0}\{1}", Server.MapPath(pathName), DA_File.arrFile(Integer.Parse(hdnIndex.Value)).FileName), System.IO.FileMode.Open, System.IO.FileAccess.Read)
            Dim t_valFileSize As Integer = DA_File.chkFileSizeVal
            DA_File.valFileSize = t_valFileSize - fs.Length
            fs.Close()
            fs.Dispose()
            File.Delete(String.Format("{0}\{1}", Server.MapPath(pathName), DA_File.arrFile(Integer.Parse(hdnIndex.Value)).FileName))
            DA_File.arrFile.RemoveAt(Integer.Parse(hdnIndex.Value))
            DisplayFile()
            Session("ObjSave") = DA_File.FileList
        Catch ex As Exception
            Session("ObjSave") = New List(Of DS_File)
            delData()
            DisplayFile()
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('ลบ File Error');", True)
        End Try
    End Sub
    Private Sub delData()
        Try

            Dim stp As String = Server.MapPath(pathName)
            If DA_File.FileList.Count > 0 Then
                For Each ds As DS_File In DA_File.FileList
                    FileIO.FileSystem.DeleteFile(String.Format("{0}\{1}", stp, ds.FileName))
                Next
            End If
            'For Each st As String In FileIO.FileSystem.GetFiles(Server.MapPath(pathName))
            '    If FileIO.FileSystem.GetFileInfo(st).CreationTime.ToString("yyyyMMdd") < Now().ToString("yyyyMMdd") Then
            '        FileIO.FileSystem.DeleteFile(st)
            '    End If
            'Next
        Catch ex As Exception

        End Try
    End Sub

End Class

