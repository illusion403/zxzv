﻿Public Partial Class index
    Inherits System.Web.UI.Page
    Public st_error As String = String.Empty
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.QueryString("err") IsNot Nothing Then
            st_error = "error"
        End If
    End Sub

End Class