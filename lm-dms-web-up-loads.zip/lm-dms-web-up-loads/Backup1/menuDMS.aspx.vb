﻿Public Partial Class menuDMS
    Inherits System.Web.UI.Page
    Public oSys_id As String
    Public region As String
    Public program_name As String
    Public dt As DataTable
    Public aa As String
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")
    Private URL_LINK As String = System.Configuration.ConfigurationSettings.AppSettings("URL_LINK")
    Private daMenu As DA_Menu = Nothing
    Private stlick As String = "<li><a href='{0}?sys_id={1}&AA={2}&region={3}&program_nm={4}' target='ifr' >{5}</a></li>"
    Private stlick_recovery As String = "<li><a href='{0}?AA={1}' target='ifr' >{2}</a></li>"
    Private stlickErr As String = "<div style='background-color:Red '>No Data</div>"
    Private err_page As String = ConfigurationSettings.AppSettings.Get("error_page")

    'Private stTable As String = "<table  cellpadding= '0' cellspacing ='0' border ='0' width='100%'>{0}</table>"
    'Private stlick As String = "<div id='td_menu'>{5}</div>"
    'Private stlickErr As String = "<div id='td_menu'>No Data</div>"


    Private menuLink As String
    Private tbManu As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            loadpage()
        End If
    End Sub
    Private Sub loadpage()
        Page.Title = "LMG Insurance Co., Ltd."
        aa = UCase(Request.QueryString("AA"))
        If aa Is Nothing Then
            Dim auth_user() As String = Request.ServerVariables.Item("AUTH_USER").Split("\")
            aa = (auth_user(auth_user.Length - 1)).ToUpper
        End If

        If Request.QueryString("region") IsNot Nothing Then
            region = Request.QueryString("region")
        Else
            region = System.Configuration.ConfigurationManager.AppSettings("Region")
        End If
        If Request.QueryString("program_nm") IsNot Nothing Then
            program_name = Request.QueryString("program_nm")
        Else
            program_name = System.Configuration.ConfigurationManager.AppSettings("APP_CALLER")
        End If

        daMenu = New DA_Menu(DMS_data)
        dt = daMenu.getUserRole(oSys_id, aa)
        tbManu = String.Empty
        If dt.Rows.Count <> 0 Then
            Dim chk_print As String = "N"
            tbManu &= "<ul id='menu'>"
            For Each row As DataRow In dt.Rows
                'program_name = "DMS"
                oSys_id = row("system_id")
                If oSys_id = "4" Then
                    tbManu &= "<li><a href='#'>Underwite</a>"
                    tbManu &= "<ul>"
                    menuLink = "schUnderwite.aspx"
                    tbManu &= String.Format(stlick, menuLink, oSys_id, aa, region, program_name, row("system_name"))
                    menuLink = "schaLLUnderwite.aspx"
                    tbManu &= String.Format(stlick, menuLink, oSys_id, aa, region, program_name, row("system_name") & " All")
                    tbManu &= "</ul></li>"
                ElseIf oSys_id = "1" Or oSys_id = "2" Or oSys_id = "3" Then
                    menuLink = "schPolicy.aspx"
                    tbManu &= String.Format(stlick, menuLink, oSys_id, aa, region, program_name, row("system_name"))
                ElseIf oSys_id = "5" Then
                    menuLink = "schFinanceAgent.aspx"
                    tbManu &= String.Format(stlick, menuLink, oSys_id, aa, region, program_name, row("system_name"))
                ElseIf oSys_id = "6" Then
                    menuLink = "schFinanceReport.aspx"
                    tbManu &= String.Format(stlick, menuLink, oSys_id, aa, region, program_name, row("system_name"))
                End If
                If row("Print_doc") = "1" Then
                    chk_print = "Y"
                End If
            Next
            If chk_print = "Y" And region = "Bangkok" And URL_LINK = "DMS" Then
                menuLink = "schRecovery.aspx"
                tbManu &= String.Format(stlick_recovery, menuLink, aa, "Recovery")
            End If
            tbManu &= "</ul> "
        Else
            Response.Redirect(err_page)
        End If
        spMenu.InnerHtml = tbManu
    End Sub

End Class