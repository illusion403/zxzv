﻿Imports System.Xml
Imports System.IO


Partial Public Class saveUploader
    Inherits System.Web.UI.Page
    Public galleryPath As String = "tmp/Gallery/"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim descriptions As New XmlDocument()
        descriptions.Load(Server.MapPath(galleryPath & "Descriptions.xml"))

        DataList1.DataSource = descriptions.DocumentElement.ChildNodes
        DataList1.DataBind()
    End Sub
    Public Function EncodeFileName(ByVal value As String) As String
        Return Server.UrlEncode(value).Replace("+", "%20")
    End Function
End Class