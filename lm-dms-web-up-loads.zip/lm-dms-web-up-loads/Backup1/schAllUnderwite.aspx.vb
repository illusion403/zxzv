﻿Public Partial Class schAllUnderwite
    Inherits System.Web.UI.Page
    Private DTW_data As String = System.Configuration.ConfigurationSettings.AppSettings("DTW_data")
    Private SETUP_data As String = System.Configuration.ConfigurationSettings.AppSettings("SETUP_data")
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")
    Private da As DA_Search = New DA_Search(DTW_data)
    Private daMenu As DA_Menu = New DA_Menu(SETUP_data)
    Private aa As String
    Private region As String
    Private program_name As String

    Private sys_id As String
    Private dt As DataTable = Nothing
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            PageLoad()
        End If
    End Sub
    Private Sub PageLoad()
        Try

       
            sys_id = Request.QueryString("sys_id")
            region = Request.QueryString("region")
            program_name = Request.QueryString("program_nm")
            aa = Request.QueryString("AA")

            hdnLoad.Value = Request.RawUrl()

            hdnRegion.Value = region
            hdnPro_nm.Value = program_name
            hdnAA.Value = aa
            hdnSysId.Value = sys_id
            daMenu = New DA_Menu(DMS_data)
            dt = daMenu.getUserRole(sys_id, aa)

            CType(Master, DMSMaster).setSysName = dt.Rows(0)("system_name")

            daMenu = New DA_Menu(SETUP_data)
            dt = daMenu.getProvince()
            If dt.Rows.Count > 0 Then
                ddlProvinces.DataSource = dt
                ddlProvinces.DataTextField = "PROVINCE_NAME"
                ddlProvinces.DataValueField = "KEY_FIELD"
                ddlProvinces.DataBind()
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('ไม่ข้อมูลจังหวัด');", True)
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub
    Protected Sub bntSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntSearch.Click
        dt = New DataTable()
        Dim dsUnder As DS_Underwrite = New DS_Underwrite()

        Try

        
            dsUnder.AA = hdnAA.Value


            dsUnder.Doc_no = txtPolicy.Text

            dsUnder.Fcode = txtFcode.Text
            dsUnder.Ecode = txtEcode.Text

            If ddlProvinces.SelectedValue = "0" Then
                dsUnder.Provinces = ""
            Else
                dsUnder.Provinces = ddlProvinces.SelectedValue
            End If

            dt = da.schDocSvc(dsUnder)

            If dt.Rows.Count <> 0 Then
                GridView1.DataSource = dt
                GridView1.DataBind()
                ' Label5.Text = "พบข้อมูลจำนวน " & dt.Rows.Count.ToString.Trim & " รายการ"
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('ไม่พบข้อมูล');", True)
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridView1.SelectedIndexChanged
        Dim t_doc_no, t_policy, t_LICENSE_NO, t_KEY_FIELD As String
        Dim row As GridViewRow = GridView1.SelectedRow
        t_doc_no = row.Cells(1).Text
        t_policy = row.Cells(1).Text
        t_LICENSE_NO = row.Cells(2).Text
        t_KEY_FIELD = row.Cells(5).Text

        region = hdnRegion.Value
        program_name = hdnPro_nm.Value
        aa = hdnAA.Value
        sys_id = hdnSysId.Value

        Response.Redirect("ClaimsList.aspx?sys_id=" & sys_id & _
                          "&doc_no=" & t_doc_no & "&licenseno=" & t_LICENSE_NO & _
                          "&keyfield=" & t_KEY_FIELD & "&policy=" & t_policy & _
                          "&region=" & region & "&office_code=" & Mid(t_doc_no, 1, 2) & _
                          "&program_nm=" & program_name & _
                          "&AA=" & aa, False)
    End Sub

    Protected Sub bntReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntReset.Click
        Response.Redirect(hdnLoad.Value)
    End Sub
End Class