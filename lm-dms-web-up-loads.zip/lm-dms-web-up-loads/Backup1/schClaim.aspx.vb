﻿Public Partial Class schClaim
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub bntDoc_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntDoc.Click
        Dim dt As DataTable = Nothing
        Dim sys_id As String = String.Empty
        Select Case sys_id
            Case "1", "2"
                '   dt = BuildData()
                If dt.Rows.Count = 0 Then

                    'Dim dataTables As New DataTable
                    'Dim dataRows As DataRow
                    'Dim t_province As String = ""
                    'If list_province.SelectedValue <> "0" Then
                    '    t_province = list_province.SelectedValue
                    'End If
                    'dataTables = createTable()
                    'dataRows = dataTables.NewRow()
                    'dataRows("CALLER") = lb_user_id.Text
                    'dataRows("REFERENCE_NO") = "123"
                    'dataRows("POLICY_NO_PAR") = tb_policy.Text.Trim
                    'dataRows("CLAIM_NO_PAR") = tb_claim.Text.Trim
                    'dataRows("VEHICLE_PREFIX_LICENSE_NO_PAR") = tb_prefix_license.Text.Trim
                    'dataRows("VEHICLE_LICENSE_NO_PAR") = tb_license_no.Text.Trim
                    'dataRows("PROVINCE_LICENSE_NO_PAR") = t_province
                    'dataRows("REFERENCE_NO_PAR") = tb_ref_no.Text.Trim
                    'dataRows("LOSS_DATE_PAR") = tb_loss_date.Text.Trim
                    'dataTables.Rows.Add(dataRows)
                    'Dim ds As New DataSet
                    'Dim res As New DataSet
                    'ds.Tables.Add(dataTables)

                    'res = MySearchAegis.wsSearchPolicyClaimInfo(ds)
                    'If res.Tables("ws_return_data").Rows(0).Item("WS_RETURN_CODE") = "1" Then
                    '    Dim dataResClaim, rows_dt As DataRow
                    '    If res.Tables("ws_return_claim_data").Rows.Count > 0 Then
                    '        dt = New DataTable
                    '        dt.TableName = "t_search"
                    '        dt.Columns.Add("POLICY_NO")
                    '        dt.Columns.Add("LICENSE_NO")
                    '        dt.Columns.Add("KEY_FIELD")
                    '        dt.Columns.Add("PROVINCE_NAME")
                    '        dt.Columns.Add("Claim_no")
                    '        dt.Columns.Add("LICENSE_KEY")

                    '        For Each dataResClaim In res.Tables("ws_return_claim_data").Rows
                    '            Dim dataPolicy = From c In res.Tables("ws_return_policy_data") _
                    '                                  Where c.Item("POLICY_NO") = dataResClaim.Item("POLICY_NO") _
                    '                                  And c.Item("lob") Like "A*"

                    '            If dataPolicy.Count > 0 Then
                    '                For Each t_datapolicy In dataPolicy
                    '                    Dim t_license1() As String = t_datapolicy.Item("policy_unit_description").ToString.Split("License:")
                    '                    Dim tmp_license2 As String = ""
                    '                    Dim l As Integer
                    '                    For l = 0 To t_license1.Length - 1
                    '                        If t_license1(l).StartsWith("icense:") Then
                    '                            Dim t_license2() As String = t_license1(l).ToString.Split("C")
                    '                            tmp_license2 = t_license2(0).ToString.Replace("icense: ", "").Replace(" ", "")
                    '                        End If
                    '                    Next
                    '                    rows_dt = dt.NewRow()
                    '                    rows_dt("POLICY_NO") = t_datapolicy.Item("POLICY_NO")
                    '                    rows_dt("LICENSE_NO") = tmp_license2.Trim
                    '                    rows_dt("KEY_FIELD") = t_datapolicy.Item("PROVINCE_LICENSE_NO_CODE")
                    '                    rows_dt("PROVINCE_NAME") = t_datapolicy.Item("PROVINCE_LICENSE_NO_NAME")
                    '                    rows_dt("Claim_no") = dataResClaim.Item("Claim_no")
                    '                    rows_dt("LICENSE_KEY") = tmp_license2.Trim & t_datapolicy.Item("PROVINCE_LICENSE_NO_CODE")
                    '                    dt.Rows.Add(rows_dt)
                    '                Next
                    '            End If
                    '        Next
                    '    End If
                End If
            Case "3"
                ' dt = BuildDataNonMotor()
                If dt.Rows.Count = 0 Then

                    '    Dim dataTables As New DataTable
                    '    Dim dataRows As DataRow
                    '    Dim t_province As String = ""
                    '    If list_province.SelectedValue <> "0" Then
                    '        t_province = list_province.SelectedValue
                    '    End If
                    '    dataTables = createTable()
                    '    dataRows = dataTables.NewRow()
                    '    dataRows("CALLER") = lb_user_id.Text
                    '    dataRows("REFERENCE_NO") = "123"
                    '    dataRows("POLICY_NO_PAR") = tb_policy.Text.Trim
                    '    dataRows("CLAIM_NO_PAR") = tb_claim.Text.Trim
                    '    dataRows("VEHICLE_PREFIX_LICENSE_NO_PAR") = ""
                    '    dataRows("VEHICLE_LICENSE_NO_PAR") = ""
                    '    dataRows("PROVINCE_LICENSE_NO_PAR") = ""
                    '    dataRows("REFERENCE_NO_PAR") = tb_ref_no.Text.Trim
                    '    dataRows("LOSS_DATE_PAR") = tb_loss_date.Text.Trim
                    '    dataTables.Rows.Add(dataRows)
                    '    Dim ds As New DataSet
                    '    Dim res As New DataSet
                    '    ds.Tables.Add(dataTables)

                    '    res = MySearchAegis.wsSearchPolicyClaimInfo(ds)
                    '    If res.Tables("ws_return_data").Rows(0).Item("WS_RETURN_CODE") = "1" Then
                    '        Dim dataResClaim, rows_dt As DataRow
                    '        If res.Tables("ws_return_claim_data").Rows.Count > 0 Then
                    '            dt = New DataTable
                    '            dt.TableName = "t_search"
                    '            dt.Columns.Add("POLICY_NO")
                    '            dt.Columns.Add("LICENSE_NO")
                    '            dt.Columns.Add("KEY_FIELD")
                    '            dt.Columns.Add("PROVINCE_NAME")
                    '            dt.Columns.Add("Claim_no")
                    '            dt.Columns.Add("LICENSE_KEY")
                    '            For Each dataResClaim In res.Tables("ws_return_claim_data").Rows
                    '                Dim dataPolicy = From c In res.Tables("ws_return_policy_data") _
                    '                                          Where c.Item("POLICY_NO") = dataResClaim.Item("POLICY_NO") _
                    '                                          And Not (c.Item("lob") Like "A*")
                    '                If dataPolicy.Count > 0 Then
                    '                    For Each t_datapolicy In dataPolicy
                    '                        rows_dt = dt.NewRow()
                    '                        rows_dt("POLICY_NO") = t_datapolicy.Item("POLICY_NO")
                    '                        rows_dt("LICENSE_NO") = dataResClaim.Item("CLAIM_REFERENCE_NO")
                    '                        rows_dt("KEY_FIELD") = "99"
                    '                        rows_dt("PROVINCE_NAME") = "Non"
                    '                        rows_dt("Claim_no") = dataResClaim.Item("Claim_no")
                    '                        rows_dt("LICENSE_KEY") = "Non"
                    '                        dt.Rows.Add(rows_dt)
                    '                    Next
                    '                End If
                    '            Next
                    '        End If
                    '        If dt.Rows.Count > 0 Then
                    '            GridView1.DataSource = dt
                    '            GridView1.DataBind()
                    '            Label5.Text = "พบข้อมูลจำนวน " & dt.Rows.Count.ToString.Trim & " รายการ"
                    '        Else
                    '            Label5.Text = "ไม่พบข้อมูล"
                    '        End If
                    '    End If
                End If
        End Select

        If dt.Rows.Count > 0 Then
            GridView1.DataSource = dt
            GridView1.DataBind()
            ' Label5.Text = "พบข้อมูลจำนวน " & dt.Rows.Count.ToString.Trim & " รายการ"
        Else
            'Label5.Text = "ไม่พบข้อมูล"
            ' lb_message.Text = "รูปแบบวันที่ วัน/เดือน/ปี ค.ศ."
        End If
    End Sub

    Protected Sub bntManDoc_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntManDoc.Click

    End Sub
End Class