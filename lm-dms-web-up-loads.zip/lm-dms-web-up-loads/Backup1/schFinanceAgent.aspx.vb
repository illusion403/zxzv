﻿Partial Public Class schFinanceAgent
    Inherits System.Web.UI.Page

    Private SETUP_data As String = System.Configuration.ConfigurationSettings.AppSettings("SETUP_data")
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")

    Private Archive_Url As String = System.Configuration.ConfigurationSettings.AppSettings("Archive_Url")
    Private URL_LINK As String = System.Configuration.ConfigurationSettings.AppSettings("URL_LINK")

    Private da As DA_Search = New DA_Search(SETUP_data)
    Private daMenu As DA_Menu = New DA_Menu(SETUP_data)


    Private aa As String
    Private region As String
    Private program_name As String

    Private sys_id As String
    Private dt As DataTable = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            PageLoad()
        End If

    End Sub
    Private Sub PageLoad()
        sys_id = Request.QueryString("sys_id")
        region = Request.QueryString("region")
        program_name = Request.QueryString("program_nm")
        aa = UCase(Request.QueryString("AA"))
        hdnLoad.Value = Request.RawUrl()
        hdnRegion.Value = region
        hdnPro_nm.Value = program_name
        hdnAA.Value = aa
        hdnSysId.Value = sys_id

        daMenu = New DA_Menu(DMS_data)
        dt = daMenu.getUserRole(sys_id, aa)

        CType(Master, DMSMaster).setSysName = dt.Rows(0)("system_name")
    End Sub
    Protected Sub bntSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntSearch.Click
        dt = da.schFinance(txtManCode.Text, txtManName.Text, txtIdCard.Text)
        If dt.Rows.Count <> 0 Then
            GridView1.DataSource = dt
            GridView1.DataBind()
        Else
            hdnMsg.Value = "ไม่มีข้อมูล"
        End If
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridView1.SelectedIndexChanged
        Dim n As Integer
        Dim t_doc_no, t_policy, t_LICENSE_NO, t_KEY_FIELD As String

        t_doc_no = GridView1.SelectedRow.Cells(1).Text
        t_policy = "9999999999"
        t_LICENSE_NO = 99999
        t_KEY_FIELD = "999"

        region = hdnRegion.Value
        program_name = hdnPro_nm.Value
        aa = hdnAA.Value
        sys_id = hdnSysId.Value

        da = New DA_Search(DMS_data)
        Try
            dt = da.getArchive(t_doc_no, URL_LINK)
            If dt.Rows.Count <> 0 Then
                n = dt.Rows.Count
            Else
                n = 0
            End If
        Catch ex As Exception
            n = 0
        End Try

        If URL_LINK = "DMS" Then
            If n = 0 Then
                Response.Redirect("ClaimsList.aspx?sys_id=" & sys_id & _
                                  "&doc_no=" & t_doc_no & "&licenseno=" & t_LICENSE_NO & _
                                  "&keyfield=" & t_KEY_FIELD & "&policy=" & t_policy & _
                                  "&region=" & region & "&office_code=" & Mid(t_doc_no, 1, 2) & _
                                  "&program_nm=" & program_name & _
                                  "&AA=" & aa, False)
            Else
                hdnMsg.Value = "ข้อมูลนี้ย้ายไปที่ " & Archive_Url & " เมื่อวันที่ " & dt.Rows(0).Item("Archive_Date").ToString
            End If
        Else
            If n = 0 Then
                hdnMsg.Value = "ข้อมูลนี้ยังไม่ถูก Archive กรุณาไปเปิดที่ " & Archive_Url
            Else
                Response.Redirect("ClaimsList.aspx?sys_id=" & sys_id & _
                                    "&doc_no=" & t_doc_no & "&licenseno=" & t_LICENSE_NO & _
                                    "&keyfield=" & t_KEY_FIELD & "&policy=" & t_policy & _
                                    "&region=" & region & "&office_code=" & Mid(t_doc_no, 1, 2) & _
                                    "&program_nm=" & program_name & _
                                    "&AA=" & aa, False)
            End If
        End If
    End Sub

    Protected Sub bntReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntReset.Click
        Response.Redirect(hdnLoad.Value)
    End Sub
End Class