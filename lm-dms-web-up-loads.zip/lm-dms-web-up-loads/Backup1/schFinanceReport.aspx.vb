﻿Partial Public Class schFinanceReport
    Inherits System.Web.UI.Page

    Private SETUP_data As String = System.Configuration.ConfigurationSettings.AppSettings("SETUP_data")
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")

    Private Archive_Url As String = System.Configuration.ConfigurationSettings.AppSettings("Archive_Url")
    Private URL_LINK As String = System.Configuration.ConfigurationSettings.AppSettings("URL_LINK")

    Private da As DA_Search = New DA_Search(SETUP_data)
    Private daMenu As DA_Menu = New DA_Menu(SETUP_data)
    Private daData As DA_Paper = New DA_Paper()

    Private aa As String
    Private region As String
    Private program_name As String

    Private con_id As String
    Private off_code As String
    Private crtDate As String
    Private sState As String
    Private slvl As String

    Private sys_id As String
    Private dt As DataTable = Nothing
    Private dt_dms As DataTable = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            PageLoad()
        End If

    End Sub
    Private Sub PageLoad()
        sys_id = Request.QueryString("sys_id")
        region = Request.QueryString("region")
        program_name = Request.QueryString("program_nm")
        aa = UCase(Request.QueryString("AA"))
        hdnLoad.Value = Request.RawUrl()
        hdnRegion.Value = region
        hdnPro_nm.Value = program_name
        hdnAA.Value = aa
        hdnSysId.Value = sys_id

        daMenu = New DA_Menu(DMS_data)
        dt = daMenu.getUserRole(sys_id, aa)
        CType(Master, DMSMaster).setSysName = dt.Rows(0)("system_name")

        dt = daData.getUser(aa)
        hdnAA.Value = aa

        off_code = ""
        If dt.Rows.Count <> 0 Then
            For Each dr In dt.Rows
                If off_code = "" Then
                    off_code = "'" & CInt(dr("office_code")).ToString("00") & "'"
                Else
                    off_code += ", '" & CInt(dr("office_code")).ToString("00") & "'"
                End If
            Next
            hdnlvl.Value = dt.Rows(0)("lvl").ToString()
            hdnOff_code.Value = off_code
        End If
        If off_code = "" Then
            dt_dms = daData.getUserDMS(aa)
            If dt_dms.Rows.Count <> 0 Then
                hdnlvl.Value = "B"
                hdnOff_code.Value = "ALL"
            Else
            End If
        End If

        If hdnlvl.Value = "U" Then
            ddlState.Items.Add(New ListItem("ทั้งหมด", ""))
            ddlState.Items.Add(New ListItem("รอส่งงาน", "U"))
            ddlState.Items.Add(New ListItem("รออนุมัติ", "S"))
            ddlState.Items.Add(New ListItem("อนุมัติ", "A"))
        ElseIf hdnlvl.Value = "M" Then
            ddlState.Items.Add(New ListItem("ทั้งหมด", "S,A"))
            ddlState.Items.Add(New ListItem("รออนุมัติ", "S"))
            ddlState.Items.Add(New ListItem("อนุมัติ", "A"))
        Else
            ddlState.Items.Add(New ListItem("อนุมัติ", "A"))
        End If
        ddlState.SelectedIndex = 0


    End Sub

    Protected Sub bntSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntSearch.Click
        off_code = hdnOff_code.Value
        con_id = txtCon_Id.Text
        crtDate = txtDate.Text
        sState = ddlState.SelectedValue.Replace(",", "','")
        GridView1.DataSource = Nothing
        GridView1.DataSource = daData.schPaper(off_code, con_id, sState, crtDate)
        GridView1.DataBind()
        GridView1.SelectedIndex = -1
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridView1.SelectedIndexChanged
        'off_code = hdnOff_code.Value
        off_code = Mid(GridView1.SelectedRow.Cells(1).Text, 1, 2)
        con_id = GridView1.SelectedRow.Cells(1).Text
        region = hdnRegion.Value
        program_name = hdnPro_nm.Value
        aa = hdnAA.Value
        sys_id = hdnSysId.Value

        Response.Redirect("ClaimsList.aspx?sys_id=" & sys_id & _
                                   "&doc_no=" & con_id & _
                                   "&region=" & region & "&office_code=" & off_code & _
                                   "&program_nm=" & program_name & _
                                   "&AA=" & aa, False)
    End Sub

    Protected Sub bntReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntReset.Click
        Response.Redirect(hdnLoad.Value)
    End Sub
End Class