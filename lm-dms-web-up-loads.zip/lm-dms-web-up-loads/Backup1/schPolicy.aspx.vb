﻿Imports System.Data
Imports System.Data.SqlClient

Partial Public Class schPolicy
    Inherits System.Web.UI.Page

    Private DTW_data As String = System.Configuration.ConfigurationSettings.AppSettings("DTW_data")
    Private SETUP_data As String = System.Configuration.ConfigurationSettings.AppSettings("SETUP_data")
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")
    Private da As DA_Search = New DA_Search(DTW_data)
    Private daMenu As DA_Menu = New DA_Menu(SETUP_data)
    Private dsPolicy As DS_SchPolicy = Nothing
    Private aa As String
    Private region As String
    Private program_name As String
    'Private chkStatus As String
    Private sys_id As String
    Private dt As DataTable = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            PageLoad()
        End If
    End Sub
    Private Sub PageLoad()

        sys_id = Request.QueryString("sys_id")
        region = Request.QueryString("region")
        program_name = Request.QueryString("program_nm")
        aa = UCase(Request.QueryString("AA"))

        hdnLoad.Value = Request.RawUrl()

        hdnRegion.Value = region
        hdnPro_nm.Value = program_name
        hdnAA.Value = aa
        hdnSysId.Value = sys_id
        'aa = CType(Master, DMSMaster).setUser
        'sys_id = CType(Master, DMSMaster).SysId
        'aa = "GR00004"
        'sys_id = "1"
        ' chkStatus = Request.QueryString("program_nm")
        daMenu = New DA_Menu(DMS_data)
        dt = daMenu.getUserRole(sys_id, aa)

        CType(Master, DMSMaster).setSysName = dt.Rows(0)("system_name")

        If sys_id = "3" Then
            txtFcode.Visible = False
            txtEcode.Visible = False
            ddlProvinces.Visible = False
            lbCarcode.Text = "Reference No"
            lbCarcode.Font.Size = System.Web.UI.WebControls.FontUnit.Smaller
            GridView1.Columns(2).HeaderText = "Reference No"
            GridView1.Columns(3).HeaderText = "Unit"
        Else
            tb_ref_no.Visible = False
        End If
        daMenu = New DA_Menu(SETUP_data)
        dt = daMenu.getProvince()
        ddlProvinces.DataSource = dt
        ddlProvinces.DataTextField = "PROVINCE_NAME"
        ddlProvinces.DataValueField = "KEY_FIELD"
        ddlProvinces.DataBind()
    End Sub
    Protected Sub bntSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntSearch.Click
        dt = New DataTable()
        dsPolicy = New DS_SchPolicy()
        Try
            sys_id = hdnSysId.Value
            aa = hdnAA.Value

            'sys_id = "1"
            dsPolicy.CALLER = aa
            dsPolicy.REFERENCE_NO = "123"

            dsPolicy.POLICY_NO_PAR = txtPolicy.Text

            dsPolicy.CLAIM_NO_PAR = txtClaim.Text
            dsPolicy.LOSS_DATE_PAR = txtDate.Text

            dsPolicy.VEHICLE_PREFIX_LICENSE_NO_PAR = txtFcode.Text
            dsPolicy.VEHICLE_LICENSE_NO_PAR = txtEcode.Text

            If ddlProvinces.SelectedValue = "0" Then
                dsPolicy.PROVINCE_LICENSE_NO_PAR = ""
            Else
                dsPolicy.PROVINCE_LICENSE_NO_PAR = ddlProvinces.SelectedValue
            End If
            dsPolicy.REFERENCE_NO_PAR = tb_ref_no.Text.Trim
            Select Case sys_id
                Case "1", "2"

                    dt = da.searchClaim(dsPolicy)
                    If dt.Rows.Count = 0 Then
                        dt = da.schPolicyClaimInfo(dsPolicy.SchPolicyTable)
                    End If
                Case "3"
                    dt = da.getCoslMaster(dsPolicy)
                    If dt.Rows.Count = 0 Then
                        dt = da.schPolicyClaimInfo3(dsPolicy.SchPolicyTable)
                    End If
            End Select


            If dt.Rows.Count <> 0 Then
                GridView1.DataSource = dt
                GridView1.DataBind()
                GridView1.Visible = True
                ' Label5.Text = "พบข้อมูลจำนวน " & dt.Rows.Count.ToString.Trim & " รายการ"
            Else
                GridView1.Visible = False
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('ไม่พบข้อมูล');", True)
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridView1.SelectedIndexChanged
        Dim n As Integer
        Dim t_doc_no, t_policy, t_LICENSE_NO, t_KEY_FIELD, t_Archive, mysql As String
        Dim Archive_Url As String = System.Configuration.ConfigurationManager.AppSettings("Archive_Url")
        Dim wup_data As String = System.Configuration.ConfigurationManager.AppSettings("WUP_data")
        Dim URL_LINK As String = System.Configuration.ConfigurationManager.AppSettings("URL_LINK")
        Dim dr As DataRow
        Dim myda As SqlDataAdapter
        Dim myds As DataSet
        Dim myconnWUP As SqlConnection
        Dim myconnDMS As SqlConnection
        Dim row As GridViewRow = GridView1.SelectedRow
        Dim msg As String = ""
        t_doc_no = row.Cells(4).Text
        t_policy = row.Cells(1).Text
        t_LICENSE_NO = row.Cells(2).Text
        t_KEY_FIELD = row.Cells(5).Text
        'Dim x As New Encryption.Encryption64
        'Dim t_user As String = x.SimpleEncrypt(lb_user_id.Text)
        'Dim d As String = Now.Date.ToString("dd/MM/yyyy")
        'Dim t As String = TimeOfDay.ToString("HH:MM:ss")
        'Dim t_dd() = x.EncrypTIME(d, t).Split("|")
        region = hdnRegion.Value
        program_name = hdnPro_nm.Value
        aa = hdnAA.Value
        sys_id = hdnSysId.Value

        If URL_LINK = "DMS" Then
            t_Archive = "AND (ISNULL(Archive_Flag, 'N') IN ('Y', 'H')) "
        Else
            t_Archive = ""
        End If
        mysql = "SELECT ISNULL(Archive_Flag, 'N') AS Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date " & _
        "FROM dbo.DMS_ClaimMonitor " & _
        "WHERE (CLAIM_NO = '" & t_doc_no & "') " & t_Archive & _
        "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"
        Try
            myconnWUP = New SqlConnection(wup_data)
            myda = New SqlDataAdapter(mysql, myconnWUP)
            myds = New DataSet
            myconnWUP.Open()
            myda.Fill(myds, "t_Archive")
            myconnWUP.Close()
        Catch ex As Exception
            If myconnWUP.State = ConnectionState.Open Then
                myconnWUP.Close()
            End If
        End Try

        mysql = "SELECT ISNULL(Archive_Flag, 'N') AS Archive_Flag, convert(varchar(10), Archive_Date, 103) As Archive_Date " & _
        "FROM dbo.DMS_maindocument " & _
        "WHERE (doc_no = '" & t_doc_no & "') " & t_Archive & _
        "GROUP BY Archive_Flag, convert(varchar(10), Archive_Date, 103)"
        Try
            myconnDMS = New SqlConnection(DMS_data)
            myda = New SqlDataAdapter(mysql, myconnDMS)
            myconnDMS.Open()
            myda.Fill(myds, "t_Archive")
            myconnDMS.Close()
        Catch ex As Exception
            If myconnDMS.State = ConnectionState.Open Then
                myconnDMS.Close()
            End If
        End Try
        Try
            n = myds.Tables("t_Archive").Rows.Count
        Catch ex As Exception
            n = 0
        End Try
        If URL_LINK = "DMS" Then
            If n = 0 Then
                Response.Redirect("ClaimsList.aspx?sys_id=" & sys_id & _
                                  "&doc_no=" & t_doc_no & "&licenseno=" & t_LICENSE_NO & _
                                  "&keyfield=" & t_KEY_FIELD & "&policy=" & t_policy & _
                                  "&region=" & region & "&office_code=" & Mid(t_doc_no, 1, 2) & _
                                  "&program_nm=" & program_name & _
                                  "&AA=" & aa, False)
            Else
                Dim t_hk As String = "N"
                Dim t_hk_date As String = ""
                For Each dr In myds.Tables("t_Archive").Rows
                    If dr.Item("Archive_Flag").ToString = "H" Then
                        t_hk = "Y"
                        t_hk_date = dr.Item("Archive_Date").ToString
                        Exit For
                    End If
                Next
                If t_hk = "Y" Then
                    msg = "ข้อมูลนี้ได้ถูกเก็บขึ้นเทปแล้ว" & " เมื่อวันที่ " & t_hk_date & " ไม่สามารถ upload รูปเพิ่มเติม"
                Else
                    'msg = "ข้อมูลนี้ย้ายไปที่ " & Archive_Url & " เมื่อวันที่ " & myds.Tables("t_Archive").Rows(0).Item("Archive_Date").ToString
                    Response.Redirect(Archive_Url & "ClaimsList.aspx?sys_id=" & sys_id & _
                  "&doc_no=" & t_doc_no & "&licenseno=" & t_LICENSE_NO & _
                  "&keyfield=" & t_KEY_FIELD & "&policy=" & t_policy & _
                  "&region=" & region & "&office_code=" & Mid(t_doc_no, 1, 2) & _
                  "&program_nm=" & program_name & _
                  "&AA=" & aa, False)

                End If
            End If
        Else
            If n = 0 Then
                msg = "ข้อมูลนี้ยังไม่ถูก Archive กรุณาไปเปิดที่ " & Archive_Url
            Else
                Dim t_hk As String = "N"
                Dim t_hk_date As String = ""
                For Each dr In myds.Tables("t_Archive").Rows
                    If dr.Item("Archive_Flag").ToString = "H" Then
                        t_hk = "Y"
                        t_hk_date = dr.Item("Archive_Date").ToString
                        Exit For
                    End If
                Next
                If t_hk = "Y" Then
                    msg = "ข้อมูลนี้ได้ถูกเก็บขึ้นเทปแล้ว" & " เมื่อวันที่ " & t_hk_date & " ไม่สามารถ upload รูปเพิ่มเติม"
                Else
                    Response.Redirect("ClaimsList.aspx?sys_id=" & sys_id & _
                                      "&doc_no=" & t_doc_no & "&licenseno=" & t_LICENSE_NO & _
                                      "&keyfield=" & t_KEY_FIELD & "&policy=" & t_policy & _
                                      "&region=" & region & "&office_code=" & Mid(t_doc_no, 1, 2) & _
                                      "&program_nm=" & program_name & _
                                      "&AA=" & aa, False)
                End If
            End If
        End If

        If msg.Length > 0 Then
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('" & msg & "');", True)
        End If



        'Response.Redirect("ClaimsList.aspx?sys_id=" & sys_id & _
        '                  "&doc_no=" & t_doc_no & "&licenseno=" & t_LICENSE_NO & _
        '                  "&keyfield=" & t_KEY_FIELD & "&policy=" & t_policy & _
        '                  "&region=" & region & "&office_code=" & Mid(t_doc_no, 1, 2) & _
        '                  "&program_nm=" & program_name & _
        '                  "&AA=" & aa, False)
    End Sub

    Protected Sub bntReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntReset.Click
        Response.Redirect(hdnLoad.Value)
    End Sub
End Class