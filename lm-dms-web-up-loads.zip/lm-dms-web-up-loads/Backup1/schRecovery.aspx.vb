﻿Public Partial Class schRecovery
    Inherits System.Web.UI.Page
    Private stSearch As String = "schRecovery.aspx"
    Private stAdd As String = "addRecovery2.aspx"
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")
    Private dt As DataTable = Nothing
    Private daSearch As DA_Search = New DA_Search(DMS_data)
    Private count As Integer = 0
    Private complete As Integer = 0
    Private index_sch As Integer = 0
    Private q_claim_no, q_create_date, q_page, q_id As String
    Private aa As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadPage()
        End If

    End Sub
    Protected Sub LoadPage()
        aa = UCase(Request.QueryString("AA"))
        hdnAA.Value = aa
        If (Request.QueryString("q_page") <> Nothing) Then
            q_page = Request.QueryString("q_page").ToString()
            dt = daSearch.searchRecovery(txtClaim.Text.Trim, txtCreateDate.Text.Trim)

            Display()
            dataGrid.CurrentPageIndex = Integer.Parse(q_page)

        End If
    End Sub
    Protected Sub Display()
        dataGrid.DataSource = dt
        dataGrid.DataBind()
        panelSearchResult.Visible = True
        If (dt.Rows.Count = 0) Then
            buttonDelete.Visible = False
            labelDataGridRecord.Text = "ไม่พบข้อมูล"
            labelDataGridRecord.ToolTip = "Data Not Found"
        Else
            buttonDelete.Visible = True
            labelDataGridRecord.Text = "ทั้งหมด " + dt.Rows.Count.ToString("N0") + " รายการ"
            labelDataGridRecord.ToolTip = "Total " + dt.Rows.Count.ToString("N0") + " Record"
            If (dt.Rows.Count > 1) Then
                labelDataGridRecord.ToolTip += "s"
            End If
        End If
    End Sub
    Protected Sub SearchData()
        dt = daSearch.searchRecovery(txtClaim.Text.Trim, txtCreateDate.Text.Trim)
        Display()

    End Sub

    Protected Sub buttonSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles buttonSearch.Click
        hdnMsg.Value = ""
        SearchData()
    End Sub

    Protected Sub buttonReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles buttonReset.Click
        Response.Redirect(stSearch & "?AA=" & hdnAA.Value, False)
    End Sub

    Protected Sub buttonAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles buttonAdd.Click
        If txtClaim.Text.Trim.Length <> 0 Then
            Response.Redirect(stAdd & "?AA=" & hdnAA.Value & "&claim_no=" & txtClaim.Text.Trim, False)
        Else
            Response.Redirect(stAdd & "?AA=" & hdnAA.Value, False)
        End If
    End Sub

    Private Sub dataGrid_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dataGrid.PageIndexChanged
        dataGrid.CurrentPageIndex = e.NewPageIndex
        SearchData()

    End Sub
    Private Function delData() As Boolean
        Dim i As Integer
        Dim arr() As String = hdnChkData.Value.Split(",".ToCharArray())
        Dim checkFlag As Boolean = False
        count = 0
        complete = 0
        For i = 0 To arr.Length - 1
            checkFlag = True
            count += 1
            q_id = dataGrid.Items(Convert.ToInt16(arr(i))).Cells(1).Text
            If (daSearch.delRecovery(q_id, hdnAA.Value)) Then
                complete += 1
            End If
        Next
        Return checkFlag
    End Function

    Protected Sub buttonDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles buttonDelete.Click
        Dim checkFlag As Boolean = delData()
        If Not (checkFlag) Then
            hdnMsg.Value = "กรุณาเลือกข้อมูลที่ต้องการลบ"
        Else
            hdnMsg.Value = "เลือกลบข้อมูล " + count.ToString() + " ข้อมูล ลบได้ " + complete.ToString() + " ข้อมูล"
            SearchData()
        End If
    End Sub
End Class