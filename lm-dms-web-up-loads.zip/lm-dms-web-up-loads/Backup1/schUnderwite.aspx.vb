﻿Public Partial Class schUnderwite
    Inherits System.Web.UI.Page
    Private dsUnder As DS_Underwrite = Nothing
    Private DMS_data As String = System.Configuration.ConfigurationSettings.AppSettings("DB")
    Private DWPROD_data As String = System.Configuration.ConfigurationSettings.AppSettings("DWPROD_data")
    Private SETUP_data As String = System.Configuration.ConfigurationSettings.AppSettings("SETUP_data")
    Private daAdd As DA_Search = New DA_Search(DMS_data)
    Private daMenu As DA_Menu = Nothing
    Private dt As DataTable = Nothing
    Private sys_id As String
    Private act_type As String
    Public aa As String
    Private t_month As String
    Private t_year As String

    Private region As String
    Private program_name As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            PageLoad()
        End If
    End Sub
    Private Sub PageLoad()
        Try
            hdnLoad.Value = Request.RawUrl()
       
            sys_id = Request.QueryString("sys_id")
            act_type = Request.QueryString("act_type")
            aa = UCase(Request.QueryString("AA"))
            region = Request.QueryString("region")
            program_name = Request.QueryString("program_nm")
            CType(Master, DMSMaster).setSysName = program_name
            'sys_id = "1"
            'aa = "GR00004"

            'aa = CType(Master, DMSMaster).setUser
            hdnRegion.Value = region
            hdnPro_nm.Value = program_name
            hdnAA.Value = aa
            hdnSysId.Value = sys_id

            CType(Master, DMSMaster).setHLink = "<a href='addUnderwite.aspx?sys_id=4&AA=" + aa + "' target='ifr'   id='lnkAdd' >เพิ่ม</a>"

            daMenu = New DA_Menu(DMS_data)
            dt = daMenu.getUserRole(sys_id, aa)


            If dt.Rows.Count <> 0 Then

                CType(Master, DMSMaster).setSysName = dt.Rows(0)("system_name")
                t_year = dt.Rows(0)("UW_YEAR")
                t_month = dt.Rows(0)("UW_MONTH")

                daMenu = New DA_Menu(SETUP_data)
                dt = daMenu.getProvince()
                ddlProvinces.DataSource = dt
                ddlProvinces.DataTextField = "PROVINCE_NAME"
                ddlProvinces.DataValueField = "KEY_FIELD"
                ddlProvinces.DataBind()

                dt = daMenu.getLob()
                ddlT2.DataSource = dt
                ddlT2.DataTextField = "GT_KEY"
                ddlT2.DataValueField = "GT_KEY"
                ddlT2.DataBind()


                dt = daMenu.getYear(t_year)
                ddlT4.DataSource = dt
                ddlT4.DataTextField = "YearText"
                ddlT4.DataValueField = "YearValue"
                ddlT4.DataBind()
                ddlT4.SelectedValue = t_year
                dt = daMenu.getMonth()
                ddlT5.DataSource = dt
                ddlT5.DataTextField = "MonthText"
                ddlT5.DataValueField = "MonthValue"
                ddlT5.DataBind()
                ddlT5.SelectedValue = Right(Str(Val(t_month) + 100), 2)

                daMenu = New DA_Menu(DWPROD_data)
                dt = daMenu.getT_Agent()
                ddlManName.DataSource = dt
                ddlManName.DataTextField = "Agent_Code"
                ddlManName.DataValueField = "Agent_Name"
                ddlManName.DataBind()

            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('ผู้ใช้อยู่นอกระบบ');", True)
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub
    Protected Sub bntSch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntSch.Click
        Bill()
        Try

       
            dt = daAdd.schDoc(dsUnder)
            If dt.Rows.Count <> 0 Then
                DataGrid1.DataSource = dt
                DataGrid1.DataBind()
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('ไม่พบข้อมูล');", True)
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub
    Private Sub Bill()
        dsUnder = New DS_Underwrite()
        dsUnder.T1 = txtT1.Text
        dsUnder.T2 = ddlT2.SelectedValue
        dsUnder.T3 = txtT3.Text
        dsUnder.T4 = ddlT4.SelectedValue
        dsUnder.T5 = ddlT5.SelectedValue
        dsUnder.Ref_no = txtRef_no.Text
        dsUnder.InsureName = txtInsureName.Text
        dsUnder.IdCard = txtIdCard.Text
        dsUnder.Fcode = txtFcode.Text
        dsUnder.Ecode = txtEcode.Text
        dsUnder.Provinces = ddlProvinces.SelectedValue
        dsUnder.CarNum = txtCarNum.Text
        dsUnder.Man = txtMan.Text
        dsUnder.ManName = ddlManName.SelectedValue
        dsUnder.ManValue = txtManName.Text
        dsUnder.AA = hdnAA.Value
       
    End Sub

    Protected Sub bntSchMan_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntSchMan.Click
        Try
            daMenu = New DA_Menu(DWPROD_data)
            dt = daMenu.getT_Agent(txtMan.Text)
            ddlManName.DataSource = dt
            ddlManName.DataTextField = "Agent_Code"
            ddlManName.DataValueField = "Agent_Name"
            ddlManName.DataBind()
            txtManName.Text = String.Empty
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub
    Private Sub DataGrid1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGrid1.SelectedIndexChanged
        Dim t_doc_no, t_policy, t_LICENSE_NO, t_KEY_FIELD, region, program_name As String


        Dim row = DataGrid1.Items(DataGrid1.SelectedItem.ItemIndex)
        t_doc_no = row.Cells(2).Text
        t_policy = row.Cells(8).Text
        t_LICENSE_NO = row.Cells(6).Text
        t_KEY_FIELD = row.Cells(9).Text

        region = hdnRegion.Value
        program_name = hdnPro_nm.Value
        aa = hdnAA.Value
        sys_id = hdnSysId.Value

        Response.Redirect("ClaimsList.aspx?sys_id=" & sys_id & _
                          "&doc_no=" & t_doc_no & "&licenseno=" & t_LICENSE_NO & _
                          "&keyfield=" & t_KEY_FIELD & "&policy=" & t_policy & _
                          "&region=" & region & "&office_code=" & Mid(t_doc_no, 1, 2) & _
                          "&program_nm=" & program_name & _
                          "&AA=" & aa, True)
    End Sub

    'Protected Sub bntAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntAdd.Click
    '    Response.Redirect("addUnderwite.aspx?sys_id=4&AA=" & hdnAA.Value, True)
    'End Sub

    Protected Sub bntReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntReset.Click
        Response.Redirect(hdnLoad.Value)
    End Sub
End Class