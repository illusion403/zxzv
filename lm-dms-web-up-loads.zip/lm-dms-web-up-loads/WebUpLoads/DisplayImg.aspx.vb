﻿Imports System.IO
Imports System.Xml.Serialization
Imports System.Xml

Partial Public Class DisplayImg
    Inherits BasePage

    Private MySearchData As New GetDMS_Require.ImageService1
    Private MySearchPolicy As New wsSearchAegis.aegisWebService
    Public lstFile As List(Of DS_DisFile)
    Private dt As DataTable = Nothing
    Private results As DataSet = Nothing
    Private dsFile As DS_DisFile = Nothing
    Private Region As String '= System.Web.Configuration.WebConfigurationManager.AppSettings("Region")
    Private da As DA_Search = New DA_Search(DTW_data)
    Private DTW_data As String = System.Web.Configuration.WebConfigurationManager.AppSettings("DTW_data")
    Private DMS_data As String = System.Web.Configuration.WebConfigurationManager.AppSettings("DB")
    Private NSIS_Share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("NSIS_Share")
    Private DMS_share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("DMS_share")
    Private DMSUW_share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("UW_Share")
    Private DMSFN_share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("DMSFN_share")
    Private MEMO_share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("MEMO_share")
    Private EMCS_share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("EMCS_share")
    Private DIY_Share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("DIY_Share")
    Private SIG_Share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("SIG_Share")
    Private MI1_Share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("MI1_Share")
    Private MI2_Share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("MI2_Share")
    Private MI3_Share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("MI3_Share")
    Private RECEIPT_Share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("RECEIPT_Share")
    Private qkcash_Share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("qkcash_Share")
    Private PRINT_Share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("PRINT_Share")
    Private Intranet_flag As String = System.Web.Configuration.WebConfigurationManager.AppSettings.Get("Intranet")
    Private SV_BKK As String = System.Web.Configuration.WebConfigurationManager.AppSettings("SV_BKK")
    Private daMenu As DA_Menu = New DA_Menu(System.Web.Configuration.WebConfigurationManager.AppSettings.Get("DB"))
    Private daDis As DA_Display = New DA_Display(DMS_data)
    ' DisplayImg.aspx?sys_id=&doc_id=&sub_id=&doc_no=&doc_form=&doc_type=&region=&office_code=&program_nm=&AA=
    'Private aHShow As String = "DisplayImg.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&doc_form={4}&doc_type={5}&region={6}&office_code={7}&program_nm={8}&AA={9}"#FFFFFF
    Private aHShow As String = "<a href='DisplayImg.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&doc_form={4}&doc_type={5}&region={6}&office_code={7}&program_nm={8}&AA={9}' style='color: {11}; font-weight: bold;'>{10}</a>"
    Private aHMove As String = "ifrMoveFile.aspx?sys_id={0}&doc_id={1}&sub_id={2}&doc_no={3}&region={4}&office_code={5}&program_nm={6}&AA={7}"
    Private dtUser As DataTable = Nothing
    Private aPrint As String = String.Empty
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadPage()
        End If
    End Sub
    Private Sub LoadPage()
        Dim sys_id As String
        Dim doc_id As String
        Dim sub_id As String
        Dim doc_no As String
        Dim doc_form As String
        Dim doc_type As String
        Dim t_doctype As String
        Dim t_system_nm As String
        Dim aa As String

        sys_id = Request.QueryString("sys_id")
        doc_id = Request.QueryString("doc_id")
        sub_id = Request.QueryString("sub_id")
        doc_no = Request.QueryString("doc_no")
        doc_form = Request.QueryString("doc_form")
        doc_type = Request.QueryString("doc_type")
        aa = UCase(Request.QueryString("AA"))
        Region = Request.QueryString("region")

        hdnSysId.Value = sys_id
        hdndoc_id.Value = doc_id
        hdnsub_id.Value = sub_id
        hdndoc_no.Value = doc_no
        hdnAA.Value = aa
        hdnRegion.Value = Region
        hdndoc_form.Value = doc_form

        hdnoffice_code.Value = Request.QueryString("office_code")
        hdnprogram_name.Value = Request.QueryString("program_nm")
        CType(Master, DMSMaster).setSysName = daMenu.getDocSubSt(sys_id, doc_id, sub_id)
        CType(Master, DMSMaster).setdocType = "เอกสารของเลขที่: " & doc_no
        dtUser = daMenu.getUserRole(sys_id, aa)
        aPrint = dtUser.Rows(0)("Print_doc").ToString()
        Try
            If Mid(doc_form, 1, 3) = "DMS" Then
                DMS_Header(aa, sys_id, doc_id, sub_id, doc_no, doc_form, hdnoffice_code.Value, hdnprogram_name.Value, doc_type)
                DMS_Display(aa, sys_id, doc_id, sub_id, doc_no, doc_form, doc_type)
            ElseIf doc_form = "NSIS" Then ' NO TEST
                NSIS_Display(doc_no)
            ElseIf doc_form = "LCIS" Then
                DMS_Display(aa, "4", "2", "2", doc_no, doc_form, "0")

            ElseIf doc_form = "DIY" Then
                DIY_Display(doc_no)
            ElseIf doc_form = "MI" Then
                MI_Display(doc_no)
            ElseIf doc_form = "EMCS" Then
                EMCS_Display(doc_no)
            ElseIf Mid(doc_form, 1, 5) = "PRINT" Then
                PRINT_Display(doc_no, Right(Request.QueryString("doc_form"), 2))
            Else
                If doc_form = "TP-DRY" Then
                    t_doctype = "ADJ"
                    t_system_nm = "TP-DryClaim"
                ElseIf doc_form = "NON-EMCS" Then
                    t_doctype = "EIT"
                    t_system_nm = "NON-EMCS"
                ElseIf doc_form = "TP-ECrash" Then
                    t_doctype = "EIT"
                    t_system_nm = "TP-ECrash"
                ElseIf doc_form = "EIV" Then
                    t_doctype = "PAY"
                    t_system_nm = "E-Invoice"
                ElseIf doc_form = "TP-EIV" Then
                    t_doctype = "PAY"
                    t_system_nm = "TP-EInvoice"
                Else
                    t_doctype = doc_form
                    t_system_nm = "WUP"
                End If
                WUP_Display(doc_no, t_doctype, t_system_nm)
            End If
            If lstFile.Count > 0 Then
                Session("ObjDis") = lstFile
            ElseIf lstFile.Count = 0 Then
                Session("ObjDis") = "0"
            Else
                Session("ObjDis") = Nothing
            End If
            bt_pPolicy.Visible = False
            bt_nPolicy.Visible = False
            If doc_form.ToUpper().IndexOf("LCIS") <> -1 Then
                dt = New DataTable()
                Dim dsPolicy = New DS_SchPolicy()
                dsPolicy.CALLER = aa
                dsPolicy.REFERENCE_NO = "DMS123"

                dsPolicy.POLICY_NO_PAR = doc_no

                dsPolicy.CLAIM_NO_PAR = ""
                dsPolicy.LOSS_DATE_PAR = ""

                dsPolicy.VEHICLE_PREFIX_LICENSE_NO_PAR = ""
                dsPolicy.VEHICLE_LICENSE_NO_PAR = ""
                dsPolicy.PROVINCE_LICENSE_NO_PAR = ""
                dt = da.schPolicyClaimInfo(dsPolicy.SchPolicyTable)
                bt_pPolicy.Visible = False
                bt_nPolicy.Visible = False
                hdnLinkPolicyNo.Value = ""
                If dt.Rows.Count <> 0 Then
                    If dt.Rows(0).Item("PREVPOL").ToString <> "" Then
                        hdnLinkPolicyNo.Value = dt.Rows(0).Item("PREVPOL").ToString & "|"
                        bt_pPolicy.Visible = True
                    Else
                        hdnLinkPolicyNo.Value = "|"
                        bt_pPolicy.Visible = False
                    End If
                    If dt.Rows(0).Item("NEXTPOL").ToString <> "" Then  '"Previous Policy"
                        hdnLinkPolicyNo.Value &= dt.Rows(0).Item("NEXTPOL").ToString
                        bt_nPolicy.Visible = True
                    Else
                        hdnLinkPolicyNo.Value &= ""
                        bt_nPolicy.Visible = False
                    End If
                End If
            End If



            'Dim xF As TextWriter = New StreamWriter(Server.MapPath(System.Web.Configuration.WebConfigurationManager.AppSettings.Get("TEMP_PATH")) + System.Web.Configuration.WebConfigurationManager.AppSettings.Get("TEMP_FILE"))
            'Dim xmlP As XmlSerializer = New XmlSerializer(GetType(List(Of DS_DisFile)))
            'xmlP.Serialize(xF, lstFile)
            'xF.Close()
        Catch ex As Exception
            ' ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('" + ex.Message + "');", True)
            lb_message.Text = ex.Message
            Session("ObjDis") = Nothing
        End Try
    End Sub
    Public Sub setlnkPolicy1(ByVal st_path As String, ByVal st_para As String)
        Response.Redirect("DisplayImg.aspx?" & st_para, False)
    End Sub
    Private Sub DMS_Header(ByVal aa As String, _
                            ByVal sys_id As String, _
                            ByVal doc_id As String, _
                            ByVal sub_id As String, _
                            ByVal doc_no As String, _
                            ByVal doc_form As String, _
                            ByVal office_code As String, _
                            ByVal program_nm As String, _
                            ByVal doc_type As String)
        Dim stAmin As String = daDis.chkAmin(aa, sys_id)
        Dim user As String = String.Empty
        Dim t_color As String = "#FFFFFF"
        lstFile = New List(Of DS_DisFile)
        Label1.Text = ""
        If dtUser.Rows(0)("Lavel") = "U" Then
            user = aa
        End If
        dt = daDis.disDMS_Header(sys_id, doc_id, sub_id, doc_no, user)
        If dt.Rows.Count > 1 Then
            If doc_type = "0" Then
                t_color = "#FF9900"
            End If
            Label1.Text = "<table cellpadding='0' cellspacing='0' border='0' style='width:300px;'><tr>"
            Label1.Text &= "<td>" & String.Format(aHShow, sys_id, doc_id, sub_id, doc_no, doc_form, "0", Region, office_code, program_nm, aa, "ALL", t_color) & "</td>"
            For Each dr As DataRow In dt.Rows
                t_color = "#FFFFFF"
                If dr.Item("doc_type").ToString = doc_type Then
                    t_color = "#FF9900"
                End If
                Label1.Text &= "<td>" & String.Format(aHShow, sys_id, doc_id, sub_id, doc_no, doc_form, dr.Item("doc_type").ToString, Region, office_code, program_nm, aa, dr.Item("doc_type").ToString, t_color) & "</td>"
            Next
            Label1.Text &= "</tr></table>"
        End If
    End Sub
    Private Sub DMS_Display(ByVal aa As String, _
                            ByVal sys_id As String, _
                            ByVal doc_id As String, _
                            ByVal sub_id As String, _
                            ByVal doc_no As String, _
                            ByVal doc_form As String, _
                            ByVal doc_type As String)


        Dim stAmin As String = daDis.chkAmin(aa, sys_id)
        Dim user As String = String.Empty
        lstFile = New List(Of DS_DisFile)

        If dtUser.Rows(0)("Lavel") = "U" Then
            user = aa
        End If
        dt = daDis.disDMS(sys_id, doc_id, sub_id, doc_no, user, doc_type)
        If dt.Rows.Count = 0 And doc_form = "LCIS" Then
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('ไม่พบข้อมูล');", True)
            Exit Sub
        End If
        For Each dr As DataRow In dt.Rows
            dsFile = New DS_DisFile()
            Dim t_date_path As String
            Dim path_name As String
            If IsDBNull(dr.Item("new_vol_flag")) Or dr.Item("new_vol_flag").ToString = "N" Then
                t_date_path = ""
            Else
                t_date_path = CDate(dr.Item("create_date")).ToString("yyyy\\MM")  'Replace(CType(dr.Item("create_date"), Date).GetDateTimeFormats(New Globalization.CultureInfo("en-US"))(65), "-", "\").Substring(0, 8)
            End If
            path_name = daMenu.get_path(sys_id, dr.Item("Region"), Intranet_flag, CDate(dr.Item("create_date")).ToString("yyyy.MM.dd"))
            If (InStr(1, LCase(dr.Item("doc_form")), "-memo") > 0) Then
                dsFile.FilePath = path_name & "MEMO\" & t_date_path & "\"
                'ElseIf sys_id = "4" Then
                '    dsFile.FilePath = DMSUW_share & dr.Item("Region") & "\" & t_date_path
                'ElseIf sys_id = "5" Or sys_id = "6" Then
                '    dsFile.FilePath = DMSFN_share & dr.Item("Region") & "\" & t_date_path
                'Else
                '    dsFile.FilePath = DMS_share & dr.Item("Region") & "\" & t_date_path
            Else
                dsFile.FilePath = path_name & dr.Item("Region") & "\" & t_date_path & "\"
            End If
            'If Region <> "Bangkok" Then
            '    If (InStr(1, LCase(DMS_share), LCase(dr.Item("Region"))) = 0) Then
            '        If dr.Item("Region") <> "Bangkok" Then
            '            dsFile.FilePath = dsFile.FilePath.Replace(Region, dr.Item("Region"))
            '        Else
            '            dsFile.FilePath = dsFile.FilePath.Replace("LMG_" & Region, SV_BKK)
            '        End If
            '    End If
            'End If
            If (stAmin = "1") Or ((UCase(dr.Item("create_by")) = aa) And (stAmin = "0")) Then
                dsFile.FileDel = True
                dsFile.FileMove = True
            Else
                dsFile.FileDel = False
                dsFile.FileMove = False
            End If
            dsFile.FileName = dr.Item("picture_name")
            dsFile.Msg = IIf(IsDBNull(dr.Item("picture_description")), Nothing, dr.Item("picture_description"))
            dsFile.Pnt = aPrint
            lstFile.Add(dsFile)
        Next dr

        If doc_form = "DMS-SIGN" Then
            Dim ds_pda As New DataSet
            ds_pda = MySearchData.wsSearchPDA(doc_no)
            If ds_pda.Tables("t_pdaSign").Rows.Count <> 0 Then
                dt = ds_pda.Tables("t_pdaSign")
                For Each dr As DataRow In dt.Rows
                    dsFile = New DS_DisFile()
                    dsFile.FilePath = SIG_Share
                    dsFile.FileName = dr.Item("name").ToString()
                    dsFile.Pnt = aPrint
                    lstFile.Add(dsFile)
                Next dr
            End If
        ElseIf doc_form = "DMS-Receipt" Then
            Dim ds_pda As New DataSet
            ds_pda = MySearchData.wsSearchPDAReceipt(doc_no, "L")
            If ds_pda.Tables("t_Receipt").Rows.Count <> 0 Then
                dt = ds_pda.Tables("t_Receipt")
                For Each dr As DataRow In dt.Rows
                    dsFile = New DS_DisFile()
                    dsFile.FilePath = RECEIPT_Share
                    dsFile.FileName = dr.Item("FILE_NAME").ToString() & ".jpg"
                    dsFile.Pnt = aPrint
                    lstFile.Add(dsFile)
                Next dr
            End If
        ElseIf doc_form = "DMS-qkcash" Then
            Dim doc_group_submain As String = daDis.Getdoc_group(sys_id, doc_id, sub_id)
            Dim ds_pda As New DataSet
            ds_pda = MySearchData.wsSearchPDAQkcash(doc_no, doc_group_submain, "L")
            If ds_pda.Tables("t_qkcash").Rows.Count <> 0 Then
                dt = ds_pda.Tables("t_qkcash")
                For Each dr As DataRow In dt.Rows
                    dsFile = New DS_DisFile()
                    dsFile.FilePath = qkcash_Share
                    dsFile.FileName = dr.Item("FILE_NAME").ToString() & ".jpg"
                    dsFile.Pnt = aPrint
                    lstFile.Add(dsFile)
                Next dr
            End If
        End If
    End Sub

    Private Sub NSIS_Display(ByVal t_policy As String)

        Dim t_licenseno As String = String.Empty
        Dim t_keyfield As String = String.Empty
        Dim pathpic As String = String.Empty
        Dim objFSO As Object = Nothing
        Dim objFolder As Object = Nothing

        lstFile = New List(Of DS_DisFile)

        daDis = New DA_Display(DTW_data)

        dt = daDis.getParaNSIS(t_policy)

        If dt.Rows.Count <> 0 Then
            t_licenseno = dt.Rows(0).Item("LICENSE_NO").ToString
            t_keyfield = dt.Rows(0).Item("KEY_FIELD").ToString
        End If

        results = MySearchData.wsSearchNSIS(t_licenseno, t_keyfield)

        If results.Tables("Search_NSIS_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
            For Each dr In results.Tables("t_nsis").Rows
                pathpic = NSIS_Share & dr.Item("path")
                objFSO = Server.CreateObject("Scripting.FileSystemObject")

                If objFSO.FolderExists(pathpic) = True Then
                    objFolder = objFSO.GetFolder(pathpic)

                    For Each objFileitem As Object In objFolder.files

                        If Right(LCase(objFileitem.name), 3) <> ".db" Then
                            dsFile = New DS_DisFile()
                            dsFile.FilePath = pathpic
                            dsFile.FileName = objFileitem.name
                            dsFile.Pnt = aPrint
                            lstFile.Add(dsFile)
                        End If
                    Next objFileitem
                End If
                objFSO = Nothing
            Next dr
        End If

    End Sub

    Private Sub DIY_Display(ByVal doc_no As String)

        lstFile = New List(Of DS_DisFile)
        results = MySearchData.wsSearchDIY(doc_no)

        If results.Tables("Search_DIY_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
            For Each dr As DataRow In results.Tables("t_diy").Rows
                dsFile = New DS_DisFile()
                dsFile.FilePath = DIY_Share
                dsFile.FileName = dr.Item("FILE_NAME")
                dsFile.Pnt = aPrint
                lstFile.Add(dsFile)
            Next dr
        End If

    End Sub

    Private Sub PRINT_Display(ByVal t_policy As String, _
                              ByVal t_lob As String)
        Dim objFSO As Object = Nothing
        lstFile = New List(Of DS_DisFile)
        results = MySearchData.wsSearchPRINT(t_policy, t_lob)
        If results.Tables("Search_PRINT_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
            For Each dr As DataRow In results.Tables("t_print").Rows
                dsFile = New DS_DisFile()
                If dr.Item("POLICY_ENDORSEMENT_NO") = "00" Then
                    dsFile.FileName = "P" & dr.Item("POLICY_NO").Replace("-", "")
                    objFSO = Server.CreateObject("Scripting.FileSystemObject")
                    If Not (objFSO.FileExists(PRINT_Share & dsFile.FileName & ".pdf")) Then
                        dsFile.FileName = dr.Item("POLICY_NO").Replace("-", "")
                    End If
                    objFSO = Nothing
                Else
                    dsFile.FileName = "E" & dr.Item("POLICY_NO").Replace("-", "") & dr.Item("POLICY_ENDORSEMENT_NO")
                End If
                dsFile.FileName &= ".pdf"
                dsFile.FilePath = PRINT_Share
                dsFile.Pnt = aPrint
                lstFile.Add(dsFile)
            Next dr
        End If
    End Sub
    Private Sub WUP_Display(ByVal doc_no As String, _
                            ByVal t_doctype As String, _
                            ByVal t_system_nm As String)
        lstFile = New List(Of DS_DisFile)
        results = MySearchData.wsSearchWUP(doc_no, t_doctype, t_system_nm)
        If results.Tables("Search_WUP_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
            For Each dr As DataRow In results.Tables("t_wup").Rows
                dsFile = New DS_DisFile()
                dsFile.FilePath = DMS_share & dr.Item("Region") & "\"

                If Region <> "Bangkok" Then
                    If (InStr(1, LCase(DMS_share), LCase(dr.Item("Region"))) = 0) Then
                        If dr.Item("Region") <> "Bangkok" Then
                            dsFile.FilePath = dsFile.FilePath.Replace(Region, dr.Item("Region"))
                        Else
                            dsFile.FilePath = dsFile.FilePath.Replace("LMG_" & Region, SV_BKK)
                        End If
                    End If
                End If
                'dsFile.FileDis = dr.Item("picture_description")
                dsFile.FileName = dr.Item("picture_name")
                dsFile.Pnt = aPrint
                lstFile.Add(dsFile)
            Next dr
        End If
    End Sub
    Private Sub MI_Display(ByVal doc_no As String)

        lstFile = New List(Of DS_DisFile)

        results = MySearchData.wsSearchMI(doc_no)
        For Each dr As DataRow In results.Tables("t_mi").Rows
            For j = 1 To dr.Item("Page_No")
                dsFile = New DS_DisFile()
                dsFile.FileName = dr.Item("PO_NO_NAME") & "_" & Trim(Str(j)) & ".pdf"
                If Not IsDBNull(dr.Item("Detail")) Then
                    If dr.Item("Detail") = "PROCUREMENT" Then
                        dsFile.FilePath = MI1_Share
                    ElseIf dr.Item("Detail") = "GENUINE" Then
                        dsFile.FilePath = MI2_Share
                    Else
                        dsFile.FilePath = MI3_Share
                    End If
                Else
                    dsFile.FilePath = MI3_Share
                End If
                dsFile.Pnt = aPrint
                lstFile.Add(dsFile)
            Next j
        Next dr
        results = MySearchData.wsSearchMI_BKK(doc_no)
        If results.Tables("Search_MI_BKK_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then

            For Each dr As DataRow In results.Tables("t_mi_bkk").Rows
                For j = 1 To dr.Item("Page_No")
                    dsFile.FileName = dr.Item("PO_NO_NAME") & "_" & Trim(Str(j)) & ".pdf"
                    If (Not IsDBNull(dr.Item("Detail"))) AndAlso dr.Item("Detail") = "PROCUREMENT" Then
                        dsFile.FilePath = MI1_Share
                    Else
                        dsFile.FilePath = String.Empty
                    End If
                Next j
            Next dr
        End If


    End Sub
    Private Sub EMCS_Display(ByVal doc_no As String)

        Dim party As String = String.Empty
        Dim t_CARIDENNO As String = String.Empty
        results = MySearchData.wsSearchEMCS(doc_no)

        If results.Tables("Search_EMCS_Return_Code").Rows(0).Item("WS_RETURN_CODE") = "1" Then
            For Each dr As DataRow In results.Tables("t_emcs").Rows
                t_CARIDENNO = dr.Item("CARIDENNO")
                If t_CARIDENNO = "0" Then
                    party = "ผู้เอาประกัน"
                Else
                    party = "คู่กรณีคนที่ " & t_CARIDENNO
                End If

                dsFile.FilePath = EMCS_share
                dsFile.FileName = (Trim(Str(dr.Item("id"))) & ".jpg")
            Next dr
        End If

    End Sub


    Protected Sub bntDel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntDel.Click
        Try
            Dim arrFile() As String = hdnSetFName.Value.Split("|")
            If arrFile.Length > 1 Then
                For i As Integer = 0 To arrFile.Length - 2
                    Dim strFile() As String = arrFile(i).Split(",")
                    Try
                        FileIO.FileSystem.DeleteFile(strFile(1))
                    Catch ex As Exception

                    End Try
                    daDis.DeldisDMS(hdnSysId.Value, hdndoc_id.Value, hdnsub_id.Value, hdndoc_no.Value, strFile(0), hdnAA.Value)

                Next i
                ' Response.Redirect(String.Format(aHShow, hdnSysId.Value, hdndoc_id.Value, hdnsub_id.Value, hdndoc_no.Value, hdndoc_form.Value, "", hdnRegion.Value, "", "", hdnAA.Value), True)
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Close", "window.close();", True)
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('กรุณาเลือก File');", True)
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub

    Protected Sub bntMove_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntMove.Click
        Try
            Dim arrFile() As String = hdnSetFName.Value.Split("|")
            If arrFile.Length > 1 Then
                Dim ds As DS_File
                Dim lstds As List(Of DS_File) = New List(Of DS_File)
                For i As Integer = 0 To arrFile.Length - 2
                    Dim strFile() As String = arrFile(i).Split(",")
                    ds = New DS_File
                    ds.FileName = strFile(0)
                    ds.OFilePath = strFile(1).Replace("\" + strFile(0), "")
                    ds.DesFile = strFile(2)

                    lstds.Add(ds)
                Next i
                Session("ObjSave") = lstds
                Response.Redirect(String.Format(aHMove, hdnSysId.Value, hdndoc_id.Value, hdnsub_id.Value, hdndoc_no.Value, hdnRegion.Value, hdnoffice_code.Value, hdnprogram_name.Value, hdnAA.Value), False)
            Else
                ' Label2.Text = "กรุณาใส่ชื่อ File ที่ต้องการ Upload"
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('กรุณาเลือก File');", True)
            End If

        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub

    Protected Sub bt_pPolicy_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bt_pPolicy.Click
        Dim LPolicy As String = hdnLinkPolicyNo.Value.Split("|")(0)
        Dim st_lnkPolicy As String = "sys_id=" & hdnSysId.Value & "&doc_id=" & hdndoc_id.Value & "&sub_id=" & hdnsub_id.Value & "&doc_no=" & LPolicy & "&doc_form=" & hdndoc_form.Value & "&doc_type=0&region=" & hdnRegion.Value & "&office_code=" & hdnoffice_code.Value & "&program_nm=" & hdnprogram_name.Value & "&AA=" & hdnAA.Value
        Response.Redirect("DisplayImg.aspx?" & st_lnkPolicy)
    End Sub

    Protected Sub bt_nPolicy_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bt_nPolicy.Click
        Dim LPolicy As String = hdnLinkPolicyNo.Value.Split("|")(1)
        Dim st_lnkPolicy As String = "sys_id=" & hdnSysId.Value & "&doc_id=" & hdndoc_id.Value & "&sub_id=" & hdnsub_id.Value & "&doc_no=" & LPolicy & "&doc_form=" & hdndoc_form.Value & "&doc_type=0&region=" & hdnRegion.Value & "&office_code=" & hdnoffice_code.Value & "&program_nm=" & hdnprogram_name.Value & "&AA=" & hdnAA.Value
        Response.Redirect("DisplayImg.aspx?" & st_lnkPolicy)
    End Sub
End Class