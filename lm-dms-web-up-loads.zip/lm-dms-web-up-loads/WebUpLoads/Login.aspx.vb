Imports System
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Net
Imports System.Web.Services.Protocols


Public Class Login
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Prevent browser caching of login page to ensure updated session check on Back button
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddSeconds(-1))
        Response.Cache.SetNoStore()

        ' Always clear old session localStorage when arriving at login page
        ' This ensures stale values from closed browser sessions don't interfere
        Dim clearScript As String = "if (typeof(Storage) !== 'undefined') { localStorage.removeItem('dms_session_expires'); }"
        ClientScript.RegisterStartupScript(Me.GetType(), "ClearStaleSessionStorage", clearScript, True)

        ' Check if user is already authenticated AND has a valid session
        If User.Identity.IsAuthenticated Then
            ' Verify that critical session data exists (not just auth cookie)
            If Session("USERLOGIN") IsNot Nothing AndAlso Not String.IsNullOrEmpty(Session("USERLOGIN").ToString()) AndAlso Session("IsAuthenticated") IsNot Nothing AndAlso Convert.ToBoolean(Session("IsAuthenticated")) AndAlso Request.Cookies("SessionExpiry") IsNot Nothing Then
                ' Valid session exists, allow redirect
                RedirectToRequestedPage()
            Else
                ' Auth cookie exists but session expired - force re-login
                ' Clear the authentication cookie to force fresh login
                FormsAuthentication.SignOut()
                If Request.Cookies(FormsAuthentication.FormsCookieName) IsNot Nothing Then
                    Dim authCookie As New HttpCookie(FormsAuthentication.FormsCookieName)
                    authCookie.Expires = DateTime.Now.AddDays(-1)
                    Response.Cookies.Add(authCookie)
                End If
                ' Fall through to show login form
            End If
        End If

        ' Pre-populate username if provided in query string
        If Not IsPostBack Then
            If Not String.IsNullOrEmpty(Request.QueryString("ReturnUrl")) Then
                ViewState("ReturnUrl") = Request.QueryString("ReturnUrl")
            End If

            ' Auto-focus on username field
            txtUsername.Focus()
        End If
    End Sub

    Protected Sub bntLogin_Click(sender As Object, e As EventArgs) Handles bntLogin.Click

        ' Validate input
        If String.IsNullOrWhiteSpace(txtUsername.Text) OrElse String.IsNullOrWhiteSpace(txtPassword.Text) Then
            lbError.Text = "Please enter both username and password."
            'lblMessage.CssClass = "message-container error"
            Return
        End If

        ' XSS Protection: explicit check for username
        ' (Password is not checked for XSS as it may contain special characters and is not rendered back directly)
        If IsXssInput(txtUsername.Text) Then
            lbError.Text = "Invalid characters detected in username."
            Return
        End If

        Try
            ' Call authentication web service
            Dim authService As New WebUpLoads.wsAuthen.Service1()

            Dim isAuthenticated As Boolean = authService.Check_UserAuthen(txtUsername.Text.Trim(), txtPassword.Text)

            If isAuthenticated Then
                ' Authentication successful
                ProcessSuccessfulLogin()
            Else
                ' Authentication failed
                lbError.Text = "Invalid username or password."
                'lblMessage.CssClass = "message-container error"
            End If
        Catch ex As SoapException
            ' Handle SOAP service exceptions
            lbError.Text = "Authentication service error: " & ex.Message
            'lblMessage.CssClass = "message-container error"
        Catch ex As WebException
            ' Handle web service connection errors
            lbError.Text = "Unable to connect to authentication service. Please try again later."
            'lblMessage.CssClass = "message-container error"
        Catch ex As Exception
            ' Handle other exceptions
            lbError.Text = "An error occurred during authentication. Please try again."
            'lblMessage.CssClass = "message-container error"
            ' Log the exception in a production environment
        End Try
    End Sub

    Private Sub ProcessSuccessfulLogin()
        ' Set authentication cookie
        FormsAuthentication.SetAuthCookie(txtUsername.Text.Trim(), False)

        Session("USERLOGIN") = txtUsername.Text.Trim()
        Session("IsAuthenticated") = True

        ' Set session expiry cookie for client-side timeout handling
        ' Use Session.Timeout to match KeepAlive.ashx logic and BasePage enforcement
        Dim timeoutMinutes As Integer = Session.Timeout
        Dim expiryMs As Long = CLng((DateTime.UtcNow.AddMinutes(timeoutMinutes) - New DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds)
        Dim expiryCookie As New HttpCookie("SessionExpiry", expiryMs.ToString())
        expiryCookie.Path = "/"
        Response.Cookies.Add(expiryCookie)

        ' Redirect to originally requested page or default page
        RedirectToRequestedPage()

    End Sub

    Private Sub RedirectToRequestedPage()
        ' Check if there's a return URL stored in ViewState
        Dim returnUrl As String = Nothing
        If ViewState("ReturnUrl") IsNot Nothing Then
            returnUrl = ViewState("ReturnUrl").ToString()
        End If

        If String.IsNullOrEmpty(returnUrl) Then
            returnUrl = Request.QueryString("ReturnUrl")
        End If

        ' Default to Default.aspx
        Dim targetUrl As String = "~/Default.aspx"

        ' Validate ReturnUrl if it exists
        If Not String.IsNullOrEmpty(returnUrl) Then
            ' Prevent redirecting back to Login.aspx to avoid loops
            Dim isLoginUrl As Boolean = returnUrl.IndexOf("Login.aspx", StringComparison.OrdinalIgnoreCase) >= 0

            If IsValidReturnUrl(returnUrl) AndAlso Not isLoginUrl Then
                ' If return URL is just root "/", force it to Default.aspx 
                ' This prevents HTTP 403.14 Forbidden if Default Document isn't configured in IIS
                If returnUrl = "/" Then
                    targetUrl = "~/Default.aspx"
                Else
                    targetUrl = returnUrl
                End If
            End If
        End If

        Response.Redirect(targetUrl, False)
        HttpContext.Current.ApplicationInstance.CompleteRequest()
    End Sub

    Private Function IsValidReturnUrl(ByVal returnUrl As String) As Boolean
        ' Basic validation to prevent open redirect vulnerabilities
        If String.IsNullOrEmpty(returnUrl) Then
            Return False
        End If

        ' Check against Open Redirect Vulnerability (Protocol-relative URLs)
        ' Prevent //example.com or /\example.com which browsers treat as absolute
        If returnUrl.StartsWith("//") OrElse returnUrl.StartsWith("/\") Then
            Return False
        End If

        ' Check if it's a relative URL or an absolute URL pointing to our site
        ' Allow ~/ for app-relative paths
        If returnUrl.StartsWith("/") OrElse returnUrl.StartsWith("~/") Then
            Return True
        End If

        ' Check if it's an absolute URL pointing to our domain
        Try
            Dim uri As New Uri(returnUrl)
            Return uri.Host.Equals(Request.Url.Host, StringComparison.OrdinalIgnoreCase)
        Catch
            ' Invalid URI format
            Return False
        End Try
    End Function
    Private Function IsXssInput(ByVal input As String) As Boolean
        If String.IsNullOrEmpty(input) Then
            Return False
        End If
        ' Check for common XSS characters/tags
        ' This is a basic check. .NET ValidateRequest="true" provides the main layer of defense.
        Dim xssSafe As Boolean = True
        If input.Contains("<") OrElse input.Contains(">") OrElse input.Contains("script") OrElse input.Contains("&#") Then
            Return True
        End If
        Return False
    End Function
End Class
