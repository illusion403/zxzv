Imports System
Imports System.Web
Imports System.Web.Security

Partial Public Class Logout
    Inherits BasePage
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Session.Clear()
        Session.Abandon()
        ExpireCookie("SessionExpiry")
        ExpireCookie("ASP.NET_SessionId")
        FormsAuthentication.SignOut()

        ' Check for returnUrl passed from client script
        Dim returnUrl As String = Request.QueryString("returnUrl")
        If Not String.IsNullOrEmpty(returnUrl) Then
            Response.Redirect("Login.aspx?ReturnUrl=" & Server.UrlEncode(returnUrl))
        Else
            Response.Redirect("Login.aspx")
        End If


    End Sub


End Class
