Imports System
Imports System.Web
Imports System.Web.UI

Public Class LogoutButton
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' No special logic needed for now
        ' The control is purely presentational with client-side JavaScript
    End Sub

End Class
