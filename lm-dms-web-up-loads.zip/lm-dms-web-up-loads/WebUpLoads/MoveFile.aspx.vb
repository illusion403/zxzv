﻿Public Partial Class MoveFile
    Inherits System.Web.UI.Page
    Private daMenu As DA_Menu = New DA_Menu(ConfigurationSettings.AppSettings.Get("DB"))

    Private config_region As String = ConfigurationSettings.AppSettings.Get("Region")
    Private DMS_share As String = System.Configuration.ConfigurationSettings.AppSettings("DMS_share")
    Private UW_Share As String = System.Configuration.ConfigurationManager.AppSettings("UW_Share")
    Private MEMO_share As String = System.Configuration.ConfigurationSettings.AppSettings("MEMO_share")
    Private MysendInfo As New wsSendInformation.SendData
    Private sys_id As String
    Private aa As String
    Private doc_no As String
    Private groupId As String
    Private Region As String
    Private office_code As String
    Private program_name As String

    Private dt As DataTable
    Public arrJs As String
    Public arrJsH As String
    Public arrJsIf As String

 
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            loadPage()
        End If
    End Sub

    Private Sub loadPage()
        sys_id = Request.QueryString("sys_id")
        ' sys_id = "4"
        aa = Request.QueryString("AA")
        '  aa = "GR00007"
        doc_no = Request.QueryString("doc_no")
        ' doc_no = "00-AV1-0000007-2009-04"
        Region = Request.QueryString("region")
        office_code = Request.QueryString("office_code")
        program_name = Request.QueryString("program_name")

        groupId = daMenu.getGroupID(sys_id, aa)



        hdnSysId.Value = sys_id
        hdnAA.Value = aa
        hdndoc_no.Value = doc_no
        hdnRegion.Value = Region
        hdnoffice_code.Value = office_code
        hdnprogram_name.Value = program_name



        dt = daMenu.getDMS_MenuDoc(doc_no, sys_id, groupId, aa)
        Dim drow() As DataRow = dt.Select("doc_main_id = " + Request.QueryString("doc_id") + " and doc_submain_id = " + Request.QueryString("sub_id"))
        TB_doc_main.Text = drow(0)("doc_main_name")
        TB_doc_submain.Text = drow(0)("doc_submain_nm")
        arrJsH = String.Empty
        arrJs = String.Empty
        Dim strHead As String = String.Empty
        Dim j = 0, k As Integer = 0
        For i As Integer = 0 To dt.Rows.Count - 1
            Dim dr As DataRow = dt.Rows(i)
            If strHead <> dr("doc_main_name") Then
                arrJsH += " opt.options[" + j.ToString() + "] = new Option('" + dr("doc_main_name").ToString() + "','" + dr("doc_main_id").ToString() + "');"
                If strHead <> String.Empty Then
                    arrJsIf += "}"
                End If
                arrJsIf += " if(objValue == '" + dr("doc_main_id").ToString() + "'){"

                strHead = dr("doc_main_name")
                j = j + 1
                k = 0
            End If
            If dr("doc_form").ToString().Substring(0, 1) <> "H" Then
                arrJsIf += " opt.options[" + k.ToString() + "] = new Option('" + dr("doc_submain_nm").ToString().Replace("&nbsp; ", "") + "','" + dr("doc_submain_id").ToString() + "');"
                k = k + 1
            End If

        Next i
        arrJsIf += "}"


        'Dim lstSave As List(Of DS_File) = CType(Session("ObjSave"), List(Of DS_File))
        'For i As Integer = 0 To lstSave.Count - 1
        '    lstFile.Items.Add(lstSave(i).FileName)
        'Next i
        'lstFile.DataBind()
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click

    'End Sub

    'Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click

    'End Sub
    Private Function createTable() As DataTable
        Dim MyTable As New DataTable
        Dim MyColumn As New DataColumn

        MyTable.TableName = "InputData"
        MyColumn = New DataColumn("SYSTEM_ID", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("MAIN_ID", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("SUBMAIN_ID", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("DOC_NO", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("DOC_TYPE", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("FILE_NAME", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("FILE_NO", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("USER_ID", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("REGION", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("OFFICE_CODE", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("APP_CALLER", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("REMARK", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("ARCHIVE_FLAG", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("FILE_DESC", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        MyColumn = New DataColumn("new_vol_flag", System.Type.GetType("System.String"))
        MyTable.Columns.Add(MyColumn)
        Return MyTable
    End Function

    Protected Sub bntMove_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntMove.Click
 
        Dim lstSave As List(Of DS_File) = Nothing
        Dim dsData As DS_Data = Nothing
        Dim dtData As DT_File = New DT_File()

        If Session("ObjSave") IsNot Nothing Then


            lstSave = CType(Session("ObjSave"), List(Of DS_File))
            dsData = New DS_Data()

            sys_id = hdnSysId.Value
            aa = hdnAA.Value
            doc_no = hdndoc_no.Value
            Region = hdnRegion.Value
            office_code = hdnoffice_code.Value
            program_name = hdnprogram_name.Value



            Dim t_doc_no As String = doc_no.Trim.Replace("-", "")
            Dim format = Now.GetDateTimeFormats
            Dim formatdate = format(105)
            Dim filedate As String

            filedate = "D" + Replace(Mid(formatdate, 1, 10), "-", "") + Mid(formatdate, 11, 9)
            filedate = filedate.Replace(":", "")
            filedate = filedate.Replace(" ", "")
            dt = createTable()
            '    'If dsData.TypeValue <> "0" Then
            For i As Integer = 0 To lstSave.Count - 1
                'Dim dsFile As DS_File = lstSave(i)

                lstSave(i).FileNew = t_doc_no & filedate & "_" & Trim(Str(i + 1)) & Mid(lstSave(i).FileName, lstSave(i).FileName.Trim.LastIndexOf(".") + 1)
                Dim save_path As String = ""
                Dim doc_form As String

                doc_form = daMenu.getDocSub(sys_id, ddl_doc_main.SelectedValue, ddl_doc_submain.SelectedValue)

                If (InStr(1, LCase(doc_form), "-memo") > 0) Then
                    save_path = MEMO_share.Substring(0, MEMO_share.Length - 1)
                ElseIf sys_id <> "4" Then
                    save_path = DMS_share & Region
                Else
                    save_path = UW_Share & Region
                End If

                If UCase(save_path).StartsWith("\\SV") Then
                    save_path = save_path & "\" & Now().ToString("yyyy\\MM") & "\"
                Else
                    save_path = Server.MapPath(save_path) & "/" & Now().ToString("yyyy/MM") & "/"
                End If
                lstSave(i).FilePath = save_path

                Dim dr As DataRow
                dr = dt.NewRow()
                dr("SYSTEM_ID") = sys_id ' sys_id
                dr("MAIN_ID") = ddl_doc_main.SelectedValue
                dr("SUBMAIN_ID") = ddl_doc_submain.SelectedValue
                dr("DOC_NO") = doc_no 'doc_no
                If ddlType.SelectedValue = "OD" Then
                    dr("DOC_TYPE") = "IN001"
                Else
                    dr("DOC_TYPE") = "TP" & Right((Val(txtNo.Text) + 1000).ToString, 3)
                End If

                dr("FILE_NAME") = lstSave(i).FileNew
                dr("FILE_NO") = (i + 1).ToString.Trim
                dr("USER_ID") = aa ' aa
                dr("REGION") = Region
                If office_code <> "" Then
                    dr("OFFICE_CODE") = office_code
                Else
                    If CInt(sys_id) <= 4 Then
                        dr("OFFICE_CODE") = Mid(doc_no, 1, 2) ' office_code
                    Else
                        dr("OFFICE_CODE") = "00"
                    End If
                End If
                If program_name <> "" Then
                    dr("APP_CALLER") = program_name ' program_name
                Else
                    dr("APP_CALLER") = "I-DMS"
                End If
                dr("REMARK") = ""
                dr("ARCHIVE_FLAG") = "N"
                dr("FILE_DESC") = lstSave(i).DesFile
                dr("new_vol_flag") = "Y"
                dt.Rows.Add(dr)
            Next i

            If Not dtData.SaveFile(dsData, lstSave) Then
                Dim ds As New DataSet
                ds.Tables.Add(dt)
                Try
                    Dim res As DataSet = MysendInfo.SendInformation(ds)
                Catch ex As Exception
                    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('" + ex.Message + "');", True)
                End Try

            Else
                ' lstSave(0).ErrorDtl
            End If



        End If
    End Sub

   
End Class