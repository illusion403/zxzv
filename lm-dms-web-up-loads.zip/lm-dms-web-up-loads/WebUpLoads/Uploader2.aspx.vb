﻿Imports System.Xml
Imports System.IO

Partial Public Class Uploader2
    Inherits BasePage
    Public galleryPath As String = "tmp/Gallery/"

    Public pathName As String = System.Web.Configuration.WebConfigurationManager.AppSettings("TEMP_PATH")

    Private sys_id As String
    Public doc_id As String
    Private sub_id As String
    Private doc_no As String
    Private region As String
    Private party_key As String
    Private office_code As String
    Private program_name As String
    Private Lvl As String
    Private aa As String
    Private groupId As String
    Private dt As DataTable

    Private daMenu As DA_Menu = New DA_Menu(System.Web.Configuration.WebConfigurationManager.AppSettings.Get("DB"))
    Private config_region As String = System.Web.Configuration.WebConfigurationManager.AppSettings.Get("Region")
    Private DMS_share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("DMS_share")
    Private UW_Share As String = System.Configuration.ConfigurationManager.AppSettings("UW_Share")
    Private MEMO_share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("MEMO_share")
    Private DMSUW_share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("UW_Share")
    Private DMSFN_share As String = System.Web.Configuration.WebConfigurationManager.AppSettings("DMSFN_share")

    Private MysendInfo As New wsSendInformation.SendData
    Private err_page As String = System.Web.Configuration.WebConfigurationManager.AppSettings.Get("error_page")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If String.IsNullOrEmpty(Request.Form("PackageGuid")) Then
            InitGallery()
        End If
        If Not IsPostBack Then
            loadPage()
        End If

    End Sub



    Private Sub ImageUploader1_FileUploaded(ByVal sender As Object, ByVal e As Aurigma.ImageUploader.FileUploadEventArgs) Handles ImageUploader1.FileUploaded
        'Save file and thumbnail 
        Dim physGalleryPath As String = Server.MapPath(galleryPath)
        Dim sourceFileName As String = e.SourceFile.GetSafeFileName(physGalleryPath)
        e.SourceFile.Save(System.IO.Path.Combine(physGalleryPath, sourceFileName))

        Dim physThumbnailsPath As String = Server.MapPath(galleryPath & "Thumbnails/")
        Dim thumbnailFileName As String = e.Thumbnails(1).GetSafeFileName(physThumbnailsPath)
        e.Thumbnails(1).Save(System.IO.Path.Combine(physThumbnailsPath, thumbnailFileName))

        'Save file info. 
        SyncLock Application
            'TODO: Use synchronization in more narrow scope 
            Dim descriptions As New XmlDocument()
            descriptions.Load(Server.MapPath(galleryPath & "Descriptions.xml"))

            Dim file As XmlElement = descriptions.CreateElement("file")
            file.SetAttribute("name", sourceFileName)
            file.SetAttribute("thumbName", thumbnailFileName)
            file.SetAttribute("width", Convert.ToString(e.SourceFile.Width))
            file.SetAttribute("height", Convert.ToString(e.SourceFile.Height))
            file.SetAttribute("handlerUrl", Request.Url.PathAndQuery)

            descriptions.DocumentElement.AppendChild(file)

            descriptions.Save(Server.MapPath(galleryPath & "Descriptions.xml"))
        End SyncLock
    End Sub
    Private Sub InitGallery()
        'Delete source files 
        Dim dir As New DirectoryInfo(Server.MapPath(galleryPath))
        For Each file As FileInfo In dir.GetFiles()
            file.Delete()
        Next

        'Delete thumbnails 
        dir = New DirectoryInfo(Server.MapPath(galleryPath) & "/Thumbnails")
        For Each file As FileInfo In dir.GetFiles()
            file.Delete()
        Next

        Dim descriptions As New XmlDocument()

        descriptions.AppendChild(descriptions.CreateElement("files"))

        descriptions.Save(Server.MapPath(galleryPath & "Descriptions.xml"))
    End Sub

    Private Sub loadPage()


        sys_id = Request.QueryString("sys_id")
        doc_id = Request.QueryString("doc_id")
        sub_id = Request.QueryString("sub_id")
        doc_no = Request.QueryString("doc_no")
        region = Request.QueryString("region")
        party_key = Request.QueryString("party_key")
        office_code = Request.QueryString("office_code")
        program_name = Request.QueryString("program_nm")
        aa = Request.QueryString("AA")



        Try
            groupId = daMenu.getGroupID(sys_id, aa)

            If groupId <> String.Empty Then

                dt = daMenu.getDocMain(sys_id, doc_id, groupId)

                Lvl = daMenu.getLvl(groupId)
                CType(Master, DMSMaster).setSysName = daMenu.getDocSubSt(sys_id, doc_id, sub_id)
                If Lvl = "U" Or Lvl = "L" Then


                    ddlGroupData.DataSource = dt
                    ddlGroupData.DataTextField = "doc_main_name"
                    ddlGroupData.DataValueField = "Doc_main_id"
                    ddlGroupData.DataBind()

                    If doc_id <> "0" Then
                        ddlGroupData.SelectedValue = doc_id
                        ddlGroupData.Enabled = False
                    End If

                    List_subid()

                    If (doc_no <> "") Then
                        txtClaimId.Text = doc_no
                        txtClaimId.ReadOnly = True
                    End If



                    If (region <> "") Then
                        ddlJob.SelectedValue = region
                    Else
                        ddlJob.SelectedValue = config_region
                    End If

                    ddlJob.Enabled = False

                    If ddlType.SelectedValue <> "0" And party_key = "" Then
                        List_type()
                        If ddlType.SelectedValue = "OD" Then
                            txtNo.Enabled = False
                        End If
                    End If
                Else
                    Response.Redirect(err_page)
                End If
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert(""" + ex.Message + """);", True)
        End Try
    End Sub

    Private Sub List_type()
        Dim t_split_doc_flag As String = daMenu.getDocFlag(sys_id, ddlGroupData.SelectedValue, ddlTypeData.SelectedValue)

        If t_split_doc_flag = "Y" Then
            ddlType.Enabled = True
            txtNo.Enabled = True
        Else
            ddlType.Enabled = False
            If (t_split_doc_flag = "N") Or (t_split_doc_flag = "I") Then
                ddlType.SelectedValue = "OD"
                txtNo.Text = ""
                txtNo.Enabled = False
            Else
                ddlType.SelectedValue = "TP"
                txtNo.Text = "1"
                txtNo.Enabled = True
            End If
        End If
    End Sub
    Private Sub List_subid()
        Dim tl As System.Web.UI.WebControls.ListItem
        groupId = daMenu.getGroupID(sys_id, aa)

        dt = daMenu.getDocSub(sys_id, doc_id, groupId, sub_id)
        If party_key = "" Then

            ddlTypeData.DataSource = dt
            ddlTypeData.DataTextField = "doc_submain_nm"
            ddlTypeData.DataValueField = "doc_submain_id"
            ddlTypeData.DataBind()

            ddlType.Enabled = True
        ElseIf party_key = "0" Then
            For Each p As DataRow In dt.Rows
                If p("split_doc_flag") = "I" Or p("split_doc_flag") = "N" Or p("split_doc_flag") = "Y" Then
                    tl = New System.Web.UI.WebControls.ListItem
                    tl.Text = p("doc_submain_nm")
                    tl.Value = p("doc_submain_id")
                    ddlTypeData.Items.Add(tl)
                End If
            Next

            tl = New System.Web.UI.WebControls.ListItem
            tl.Text = "กรุณาระบุ"
            tl.Value = "0"
            ddlTypeData.Items.Add(tl)
            ddlTypeData.DataBind()

            ddlType.SelectedValue = "OD"
            txtNo.Text = ""
            ddlType.Enabled = False
        Else
            For Each p As DataRow In dt.Rows
                If p("split_doc_flag") = "T" Or p("split_doc_flag") = "Y" Then
                    tl = New System.Web.UI.WebControls.ListItem
                    tl.Text = p("doc_submain_nm")
                    tl.Value = p("doc_submain_id")
                    ddlTypeData.Items.Add(tl)
                End If
            Next
            tl = New System.Web.UI.WebControls.ListItem
            tl.Text = "กรุณาระบุ"
            tl.Value = "0"
            ddlTypeData.Items.Add(tl)
            ddlTypeData.DataBind()

            ddlType.SelectedValue = "TP"
            txtNo.Text = party_key
            ddlType.Enabled = False
            txtNo.Enabled = False
        End If

        If sub_id <> "0" Then
            Dim chk_id As String = "N"
            For s As Integer = 0 To ddlTypeData.Items.Count - 1
                If ddlTypeData.Items(s).Value = sub_id Then
                    chk_id = "Y"
                    Exit For
                End If
            Next
            If chk_id = "Y" Then
                ddlTypeData.SelectedValue = sub_id
                ddlTypeData.Enabled = False
            Else
                ddlTypeData.SelectedValue = "0"
            End If
        Else
            ddlTypeData.SelectedValue = "0"
            ddlTypeData.Enabled = True
        End If
    End Sub

End Class