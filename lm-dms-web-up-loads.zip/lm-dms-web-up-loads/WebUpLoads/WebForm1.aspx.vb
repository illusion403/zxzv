﻿Imports System.Xml.Serialization
Imports System.Xml
Imports System.IO
Partial Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (IsPostBack) Then
            File1.Attributes.Add("accept", DA_File.chkFileInputClass)
        End If

    End Sub

    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Try
            DA_File.TempDir = Server.MapPath(System.Configuration.ConfigurationSettings.AppSettings("TEMP_PATH"))
            DA_File.addFile(Request.Files, hdnDes.Value)
            Message.InnerHtml = setMessage(DA_File.FileList)
            hdnMsg.Value = setMessage(DA_File.FileList)
            Session("ObjSave") = DA_File.FileList
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "ShowMessage", "alert('กรุณาเลือก File');", True)
        End Try


    End Sub
    Protected Function setMessage(ByVal arr As List(Of DS_File)) As String
        Dim stMsg As String = String.Empty
        For i As Integer = 0 To arr.Count - 1
            If arr(i).FileError = False Then
                stMsg += arr(i).FileMsg + Char.Parse("|")
            End If
        Next i
        Return stMsg
    End Function

    Private Sub ifUpLoads_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        'Message.Visible = Not String.IsNullOrEmpty(Message.InnerHtml)
    End Sub

End Class