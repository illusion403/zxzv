﻿Public Partial Class WebForm3
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim ss As String = "Moo"
    End Sub

    Protected Sub Button1_Click1(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim AllFiles As HttpFileCollection = Request.Files
        AllFiles(0).SaveAs(Server.MapPath(System.Configuration.ConfigurationSettings.AppSettings("TEMP_PATH")) + "\aaa.jpg")
        Dim img As Image = New Image()

        img.ImageUrl = System.Configuration.ConfigurationSettings.AppSettings("TEMP_PATH") + "\aaa.jpg"
        Page.Form.Controls.Add(img)
    End Sub

End Class