﻿Imports System.IO
Imports System.Xml.Serialization
Imports System.Xml

Partial Public Class ifrDisPage
    Inherits System.Web.UI.Page

    Private lstFile As List(Of DS_DisFile)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim xF As FileStream = New FileStream(Server.MapPath(ConfigurationSettings.AppSettings.Get("TEMP_PATH")) + ConfigurationSettings.AppSettings.Get("TEMP_FILE"), FileMode.Open)
        Dim xR As XmlReader = New XmlTextReader(xF)
        Dim ser As XmlSerializer = New XmlSerializer(GetType(List(Of DS_DisFile)))
        lstFile = CType(ser.Deserialize(xR), List(Of DS_DisFile))
        Dim daf As DA_DisFile = New DA_DisFile()
        daf.ServerPath = Server.MapPath("")
        daf.setDisImage(lstFile)
        divDis.InnerHtml = daf.setDisStr(lstFile)
        xR.Close()
        xF.Close()
    End Sub

End Class