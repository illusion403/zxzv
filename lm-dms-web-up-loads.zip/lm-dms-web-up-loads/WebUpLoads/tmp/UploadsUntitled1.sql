




'<table><tr><td class="tdPic" align="right" ><span id="txtNo' + this.stDiv + arrNum + '" class="lbI"  ></span>.</td><td class="tdTxt" >'+
                      '<select id="lstSell' + this.stDiv + arrNum +'" onblur="setSell' + this.stDiv + '(this,' + arrNum +')"  class="selTxt" name="lstSell" ></select>'+
                      
                      '<table border ="0" cellpadding ="0" cellspacing ="0"><tr><td><span id="txtSell' + this.stDiv + arrNum +'" class="selTxt"  ></span></td><td><input type"text" id="txtMsg' + this.stDiv + arrNum +'" onblur="setMsg' + this.stDiv + '(this,' + arrNum +')"  value="" /></td></tr></table></td><td>'+
                      '<input id="txtNum' + this.stDiv + arrNum + '" class="inputNum"  onblur="setNum' + this.stDiv + '(this,' + arrNum + ')"   onkeydown="fixkeyNum(this)" maxlength="2" />'+
                      '</td><td class="numType"><span class="lbI" >' + this.stNum + '</span></td><td>'+
                      '<input id="txtMoney' + this.stDiv + arrNum +'" class="inputMoney" onblur="setMoney' + this.stDiv + '(this,' + arrNum +')"   onkeydown="fixkey(this)" maxlength="14"  /></td>'+
                      '<td  class="monType"><span class="lbI" >' + this.stMoney + '</span>'+
                      '</td><td class="tdPic"><img src="img/add.gif" id="add' + this.stDiv + arrNum +'" title="����" class="imgPic" onclick="addRow' + this.stDiv + '();" alt="����" /></td><td  class="tdPic"><img src="img/del.gif" id="del' + this.stDiv + arrNum +'" title="ź" class="imgPic" onclick="delRow' + this.stDiv + '(' + arrNum + ')" alt="ź" /></td></tr></table>'